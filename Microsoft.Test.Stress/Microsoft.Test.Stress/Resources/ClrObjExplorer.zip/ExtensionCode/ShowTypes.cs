﻿//Desc: Enumerate all types, show them and their methods, fields

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Reflection.Emit;
using System.Runtime.Remoting.Messaging;

namespace ClrObjExtension
{

    public class MyMainClass : BaseExtension
    {
        public interface ITest1
        {
            string Name { get; set; }
        }
        public interface ITest2 : ITest1, IDisposable
        {
            public void foo();
        }
        public class MyMainTest : ITest2
        {
            public string Name { get; set; }
            public void foo()
            {

            }
            public void Dispose() { }
        }

        public static void DoMain(object[] args)
        {
            var xx = new MyMainTest();
            xx.foo();
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("Types", $"Select a type to show its methods");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
        public class MyUserControl : UserControl
        {
            MyMainClass _MyMainClass;
            MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
            ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
            public MyUserControl(MyMainClass myMainClass)
            {
                _MyMainClass = myMainClass;
            }
            public void Initialize()
            {
                // Make a namespace referring to our namespace and assembly
                // using the prefix "l:"
                //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
                var nameSpace = this.GetType().Namespace;
                var asm = System.IO.Path.GetFileNameWithoutExtension(
                    System.Reflection.Assembly.GetExecutingAssembly().Location);

                var xmlns = string.Format(
    @"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
                //there are a lot of quotes (and braces) in XAML
                //and the C# string requires quotes to be doubled
                var strxaml =
    @"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
    @" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""600""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition/>
    </Grid.ColumnDefinitions>
    <DockPanel x:Name = ""dpTypes"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
        <Grid Grid.Row = ""1""  Grid.Column = ""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""20""/>
                <RowDefinition Height = ""90""/>
                <RowDefinition Height = ""3""/>
                <RowDefinition/>
                <RowDefinition Height = ""3""/>
                <RowDefinition/>
                <RowDefinition Height = ""3""/>
                <RowDefinition/>
                <RowDefinition Height = ""3""/>
                <RowDefinition/>
            </Grid.RowDefinitions>
            <DockPanel x:Name = ""dpLabel"" Grid.Row=""0"" />
            <DockPanel x:Name = ""dpData"" Grid.Row = ""1""/>
            <GridSplitter Grid.Row=""2"" Height=""3"" HorizontalAlignment=""Stretch"" VerticalAlignment=""Center"" Background=""LightBlue""/>
            <DockPanel x:Name = ""dpHier"" Grid.Row = ""3""/>
            <GridSplitter Grid.Row=""4"" Height=""3"" HorizontalAlignment=""Stretch"" VerticalAlignment=""Center"" Background=""LightBlue""/>
            <DockPanel x:Name = ""dpMethods"" Grid.Row=""5"" />
            <GridSplitter Grid.Row=""6"" Height=""3"" HorizontalAlignment=""Stretch"" VerticalAlignment=""Center"" Background=""LightBlue""/>
            <DockPanel x:Name = ""dpFields"" Grid.Row = ""7""/>
            <GridSplitter Grid.Row=""8"" Height=""3"" HorizontalAlignment=""Stretch"" VerticalAlignment=""Center"" Background=""LightBlue""/>
            <DockPanel x:Name = ""dpStatFields"" Grid.Row = ""9""/>
        </Grid>
</Grid>
";
                var grid = (Grid)XamlReader.Parse(strxaml);
                this.Content = grid;
                var dpTypes = (DockPanel)grid.FindName("dpTypes");
                var dpLabel = (DockPanel)grid.FindName("dpLabel");
                var dpData = (DockPanel)grid.FindName("dpData");
                var dpHier = (DockPanel)grid.FindName("dpHier");
                var dpMethods = (DockPanel)grid.FindName("dpMethods");
                var dpFields = (DockPanel)grid.FindName("dpFields");
                var dpStatFields = (DockPanel)grid.FindName("dpStatFields");
                dpLabel.Children.Add(new TextBlock() { Text = "Select a type to show methods, fields" });
                //            DockPanel.SetDock(dpTypes, Dock.Left);
                using (var _progress = new ProgressOwnUI<string>("Getting all types"))
                {
                    var lstAllTypes = new List<ClrType>();
                    // for generics, these types only show generic params, like "List<T>", and not "List<int>"
                    _clrUtil.clrRuntime.EnumerateTypes((type) =>
                    {
                        lstAllTypes.Add(type);
                        return true; // keep enumerating
                    });
                    var query = from atype in lstAllTypes
                                let InstanceCount = _clrUtil.GetObjectsOfType(atype.Name).Count
                                select new
                                {
                                    _type = atype,
                                    atype.Name,
                                    InstanceCount
                                };
                    var br = new BrowsePanel(query);

                    _mainWindowClrObjExp.AddItemsToContextMenu(br, "_type");
                    int numMsgs = 0;
                    void DoInheritOrImplement(string InheritOrImplement)
                    {
                        var lstTypesTarget = new List<ClrType>();
                        if (br.BrowseList.SelectedItems.Count == 1)
                        {
                            var selectedItem = br.BrowseList.SelectedItems[0];
                            var typeTarget = (ClrType)TypeDescriptor.GetProperties(selectedItem)["_type"].GetValue(selectedItem);
                            using (var _progress = new ProgressOwnUI<string>($"{InheritOrImplement} types"))
                            {
                                foreach (var testType in lstAllTypes)
                                {
                                    if (testType.Name != "ClrObjExtension.MyMainClass+MyMainTest")
                                    {
                                        //                                        continue;
                                    }
                                    var curType = testType;
                                    while (curType != null && curType.Name != "System.Object")
                                    {
                                        if (InheritOrImplement == "Implement")
                                        {
                                            foreach (var intface in curType.EnumerateInterfaces())
                                            {
                                                var curIntface = intface;
                                                var nDepth = 0;
                                                while (curIntface != null)
                                                {
                                                    if (numMsgs++ < 50)
                                                    {
                                                        // ClrType =='ClrObjExtension.MyMainClass+ITest2', but intface.name == 'ITest2'
                                                        // for IDisposable, both are System.IDisposable
                                                        //                                                      _mainWindowClrObjExp.AddStatusMsg($" {nDepth}  {typeTarget.Name}  {curIntface.Name}");
                                                    }
                                                    if (curIntface.Name == typeTarget.Name)
                                                    {
                                                        if (nDepth >= 0)
                                                        {
                                                            lstTypesTarget.Add(testType);
                                                            break;
                                                        }
                                                    }
                                                    nDepth++;
                                                    curIntface = curIntface.BaseInterface;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (curType.Name == typeTarget.Name)
                                            {
                                                lstTypesTarget.Add(testType);
                                                break;
                                            }
                                        }
                                        curType = curType.BaseType;
                                    }
                                }
                                var qI = from atype in lstTypesTarget
                                         let InstanceCount = _clrUtil.GetObjectsOfType(atype.Name).Count
                                         select new
                                         {
                                             _type = atype,
                                             atype.Name,
                                             InstanceCount
                                         };
                                var brI = new BrowsePanel(qI);
                                _mainWindowClrObjExp.AddItemsToContextMenu(brI, "_type");
                                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem(InheritOrImplement, $"Type that {InheritOrImplement}s {typeTarget.Name}");
                                tabItem.Content = brI;
                            }
                        }
                    }
                    br.BrowseList.ContextMenu.AddMenuItem((_, __) =>
                    {
                        try
                        {
                            DoInheritOrImplement("Inherit");
                        }
                        catch (Exception ex)
                        {
                            _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                        }
                    }, "SubSnapshot Inheritors", "Get all Types inherit from selected item to new tab", InsertPos: 0);
                    br.BrowseList.ContextMenu.AddMenuItem((_, __) =>
                    {
                        try
                        {
                            DoInheritOrImplement("Implement");
                        }
                        catch (Exception ex)
                        {
                            _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                        }
                    }, "SubSnapshot Implementors", "Get all Types that implement selected item to new tab", InsertPos: 0);


                    dpTypes.Children.Add(br);
                    br.BrowseList.SelectionChanged += (om, em) =>
                    {
                        try
                        {
                            BrowseList lv = om as BrowseList;
                            if (lv != null && lv.SelectedItems.Count == 1)
                            {
                                var selectedItem = lv.SelectedItems[0];
                                var typeDesc = TypeDescriptor.GetProperties(selectedItem)["_type"];
                                var typeSelected = (ClrType)typeDesc.GetValue(selectedItem);
                                dpLabel.Children.Clear();
                                dpLabel.Children.Add(new TextBlock() { Text = $"{typeSelected.Name}" });

                                {
                                    var queryData = from atype in lstAllTypes
                                                    where atype.Name == typeSelected.Name
                                                    let TypeCount = _clrUtil.GetObjectsOfType(atype.Name).Count
                                                    select new
                                                    {
                                                        _type = atype,
                                                        atype.Name,
                                                        BaseType = atype.BaseType == null ? "" : atype.BaseType.Name,
                                                        TypeCount,
                                                        atype.IsFinalizable,
                                                        MetadataToken = atype.MetadataToken.ToString("x8"),
                                                        atype.IsCollectible,
                                                        ElementType = atype.ElementType.ToString(),
                                                        atype.IsArray,
                                                        atype.ComponentSize,
                                                        atype.StaticSize,
                                                        atype.IsValueType,
                                                        atype.IsObjectReference,
                                                        atype.IsPublic,
                                                        atype.IsPrivate,
                                                        atype.IsInternal,
                                                        atype.IsProtected,
                                                        atype.IsAbstract,
                                                        atype.IsSealed,
                                                        atype.IsInterface,
                                                        atype.Module,
                                                    };
                                    dpData.Children.Clear();
                                    dpData.Children.Add(new BrowsePanel(queryData, ShowFilter: false));
                                }
                                var qmethds = from meth in typeSelected.Methods
                                              select new
                                              {
                                                  MethodName = meth.Name,
                                                  meth.Signature,
                                                  CompilationType = meth.CompilationType.ToString(),
                                                  MethodDesc = meth.MethodDesc.ToString("x16"),
                                                  NativeCode = meth.NativeCode.ToString("x16"),
                                                  MetadataToken = meth.MetadataToken.ToString("x8"),
                                                  meth.IsStatic,
                                                  meth.IsPInvoke,
                                                  meth.IsPublic,
                                                  meth.IsPrivate,
                                                  meth.IsInternal,
                                                  meth.IsProtected,
                                              };
                                var brMethods = new BrowsePanel(qmethds, ShowFilter: false);
                                dpMethods.Children.Clear();
                                dpMethods.Children.Add(brMethods);
                                var qFields = from fld in typeSelected.Fields
                                              select new
                                              {
                                                  FieldName = fld.Name,
                                                  Type = fld.Type?.Name,
                                                  fld.Offset,
                                                  fld.Size,
                                                  fld.ElementType,
                                                  fld.IsPrimitive,
                                                  fld.IsValueType,
                                                  fld.IsObjectReference,
                                                  fld.IsPublic,
                                                  fld.IsPrivate,
                                                  fld.IsInternal,
                                                  fld.IsProtected,
                                              };
                                var brFields = new BrowsePanel(qFields, ShowFilter: false);
                                dpFields.Children.Clear();
                                dpFields.Children.Add(brFields);

                                var qStatFlds = from fld in typeSelected.StaticFields
                                                select new
                                                {
                                                    StaticFieldName = fld.Name,
                                                    Type = fld.Type?.Name,
                                                    fld.Size,
                                                    fld.ElementType,
                                                    fld.IsPrimitive,
                                                    fld.IsValueType,
                                                    fld.IsObjectReference,
                                                    fld.IsPublic,
                                                    fld.IsPrivate,
                                                    fld.IsInternal,
                                                    fld.IsProtected,
                                                };
                                var brStatFlds = new BrowsePanel(qStatFlds, ShowFilter: false);
                                brStatFlds.BrowseList.ContextMenu.AddMenuItem((_, __) =>
                                {
                                    try
                                    {
                                        if (brStatFlds.BrowseList.SelectedItems.Count == 1)
                                        {
                                            var selectedItem = brStatFlds.BrowseList.SelectedItems[0];
                                            var statFldName = (string)TypeDescriptor.GetProperties(selectedItem)["StaticFieldName"].GetValue(selectedItem);
                                            var fld = typeSelected.GetStaticFieldByName(statFldName);
                                            var objValue= ((ClrStaticField)fld).ReadObject(ClrUtil.g_ClrUtil.clrRuntime.AppDomains[0]);
                                            ObjRefView.MakeObjRefTree(_clrUtil, objValue, _mainWindowClrObjExp);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                                    }
                                }, "References","Show references of this Static field if it's an object",InsertPos:0);
                                dpStatFields.Children.Clear();
                                dpStatFields.Children.Add(brStatFlds);

                                dpHier.Children.Clear();
                                var tv = new MyTreeViewBase();
                                dpHier.Children.Add(tv);
                                var typ = typeSelected;
                                ItemsControl parentitem = tv;
                                while (true)
                                {
                                    var intfaces = string.Empty;
                                    foreach (var intface in typ.EnumerateInterfaces())
                                    {
                                        intfaces += string.IsNullOrEmpty(intfaces) ? ": " : ", ";
                                        var baseintfce = string.Empty;
                                        if (intface.BaseInterface != null)
                                        {
                                            baseintfce = $"({intface.BaseInterface.Name})";
                                        }
                                        intfaces += $"{intface.Name}{baseintfce}";
                                    }
                                    var hdr = new StackPanel() { Orientation = Orientation.Horizontal };
                                    hdr.Children.Add(new TextBlock() { Text = typ.Name });
                                    if (!string.IsNullOrEmpty(intfaces))
                                    {
                                        hdr.Children.Add(new TextBlock() { Text = intfaces, Foreground = Brushes.DarkCyan });
                                    }
                                    var childItem = new MyTreeViewItem()
                                    {
                                        Header = hdr,
                                        IsExpanded = true
                                    };
                                    parentitem.Items.Add(childItem);
                                    if (typ.Name == "System.Object")
                                    {
                                        break;
                                    }
                                    typ = typ.BaseType;
                                    parentitem = childItem;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                        }
                    };
                }
            }
        }
    }
}
