﻿//Desc: Show objs that have finalizers and GC.SuppressFinalizer
//Desc: search for "public void Dispose" to find Types that call GC.SuppressFinalize but there is no finalize.
//Desc: e.g. InstanceBuilderContextBase.cs https://devdiv.visualstudio.com/DevDiv/_git/VS?path=/src/Xaml/Designer/Source/Designer/InstanceBuilders/InstanceBuilderContextBase.cs&_a=contents&version=GBmain
//Include: ..\util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.Xaml.dll
// problem:ClrMD says "MS.Internal.Text.TextInterface.Generics.NativeIUnknownWrapper<MS::Internal::Text::TextInterface::Native::IDWriteFont>" is not finalizable, but it has a finalizer: System.Runtime.InteropServices.CriticalHandle.Finalize()

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }
        private void DoMainInternal()
        {
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <DockPanel x:Name = ""dpSummary"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""4""/>
    <DockPanel x:Name = ""dpFinalize"" Grid.Row = ""1"" Grid.Column = ""2""/>
</Grid>
";
            var strReader = new System.IO.StringReader(strxaml);
            var xamlreader = XmlReader.Create(strReader);
            var grid = (Grid)(XamlReader.Load(xamlreader));
            var dpFinalize = (DockPanel)grid.FindName("dpFinalize");
            var dpSummary = (DockPanel)grid.FindName("dpSummary");
            try
            {
                var lstFinalize = new List<ClrObject>();
                using (var progress = new ProgressOwnUI<string>($"Finding Finalize Objects"))
                {
                    foreach (var clrobjType in _clrUtil.EnumerateObjectTypes())
                    {
                        var lstObjs = _clrUtil.GetObjectsOfType(clrobjType);
                        var oneObjOfType = lstObjs[0];
                        var ptype = oneObjOfType.Type;
                        if (ptype.Name == "Free")
                        {
                            continue;
                        }
                        var btypeName = ptype?.BaseType?.Name;
                        foreach (var obj in lstObjs)
                        {
                            var IsSuppressed = ptype.IsFinalizeSuppressed(obj.Address);
                            if (IsSuppressed)
                            {
                                lstFinalize.Add(obj);
                            }
                        }
                    }
                }
                var q = from obj in lstFinalize
                        select new
                        {
                            _clrobj = obj,
                            Address = obj.GetAddressAsString(),
                            Type = obj.Type.Name,
                            Obj = obj.GetObjectDisplayValue()
                        };
                var brObjs = new BrowsePanel(q);
                dpFinalize.Children.Add(brObjs);
                AddItemsToContextMenu(brObjs);

                var qSummary = from obj in lstFinalize
                               group obj by obj.Type
                               into grp
                               select new
                               {
                                   Type = grp.Key.Name,
                                   grp.Key.IsFinalizable,
                                   Count = grp.Count()
                               };
                var brSummary = new BrowsePanel(qSummary);
                dpSummary.Children.Add(brSummary);
                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("Finalize", $"{_clrUtil._dumpFileName}");
                tabItem.Content = grid;
            }
            catch (Exception ex)
            {
                _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
            }
        }
    }
    public class MyDisposeControl : UserControl
    {
        public MyDisposeControl()
        {
            this.DataContext = this;

        }
    }
}
