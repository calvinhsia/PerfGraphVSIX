﻿//Desc: Enumerate all types and show Statics

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: ..\util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;


namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            using (var _progress = new ProgressOwnUI<string>("Getting all types"))
            {
                var lstStatFields = new List<ClrStaticField>();
                // for generics, these types only show generic params, like "List<T>", and not "List<int>"
                _clrutil.clrRuntime.EnumerateTypes((type) =>
                {
                    if (type.StaticFields != null)
                    {
                        lstStatFields.AddRange(type.StaticFields);
                    }
                    return true; // keep enumerating
                });
                var query = from statFld in lstStatFields
                            select new
                            {
                                statFld.Name,
                                Type = statFld.Type?.Name,
                                Module = statFld.Type?.Module?.Name
                            };
                var br = new BrowsePanel(query);
                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("StaticFields", $"");
                tabItem.Content = br;
            }
        }
    }
}
