﻿//Desc: Show System.Xml.Linq.XAttribute

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: ..\util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using ClrLib;
using ClrObjExplorer;
using Utility;


namespace ClrObjExtension
{
    public class MyMainClass: BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var typeToFind = "System.Xml.Linq.XAttribute";
            using (var _progress = new ProgressOwnUI<string>($"Finding {typeToFind}"))
            {
                _progress.Report($"Finding {typeToFind}");
                var objs = _clrUtil.GetObjectsOfType(typeToFind);
                if (objs.Count > 0)
                {
                    var q = from obj in objs
                            select new
                            {
                                Addr = obj.GetAddressAsString(),
                                Name = obj.GetObjectMember("name").GetObjectDisplayValue("localName"),
                            };
                    var br = new BrowsePanel(q);
                    var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("XAttribut", $"{typeToFind}");
                    tabItem.Content = br;
                }
            }
        }
    }
}
