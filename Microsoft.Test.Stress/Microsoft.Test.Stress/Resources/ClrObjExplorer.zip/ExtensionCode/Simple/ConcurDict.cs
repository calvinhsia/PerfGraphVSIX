﻿//Desc: Extension Sample
//Desc: Shows how to find types, display selected members of ConcurrentDictionary

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: ..\util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Xml;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;


namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }
        /*
Children of '-- System.Collections.Concurrent.ConcurrentDictionary<Microsoft.VisualStudio.RpcContracts.Logging.LogId, System.Collections.Concurrent.ConcurrentBag<System.Diagnostics.TraceSource>> 000001cb`863ae468'
-- System.Collections.Concurrent.ConcurrentDictionary<Microsoft.VisualStudio.RpcContracts.Logging.LogId, System.Collections.Concurrent.ConcurrentBag<System.Diagnostics.TraceSource>> 000001cb`863ae468
 -> m_tables = System.Collections.Concurrent.ConcurrentDictionary<Microsoft.VisualStudio.RpcContracts.Logging.LogId, System.Collections.Concurrent.ConcurrentBag<System.Diagnostics.TraceSource>>+Tables 000001ca`8877b0a0
  -> m_buckets = System.Collections.Concurrent.ConcurrentDictionary<Microsoft.VisualStudio.RpcContracts.Logging.LogId, System.Collections.Concurrent.ConcurrentBag<System.Diagnostics.TraceSource>>+Node[] 000001ca`8877a360
   -> System.Collections.Concurrent.ConcurrentDictionary<Microsoft.VisualStudio.RpcContracts.Logging.LogId, System.Collections.Concurrent.ConcurrentBag<System.Diagnostics.TraceSource>>+Node 000001ca`8877a9d8
    -> m_key.<LogName>k__BackingField = System.String 000001cb`86b84f28 Microsoft.VisualStudio.Setup.EnvironmentConfigurationService.1.0.BrokeredService Microsoft.VisualStudio.Setup.EnvironmentConfigurationService.1.0.BrokeredService
    -> m_key.<ServiceId>k__BackingField = Microsoft.ServiceHub.Framework.ServiceMoniker 000001ca`87962080
    -> m_value = System.Collections.Concurrent.ConcurrentBag<System.Diagnostics.TraceSource> 000001cb`86b87238
   -> System.Collections.Concurrent.ConcurrentDictionary<Microsoft.VisualStudio.RpcContracts.Logging.LogId, System.Collections.Concurrent.ConcurrentBag<System.Diagnostics.TraceSource>>+Node 000001ca`8877a9a0
    -> m_key.<LogName>k__BackingField = System.String 000001ca`87eeee88 Microsoft.VisualStudio.TraceHubCommand.1.0.BrokeredService Microsoft.VisualStudio.TraceHubCommand.1.0.BrokeredService
    -> m_key.<ServiceId>k__BackingField = Microsoft.ServiceHub.Framework.ServiceMoniker 000001cb`87b8bef0
    -> m_value = System.Collections.Concurrent.ConcurrentBag<System.Diagnostics.TraceSource> 000001ca`87ef0e30
   -> System.Collections.Concurrent.ConcurrentDictionary<Microsoft.VisualStudio.RpcContracts.Logging.LogId, System.Collections.Concurrent.ConcurrentBag<System.Diagnostics.TraceSource>>+Node 000001ca`8877aa80
    -> m_key.<LogName>k__BackingField = System.String 000001ca`8869b580 Microsoft.VisualStudio.LanguageServices.ProcessTelemetry64.BrokeredClient Microsoft.VisualStudio.LanguageServices.ProcessTelemetry64.BrokeredClient
    -> m_key.<ServiceId>k__BackingField = Microsoft.ServiceHub.Framework.ServiceMoniker 000001cb`881fa708
    -> m_value = System.Collections.Concurrent.ConcurrentBag<System.Diagnostics.TraceSource> 000001ca`8869d920
         */
        private void DoMainInternal()
        {
            var typeToFind = "System.Collections.Concurrent.ConcurrentDictionary<Microsoft.VisualStudio.RpcContracts.Logging.LogId, System.Collections.Concurrent.ConcurrentBag<System.Diagnostics.TraceSource>>";
            typeToFind = "System.Collections.Concurrent.ConcurrentDictionary<Microsoft.VisualStudio.RpcContracts.Logging.LogId, System.Collections.Concurrent.ConcurrentBag<System.Diagnostics.TraceSource>>+Node";
            using (var _progress = new ProgressOwnUI<string>($"Finding {typeToFind}"))
            {
                _progress.Report($"Finding {typeToFind}");
                var objs = _clrUtil.GetObjectsOfType(typeToFind);
                if (objs.Count > 0)
                {
                    var q = from obj in objs
                            let Key = obj.TryGetObjectFieldex("m_key")
                            select new
                            {
                                Addr = obj.GetAddressAsString(),
                                Type = obj.GetObjectDisplayValue(),
                                Key,
                                LogName = Key.ReadObjectField("<LogName>k__BackingField").GetObjectDisplayValue()
                            };
                    //var q = from obj in objs
                    //        let Tables = obj.GetObjectMember("m_tables")
                    //        let Buckets = Tables.GetObjectMember("m_buckets")
                    //        select new
                    //        {
                    //            Addr = obj.GetAddressAsString(),
                    //            Type= obj.GetObjectDisplayValue(),
                    //            Tables,
                    //            Buckets
                    //        };
                    var br = new BrowsePanel(q);
                    var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("ConcurDict", $"{typeToFind}");
                    tabItem.Content = br;
                }
            }
        }
    }
}
