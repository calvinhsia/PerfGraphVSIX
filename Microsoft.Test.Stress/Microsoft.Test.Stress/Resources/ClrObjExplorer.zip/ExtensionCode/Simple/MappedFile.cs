﻿//Desc: Show Mapped File information for Roslyn

//Include: ..\util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;


namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }

        public MyMainClass(object[] args) : base(args) { }
        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("MappedFile", $"{_clrUtil._dumpFileName}");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }

        public class MyUserControl : UserControl
        {
            MyMainClass _MyMainClass;
            MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
            ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
            public uint SizeLimitOfDumpView { get; set; } = 1024 * 1024;
            public List<string> MapViewTypes { get; set; } = new List<string>()
                {
                    "Microsoft.CodeAnalysis.Serialization.SerializerService+SerializedMetadataReference",
                    "Microsoft.Windows.CsWin32.MetadataIndex",
                    "ViewAccessor",
                };
            public MyUserControl(MyMainClass myMainClass)
            {
                _MyMainClass = myMainClass;
                this.DataContext = this;
            }
            public void Initialize()
            {
                // Make a namespace referring to our namespace and assembly
                // using the prefix "l:"
                //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
                var nameSpace = this.GetType().Namespace;
                var asm = System.IO.Path.GetFileNameWithoutExtension(
                    Assembly.GetExecutingAssembly().Location);

                var xmlns = string.Format(
    @"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
                //there are a lot of quotes (and braces) in XAML
                //and the C# string requires quotes to be doubled
                var strxaml =
    @"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
    @" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <StackPanel Orientation=""Horizontal"">
        <ComboBox x:Name=""cboMapviewTypes"" ItemsSource=""{Binding MapViewTypes}"" IsEditable=""false"" Width = ""500""/>
        <Label Content =""SizeLimitOfDumpView""/>
        <TextBox Text = ""{Binding SizeLimitOfDumpView}"" Width = ""200"" ToolTip=""Limit the size of the raw dump of the memory region""/>
        <Button Content=""_Go"" x:Name = ""btnGo""/>
    </StackPanel>
    <DockPanel x:Name = ""dpMappedViews"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""4"" Background=""LightBlue""/>
        <Grid Grid.Row = ""1""  Grid.Column = ""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""30""/>
                <RowDefinition Height = ""400""/>
                <RowDefinition Height = ""3""/>
                <RowDefinition Height = ""20""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbTotals""/>
            <DockPanel x:Name = ""dpSummary"" Grid.Row = ""1""/>
            <GridSplitter Grid.Row = ""2"" VerticalAlignment=""Center"" HorizontalAlignment=""Stretch"" Height = ""3"" Background=""LightBlue""/>
            <TextBox x:Name = ""tbMemoryLabel"" Grid.Row=""3"" />
            <TextBox x:Name = ""tbMemory"" FontFamily=""Consolas"" Grid.Row=""4"" HorizontalAlignment=""Stretch"" VerticalScrollBarVisibility=""Auto"" HorizontalScrollBarVisibility=""Auto"" />
        </Grid>
</Grid>
";

                try
                {
                    var grid = (Grid)(XamlReader.Parse(strxaml));
                    this.Content = grid;
                    var cboMapviewTypes = (ComboBox)grid.FindName("cboMapviewTypes");
                    cboMapviewTypes.SelectedIndex = 0;
                    var dpLabel = (DockPanel)grid.FindName("dpLabel");
                    var dpMappedViews = (DockPanel)grid.FindName("dpMappedViews");
                    var tbTotals = (TextBox)grid.FindName("tbTotals");
                    var dpSummary = (DockPanel)grid.FindName("dpSummary");
                    var tbMemoryLabel = (TextBox)grid.FindName("tbMemoryLabel");
                    var tbMemory = (TextBox)grid.FindName("tbMemory");
                    var btnGo = (Button)grid.FindName("btnGo");
                    ulong lSizeMappedFilesTotal = 0;
                    uint nMappedFilesTotal = 0;
                    var allocGran = IntPtr.Size == 4 ? 65536u : 65536u; // SYSTEM_INFO si;GetSystemInf(&si); both 32 & 64 == 65536
                    var dictMappedFileBlame = new Dictionary<string, MappedFileSummary>();
                    var dictmappedViews = new Dictionary<ulong, MappedViewData>();
                    btnGo.Click += (_, __) =>
                    {
                        try
                        {
                            dictmappedViews.Clear();
                            dictMappedFileBlame.Clear();
                            lSizeMappedFilesTotal = 0;
                            nMappedFilesTotal = 0;
                            dpMappedViews.Children.Clear();
                            tbMemory.Text = string.Empty;
                            tbMemoryLabel.Text = string.Empty;
                            BrowsePanel br = null;
                            MappedViewData GotMappedView(ClrObject mview) // System.IO.MemoryMappedFiles.MemoryMappedView
                            {

                                var sizeSpecified = mview.GetFieldValue<long>("^[m]?_size", IsRegex: true);

                                var viewHandle = mview.GetObjectMember("^[m]?_viewHandle", IsRegex: true); //Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle
                                var ViewOffset = mview.GetFieldValue<long>("^[m]?_pointerOffset", IsRegex: true);
                                var handle = viewHandle.GetFieldValue<IntPtr>("handle");
                                var sizeUsed = handle == IntPtr.Zero ? 0 : sizeSpecified;
                                var numRegions = (sizeUsed + allocGran - 1) / allocGran; // 65536 => 1 region
                                var sizeConsumed = (ulong)numRegions * allocGran;
                                lSizeMappedFilesTotal += sizeConsumed;
                                nMappedFilesTotal++;
                                var newData = new MappedViewData()
                                {
                                    SizeConsumed = sizeConsumed,
                                    SizeUsed = (ulong)sizeUsed,
                                    ViewAddress = (ulong)handle.ToInt64(),
                                    ViewOffset = (ulong)ViewOffset,
                                };
                                dictmappedViews[mview.Address] = newData;
                                return newData;
                            }
                            if (cboMapviewTypes.Text == "ViewAccessor") // from viewaccessor, try to go up ref tree to find data
                            {
                                using (var progress = new ProgressOwnUI<string>($"Finding MappedFile Views"))
                                {
                                    foreach (var mapViewType in new[] { "System.IO.MemoryMappedFiles.MemoryMappedViewAccessor", "System.IO.MemoryMappedFiles.MemoryMappedViewStream" })
                                    {
                                        var oMappedViews = this._clrUtil.GetObjectsOfType(mapViewType);
                                        foreach (var oMappedView in oMappedViews)
                                        {
                                            var mview = oMappedView.GetObjectMember("^[m]?_view", IsRegex: true); // System.IO.MemoryMappedFiles.MemoryMappedView
                                            var mapData = GotMappedView(mview);
                                            // now we want to get the chain of parents
                                            var blameChain = string.Empty;
                                            var lstParentChain = DoQueryForParents(oMappedView);
                                            var filename = string.Empty;
                                            foreach (var ancestor in lstParentChain)
                                            {
                                                if (ancestor.Type.Name == "Microsoft.CodeAnalysis.Serialization.SerializerService+SerializedMetadataReference")
                                                {
                                                    var oFilename = ancestor.GetObjectMember("_filePath");
                                                    if (oFilename.IsValid)
                                                    {
                                                        filename = oFilename.GetObjectDisplayValue();
                                                        break;
                                                    }
                                                }
                                            }
                                            var blame = lstParentChain[0].Type.Name; // guaranteed to be at least one
                                            lstParentChain.ForEach((s) =>
                                            {
                                                if (!string.IsNullOrEmpty(blameChain))
                                                {
                                                    blameChain += ';';
                                                }
                                                blameChain += s.Type.Name;
                                            });
                                            mapData.clrobjView = oMappedView;
                                            mapData.Blame = blame;
                                            //var strHandle = MyAddrFormatter.AddrFormat($"{handle:x}");
                                            //this.clrUtil.LogString($"{oMappedView.GetAddressAsString()}  {oMappedView.GetTypeName()}  {strHandle}  {size.ToString()} {blame} {blameChain}");
                                            if (!dictMappedFileBlame.TryGetValue(blame, out var mappedFileSummary))
                                            {
                                                dictMappedFileBlame[blame] = new MappedFileSummary()
                                                {
                                                    Blame = blame,
                                                    AdditionalInfo = blameChain,
                                                    size = mapData.SizeConsumed,
                                                    count = 1
                                                };
                                            }
                                            else
                                            {
                                                mappedFileSummary.size += mapData.SizeConsumed;
                                                mappedFileSummary.count++;
                                            }
                                        }
                                    }
                                }
                                var q = from view in dictmappedViews.Values
                                        select new
                                        {
                                            _clrobj = view.clrobjView,
                                            _MappedViewData = view,
                                            Address = view.clrobjView.GetAddressAsString(),
                                            ViewAddress = MyAddrFormatter.AddrFormat($"{view.ViewAddress:x}"),
                                            view.ViewOffset,
                                            view.SizeConsumed,
                                            view.SizeUsed,
                                            view.Blame
                                        };
                                br = new BrowsePanel(q, colWidths: new[] { 90, 90, 90, 10, 90, 90, 100 });
                            }
                            else
                            {
                                int cntOutput = 0;
                                var typMetaData = cboMapviewTypes.Text;
                                using (var progress = new ProgressOwnUI<string>($"Finding {typMetaData}"))
                                {
                                    var fCSWin32 = typMetaData.Contains("Microsoft.Windows.CsWin32");
                                    var oMetaDatas = _clrUtil.GetObjectsOfType(typMetaData);
                                    foreach (var oMetaData in oMetaDatas)
                                    {
                                        if (fCSWin32)
                                        {
                                            /*
                                             * 
                                             * https://github.com/microsoft/CsWin32/blob/e525c05f27f4c62d022ea7706c8ec8fbae1a3573/src/Microsoft.Windows.CsWin32/MetadataIndex.cs#L21
                                             * 
Children of '-- Microsoft.Windows.CsWin32.MetadataIndex 000001a5`94b8bdb0'
-- Microsoft.Windows.CsWin32.MetadataIndex 000001a5`94b8bdb0
 -> metadataPath = System.String 000001a5`87bbb4c0 C:\Users\alexfi\.nuget\packages\microsoft.windows.sdk.win32metadata\17.0.2-preview\buildTransitive\..\Windows.Win32.winmd C:\Users\alexfi\.nuget\packages\microsoft.windows.sdk.win32metadata\17.0.2-preview\buildTransitive\..\Windows.Win32.winmd
 -> metadataStream = System.IO.FileStream 000001a5`94b8c028
 -> peReader = System.Reflection.PortableExecutable.PEReader 000001a5`94b8c198
  -> _lazyMetadataBlock = System.Reflection.Internal.MemoryMappedFileBlock 000001a5`94b8d590
   -> _data = System.Reflection.Internal.MemoryMappedFileBlock+DisposableData 000001a5`94b8d5b0
    -> _accessor = System.IO.MemoryMappedFiles.MemoryMappedViewAccessor 000001a5`94b8d558
     -> _buffer = Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle 000001a5`94b8d500
     -> m_view = System.IO.MemoryMappedFiles.MemoryMappedView 000001a5`94b8d528
    -> _safeBuffer = Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle 000001a5`94b8d500
  -> _lazyPEHeaders = System.Reflection.PortableExecutable.PEHeaders 000001a5`94b8c228
  -> _peImage = System.Reflection.Internal.StreamMemoryBlockProvider 000001a5`94b8c1d8
 -> mr = System.Reflection.Metadata.MetadataReader 000001a5`94b8d5d8
 -> apis = System.Collections.Generic.List<System.Reflection.Metadata.TypeDefinition> 000001a5`94b8bec8
 -> releaseMethods = System.Collections.Generic.HashSet<System.String> 000001a5`94b8bf08
 -> handleTypeStructsWithIntPtrSizeFields = System.Collections.Generic.HashSet<System.String> 000001a5`94b8bf48
 -> handleTypeReleaseMethod = System.Collections.Generic.Dictionary<System.Reflection.Metadata.TypeDefinitionHandle, System.String> 000001a5`94b8bf88
 -> <MetadataByNamespace>k__BackingField = System.Collections.Generic.Dictionary<System.String, Microsoft.Windows.CsWin32.NamespaceMetadata> 000001a5`94b8bfd8
 -> <CommonNamespace>k__BackingField = System.String 000001a5`95ac4ca8 Windows.Win32 Windows.Win32
 -> <CommonNamespaceDot>k__BackingField = System.String 000001a5`95ac4c70 Windows.Win32. Windows.Win32.

                                             */
                                            var filename = oMetaData.GetObjectMember("metadataPath").GetObjectDisplayValue();
                                            var accessor = oMetaData.GetObjectMember("peReader")
                                                    .GetObjectMember("_lazyMetadataBlock")
                                                    .GetObjectMember("_data")
                                                    .GetObjectMember("^[m]?_accessor", IsRegex: true);
                                            var mview = accessor.GetObjectMember("^[m]?_view", IsRegex: true);
                                            if (mview.IsValid)
                                            {
                                                var mapData = GotMappedView(mview);
                                                mapData.FileName = filename;
                                                mapData.clrobjView = accessor;
                                            }
                                        }
                                        else
                                        {
                                            var filename = oMetaData.GetObjectMember("_filePath").GetObjectDisplayValue();
                                            var metadata = oMetaData.GetObjectMember("_metadata");
                                            bool DoMetaDataProc(ClrObject oChildMeta)
                                            {
                                                oChildMeta.EnumerateRefsOfObject((ochild) =>
                                                {
                                                    if (ochild.Type.Name == "Microsoft.CodeAnalysis.Host.TemporaryStorageServiceFactory+MemoryMappedInfo+SharedReadableStream")
                                                    {
                                                        var accessor = ochild.GetObjectMember("_accessor"); //Roslyn.Utilities.ReferenceCountedDisposable<System.IO.MemoryMappedFiles.MemoryMappedViewAccessor>
                                                        if (accessor.IsValid)
                                                        {
                                                            var instance = accessor.GetObjectMember("_instance"); //System.IO.MemoryMappedFiles.MemoryMappedViewAccessor
                                                            if (instance.IsValid)
                                                            {
                                                                var mview = instance.GetObjectMember("^[m]?_view", IsRegex: true); // System.IO.MemoryMappedFiles.MemoryMappedView
                                                                var mapdata = GotMappedView(mview);
                                                                mapdata.clrobjView = instance;
                                                                mapdata.FileName = filename;
                                                                return false;// don't continue
                                                            }
                                                        }
                                                    }
                                                    return true; // continue 
                                                });
                                                return true; // continue 
                                            }
                                            try
                                            {
                                                var initialmodules = metadata.ReadValueTypeField("_initialModules"); // Field does not have an associated class.
                                                var array = initialmodules.ReadObjectField("array");
                                                array.EnumerateRefsOfObject((oChildMeta) =>
                                                {
                                                    return DoMetaDataProc(oChildMeta);
                                                });
                                            }
                                            catch (InvalidOperationException ex)
                                            {
                                                metadata.EnumerateRefsOfObject((oChildMeta) =>
                                                {
                                                    if (oChildMeta.Type.Name == "Microsoft.CodeAnalysis.ModuleMetadata[]")
                                                    {
                                                        oChildMeta.EnumerateRefsOfObject((oelem) =>
                                                        {
                                                            if (cntOutput++ < 10)
                                                            {
                                                                _mainWindowClrObjExp.AddStatusMsg($"Enum {oelem.GetObjectDisplayValue()} {oChildMeta.Type.Name} {ex.Message}");
                                                            }
                                                            return DoMetaDataProc(oelem);
                                                        });
                                                        return false;
                                                    }
                                                    return true; // continue 
                                                });

                                            }
                                        }
                                    }
                                }
                                var q = from view in dictmappedViews.Values
                                        select new
                                        {
                                            _clrobj = view.clrobjView,
                                            _MappedViewData = view,
                                            Address = view.clrobjView.GetAddressAsString(),
                                            ViewAddress = MyAddrFormatter.AddrFormat($"{view.ViewAddress:x}"),
                                            view.ViewOffset,
                                            view.SizeConsumed,
                                            view.SizeUsed,
                                            view.FileName,
                                        };
                                br = new BrowsePanel(q);
                            }
                            br.BrowseList.ContextMenu.AddMenuItem((_, __) =>
                            {
                                try
                                {
                                    if (br.BrowseList.SelectedItems.Count > 1)
                                    {
                                        var cts = new CancellationTokenSource();
                                        using (var progress = new ProgressOwnUI<string>($"Comparing memory of views", cts: cts, delayStart: true))
                                        {
                                            MappedViewData firstMappedData = null;
                                            foreach (var item in br.BrowseList.SelectedItems)
                                            {
                                                var oMappedViewData = (MappedViewData)(TypeDescriptor.GetProperties(item)["_MappedViewData"]).GetValue(item);
                                                if (firstMappedData == null)
                                                {
                                                    firstMappedData = oMappedViewData;
                                                }
                                                else
                                                {
                                                    var diffOffset = oMappedViewData.CompareMemoryWith(firstMappedData);
                                                    if (diffOffset != ulong.MaxValue)
                                                    {
                                                        _mainWindowClrObjExp.AddStatusMsg($"Memory Content different at offset 0x{diffOffset:x8}: {firstMappedData} {oMappedViewData}");
                                                    }
                                                    else
                                                    {
                                                        _mainWindowClrObjExp.AddStatusMsg($"Memory Content identical {firstMappedData} {oMappedViewData}");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                                }
                            }, "Compare memory of selected items", "First selected item is compared with the rest, so selection order is important", InsertPos: 0);
                            _MyMainClass.AddItemsToContextMenu(br);
                            br.BrowseList.SelectionChanged += (_, __) =>
                            {
                                try
                                {
                                    tbMemoryLabel.Text = string.Empty;
                                    tbMemory.Text = string.Empty;
                                    if (br.BrowseList.SelectedItems.Count == 1)
                                    {
                                        var selectedItem = br.BrowseList.SelectedItems[0];
                                        var oMappedView = (ClrObject)TypeDescriptor.GetProperties(selectedItem)["_clrobj"].GetValue(selectedItem);
                                        var oMappedViewData = (MappedViewData)(TypeDescriptor.GetProperties(selectedItem)["_MappedViewData"]).GetValue(selectedItem);
                                        if (oMappedViewData.SizeUsed > 0)
                                        {
                                            using (var progress = new ProgressOwnUI<string>($"Getting Memory Dump"))
                                            {
                                                var strDump = ClrUtil.GetMemoryDumpAsString(oMappedViewData.ViewAddress, oMappedViewData.SizeUsed, nMaxDumpSize: SizeLimitOfDumpView);
                                                tbMemory.Text = strDump;
                                            }
                                        }
                                        tbMemoryLabel.Text = MyAddrFormatter.AddrFormat($"View={oMappedView.GetAddressAsString()} ViewAddr = {oMappedViewData.ViewAddress:x} Size ={oMappedViewData.SizeUsed:n0} Offset = {oMappedViewData.ViewOffset:n0} {oMappedViewData.FileName}");
                                    }
                                }
                                catch (Exception ex)
                                {
                                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                                }
                            };
                            dpMappedViews.Children.Add(br);
                            {
                                // now calc summary
                                var q = (from view in dictmappedViews.Values
                                         group view by view.FileName into grp
                                         select new
                                         {
                                             Filename = grp.Key,
                                             Size = (ulong)(grp.Sum(d => (double)d.SizeConsumed)), //error: ambiguous overload, so double
                                             Count = grp.Count()
                                         }).OrderByDescending(d => d.Size);
                                var brSum = new BrowsePanel(q);
                                dpSummary.Children.Clear();
                                dpSummary.Children.Add(brSum);
                                tbTotals.Text = $"Total # files mapped = {nMappedFilesTotal}  Total SizeMapped= {lSizeMappedFilesTotal:n0}";
                            }

                        }
                        catch (Exception ex)
                        {
                            _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                        }
                    };

                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            }
            private List<ClrObject> DoQueryForParents(ClrObject objIdLeaf)
            {
                int nMaxLevels = 20;
                int numImmediateParents = 0;
                var lstParentChain = new List<ClrObject>();
                lstParentChain.Add(objIdLeaf);
                //            Trace.WriteLine($"Looking for Parents of {desc} {objIdLeaf:x8}");
                WalkParentTree(objIdLeaf, 0);
                lstParentChain.Reverse();
                return lstParentChain;
                // we want to walk from leaf node up the parent chain while the parent count ==1.
                // then we want the ref chain list in reverse, from root to leaf
                void WalkParentTree(ClrObject objId, int level)
                {
                    if (level < nMaxLevels)
                    {
                        var indent = new string(' ', 2 * level);
                        var lstParents = objId.GetParentObjectReferences();// (List<uint>)await oop.ClientSendVerb(Verbs.QueryParentOfObject, objId);
                        if (level == 0)
                        {
                            numImmediateParents = lstParents.Count;
                            //this._clrUtil.LogString($"{indent} {objId.Type.Name} #parents= {lstParents.Count}");
                        }
                        if (lstParents.Count == 1)
                        {
                            lstParentChain.Add(lstParents[0]);
                            foreach (var parentObjId in lstParents.Take(10))
                            {
                                //                            Trace.WriteLine($"{indent}  {parentObjId:x8}");
                                WalkParentTree(parentObjId, level + 1);
                            }
                        }
                    }
                }
            }
        }
        class MappedFileSummary
        {
            public string Blame;
            public string AdditionalInfo; // parentchain
            public ulong size;
            public ulong count;
        }
        class MappedViewData
        {
            public ClrObject clrobjView;
            public ulong SizeConsumed;
            public ulong SizeUsed;
            public ulong ViewOffset;
            public ulong ViewAddress;
            public string FileName;
            public string Blame;

            public ulong CompareMemoryWith(MappedViewData Other)
            {
                ulong result = ulong.MaxValue;
                var blkthis = ClrUtil.g_ClrUtil.ReadBytes(ViewAddress, (int)SizeUsed);
                var blkOther = ClrUtil.g_ClrUtil.ReadBytes(Other.ViewAddress, (int)Other.SizeUsed);
                for (ulong ndx = 0; ndx < SizeUsed; ndx++)
                {
                    if (ndx >= Other.SizeUsed || blkthis[ndx] != blkOther[ndx])
                    {
                        result = ndx;
                        break;
                    }
                }
                return result;
            }
            override public string ToString() => MyAddrFormatter.AddrFormat($"{clrobjView.GetAddressAsString()} ViewAddress={ViewAddress:x} Offset={ViewOffset} Size={SizeUsed} {FileName}");
        }
    }
}
