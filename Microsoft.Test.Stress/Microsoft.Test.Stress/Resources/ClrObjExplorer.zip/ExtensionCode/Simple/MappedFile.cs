﻿//Desc: Show Mapped File 

//Include: ..\util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        class MappedFileSummary
        {
            public string Blame;
            public string AdditionalInfo; // parentchain
            public ulong size;
            public ulong count;
        }
        class MappedViewData
        {
            public ClrObject clrobjView;
            public ulong Size;
            public ulong SizeUsed;
            public string Blame;
        }

        public MyMainClass(object[] args) : base(args)
        {

        }
        private void DoMainInternal()
        {
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <DockPanel x:Name = ""dpMappedViews"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""4""/>
        <Grid Grid.Row = ""1""  Grid.Column = ""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""20""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <DockPanel x:Name = ""dpLabel"" Grid.Row=""0"" />
            <DockPanel x:Name = ""dpDisposed"" Grid.Row=""1"" />
        </Grid>
</Grid>
";
            var strReader = new System.IO.StringReader(strxaml);
            var xamlreader = XmlReader.Create(strReader);
            var grid = (Grid)(XamlReader.Load(xamlreader));
            var dpLabel = (DockPanel)grid.FindName("dpLabel");
            var dpMappedViews = (DockPanel)grid.FindName("dpMappedViews");
            var dpDisposed = (DockPanel)grid.FindName("dpDisposed");
            try
            {
                ulong lSizeMappedFilesTotal = 0;
                uint nMappedFilesTotal = 0;
                var allocGran = IntPtr.Size == 4 ? 65536u : 65536u; // SYSTEM_INFO si;GetSystemInf(&si); both 32 & 64 == 65536
                var dictMappedFileBlame = new Dictionary<string, MappedFileSummary>();
                var lstmappedViews = new List<MappedViewData>();
                using (var progress = new ProgressOwnUI<string>($"Finding MappedFile Views"))
                {
                    foreach (var mapViewType in new[] { "System.IO.MemoryMappedFiles.MemoryMappedViewAccessor", "System.IO.MemoryMappedFiles.MemoryMappedViewStream" })
                    {
                        var oMappedViews = this._clrUtil.GetObjectsOfType(mapViewType);

                        foreach (var oMappedView in oMappedViews)
                        {
                            var mview = oMappedView.GetObjectMember("^[m]?_view", IsRegex: true);
                            var sizeSpecified = mview.GetFieldValue<long>("^[m]?_size", IsRegex: true);

                            var viewHandle = mview.GetObjectMember("^[m]?_viewHandle", IsRegex: true); //Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle
                            var handle = viewHandle.GetFieldValue<IntPtr>("handle");
                            var sizeUsed = handle == IntPtr.Zero ? 0 : sizeSpecified;
                            var numRegions = (sizeUsed + allocGran - 1) / allocGran; // 65536 => 1 region
                            var size = (ulong)numRegions * allocGran;
                            lSizeMappedFilesTotal += size;
                            nMappedFilesTotal++;
                            // now we want to get the chain of parents

                            var blameChain = string.Empty;
                            var lstParentChain = DoQueryForParents(oMappedView);
                            //int nIndex = 0;
                            //foreach (var itm in lstParentChain)
                            //{
                            //    var indent = new string(' ', 2 * nIndex++);
                            //    this.clrUtil.LogString($"  {indent} {itm.Type.Name}");
                            //}
                            var blame = lstParentChain[0].Type.Name; // guaranteed to be at least one
                            lstParentChain.ForEach((s) =>
                            {
                                if (!string.IsNullOrEmpty(blameChain))
                                {
                                    blameChain += ';';
                                }
                                blameChain += s.Type.Name;
                            });

                            lstmappedViews.Add(new MappedViewData()
                            {
                                clrobjView = oMappedView,
                                Size = size,
                                SizeUsed = (ulong)sizeUsed,
                                Blame = blameChain
                            });
                            //var strHandle = MyAddrFormatter.AddrFormat($"{handle:x}");
                            //this.clrUtil.LogString($"{oMappedView.GetAddressAsString()}  {oMappedView.GetTypeName()}  {strHandle}  {size.ToString()} {blame} {blameChain}");
                            if (!dictMappedFileBlame.TryGetValue(blame, out var mappedFileSummary))
                            {
                                dictMappedFileBlame[blame] = new MappedFileSummary()
                                {
                                    Blame = blame,
                                    AdditionalInfo = blameChain,
                                    size = size,
                                    count = 1
                                };
                            }
                            else
                            {
                                //mappedFileSummary.size += size;
                                //mappedFileSummary.count++;
                            }
                        }
                    }
                }
                var q = from view in lstmappedViews
                        select new
                        {
                            _clrobj = view.clrobjView,
                            Address = view.clrobjView.GetAddressAsString(),
                            view.Size,
                            view.SizeUsed,
                            view.Blame
                        };
                var br = new BrowsePanel(q);
                AddItemsToContextMenu(br);
                dpMappedViews.Children.Add(br);
                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("MappedFile", $"{_clrUtil._dumpFileName}");
                tabItem.Content = grid;
            }
            catch (Exception ex)
            {
                _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
            }
        }
        private List<ClrObject> DoQueryForParents(ClrObject objIdLeaf)
        {
            int nMaxLevels = 20;
            int numImmediateParents = 0;
            var lstParentChain = new List<ClrObject>();
            lstParentChain.Add(objIdLeaf);
            //            Trace.WriteLine($"Looking for Parents of {desc} {objIdLeaf:x8}");
            WalkParentTreeAsync(objIdLeaf, 0);
            lstParentChain.Reverse();
            return lstParentChain;
            // we want to walk from leaf node up the parent chain while the parent count ==1.
            // then we want the ref chain list in reverse, from root to leaf
            void WalkParentTreeAsync(ClrObject objId, int level)
            {
                if (level < nMaxLevels)
                {
                    var indent = new string(' ', 2 * level);
                    var lstParents = objId.GetParentObjectReferences();// (List<uint>)await oop.ClientSendVerb(Verbs.QueryParentOfObject, objId);
                    if (level == 0)
                    {
                        numImmediateParents = lstParents.Count;
                        //this._clrUtil.LogString($"{indent} {objId.Type.Name} #parents= {lstParents.Count}");
                    }
                    if (lstParents.Count == 1)
                    {
                        lstParentChain.Add(lstParents[0]);
                        foreach (var parentObjId in lstParents.Take(10))
                        {
                            //                            Trace.WriteLine($"{indent}  {parentObjId:x8}");
                            WalkParentTreeAsync(parentObjId, level + 1);
                        }
                    }
                }
            }
        }
    }
    //static class ExtMethods
    //{
    //    /// <summary>
    //    /// .Net 6 has some fields renamed with "_" prefix
    //    /// </summary>
    //    /// <param name="memname">desired field without the '_' prefix</param>
    //    public static string GetMemberNameRegex(this ClrObject clrObj, string memnameRegexPattern)
    //    {
    //        var res = string.Empty;
    //        //            clrObj.Type.Fields.Where(f => f.Name.Contains("componentClass")).First().Name
    //        var flds = clrObj.Type.Fields.Where(f => Regex.IsMatch(f.Name, memnameRegexPattern));
    //        if (flds.Count() == 1)
    //        {
    //            res = flds.First().Name;
    //        }
    //        return res;
    //    }

    //}
}
