﻿//Desc: Show System.Collections.Concurrent and their members

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: ..\util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using System.Reflection.Emit;
using System.Runtime.Remoting.Messaging;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        //        public static string WpfBaseType = "System.Windows.Media.Visual";
        public MyMainClass(object[] args) : base(args) { }
        //Ref64: %VSRoot%\Common7\IDE\PrivateAssemblies\System.Collections.Immutable.dll
        //Ref: c:\Windows\Microsoft.NET\Framework64\v4.0.30319\netstandard.dll

        //class BigStuffWithLongNameSoICanSeeItBetter
        //{
        //    ConcurrentBag<string> bag = new ConcurrentBag<string>();
        //    ConcurrentDictionary<string, string> dict = new ConcurrentDictionary<string, string>();
        //    ConcurrentQueue<string> queue = new ConcurrentQueue<string>();
        //    ConcurrentStack<string> stack = new ConcurrentStack<string>();
        //    ImmutableDictionary<string, string> immdict = ImmutableDictionary<string, string>.Empty;
        //    ImmutableArray<string> immarray = ImmutableArray<string>.Empty;
        //    ImmutableHashSet<string> immhash = ImmutableHashSet<string>.Empty;
        //    ImmutableList<string> immlist = ImmutableList<string>.Empty;
        //    public BigStuffWithLongNameSoICanSeeItBetter()
        //    {
        //        for (int i = 0; i < 100; i++)
        //        {
        //            bag.Add($"Bag {i }");
        //            dict[$"dictkey{i}"] = $"dictval{i}";
        //            queue.Enqueue($"q{i}");
        //            stack.Push($"stack{i}");
        //            immdict = immdict.Add($"dictkey{i}", $"dictval{i}");
        //            immarray = immarray.Add($"arr{i}");
        //            immhash = immhash.Add($"hash{i}");
        //            immlist = immlist.Add($"list{i}");

        //        }
        //    }
        //    byte[] arr = new byte[1024 * 1024];
        //}

        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("Concurrent", $"");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }

        public class MyUserControl : UserControl
        {
            MyMainClass _MyMainClass;
            MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
            ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
            public MyUserControl(MyMainClass myMainClass)
            {
                _MyMainClass = myMainClass;
                this.DataContext = this;
            }
            public void Initialize()
            {
                try
                {
                    // Make a namespace referring to our namespace and assembly
                    // using the prefix "l:"
                    //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
                    var nameSpace = this.GetType().Namespace;
                    var asm = System.IO.Path.GetFileNameWithoutExtension(
                        System.Reflection.Assembly.GetExecutingAssembly().Location);

                    var xmlns = string.Format(
        @"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
                    //there are a lot of quotes (and braces) in XAML
                    //and the C# string requires quotes to be doubled
                    var strxaml =
        @"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
        @" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition/>
    </Grid.ColumnDefinitions>
    <DockPanel x:Name = ""dpConcurrent"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
        <Grid Grid.Row = ""1""  Grid.Column = ""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""20""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <DockPanel x:Name = ""dpLabel"" Grid.Row=""0"" />
            <DockPanel x:Name = ""dpDetails"" Grid.Row=""1"" />
        </Grid>
</Grid>
";
                    var grid = (Grid)(XamlReader.Parse(strxaml));
                    this.Content = grid;
                    var dpLabel = (DockPanel)grid.FindName("dpLabel");
                    var dpConcurrent = (DockPanel)grid.FindName("dpConcurrent");
                    var dpDetails = (DockPanel)grid.FindName("dpDetails");
                    using (var _progress = new ProgressOwnUI<string>("Getting all System.Collections.Concurrent"))
                    {
                        var lstConcurrent = new List<ClrObject>();
                        foreach (var concur in _clrUtil.EnumerateObjectTypes(regexFilter: @"System\.Collections\.Concurrent\.Concurrent(Dictionary|Bag|Queue|Stack)<"))
                        {
                            if (concur.Contains("+") || concur.EndsWith("[]")) // like "+Node", "+ThreadLocalList"
                            {
                                continue;
                            }
                            lstConcurrent.AddRange(_clrUtil.GetObjectsOfType(concur));
                        }
                        var query = from obj in lstConcurrent
                                    let Count = obj.GetCollectionCount()
                                    orderby Count descending
                                    select new
                                    {
                                        _clrobj = obj,
                                        Address = obj.GetAddressAsString(),
                                        Count,
                                        Type = obj.Type.Name,
                                    };

                        var br = new BrowsePanel(query);
                        dpConcurrent.Children.Add(br);
                        _MyMainClass.AddItemsToContextMenu(br);
                        br.BrowseList.SelectionChanged += (om, em) =>
                        {
                            try
                            {
                                BrowseList lv = om as BrowseList;
                                if (lv != null && lv.SelectedItems.Count == 1)
                                {
                                    dpDetails.Children.Clear();
                                    var selectedItem = lv.SelectedItems[0];
                                    var typeDesc = TypeDescriptor.GetProperties(selectedItem)["_clrobj"];
                                    var obj = (ClrObject)typeDesc.GetValue(selectedItem);
                                    var type = obj.Type.Name;
                                    dpLabel.Children.Clear();
                                    dpLabel.Children.Add(new TextBlock() { Text = $"{obj.ToString()}" });
                                    if (obj.Type.Name.StartsWith("System.Collections.Concurrent.ConcurrentBag"))
                                    {
                                        var lstNodes = new List<ClrObject>();
                                        obj.EnumerateCollectionContent((node) =>
                                        {
                                            lstNodes.Add((ClrObject)node);
                                            return true;
                                        }, _mainWindowClrObjExp);

                                        var qchildren = from oNode in lstNodes
                                                        select new
                                                        {
                                                            _clrobj = oNode,
                                                            Address = oNode.GetAddressAsString(),
                                                            Value = oNode.GetObjectDisplayValue()
                                                        };
                                        var brChildren = new BrowsePanel(qchildren);
                                        _MyMainClass.AddItemsToContextMenu(brChildren);
                                        dpDetails.Children.Add(brChildren);
                                    }
                                    else if (obj.Type.Name.StartsWith("System.Collections.Concurrent.ConcurrentQu"))
                                    {
                                        var lstNodes = new List<ClrObject>();
                                        obj.EnumerateCollectionContent((oNode) =>
                                        {
                                            lstNodes.Add((ClrObject)oNode);
                                            return true;
                                        }, _mainWindowClrObjExp);
                                        var qchildren = from oNode in lstNodes
                                                        select new
                                                        {
                                                            _clrobj = oNode,
                                                            Address = oNode.GetAddressAsString(),
                                                            Value = oNode.GetObjectDisplayValue()
                                                        };
                                        var brChildren = new BrowsePanel(qchildren);
                                        _MyMainClass.AddItemsToContextMenu(brChildren);
                                        dpDetails.Children.Add(brChildren);
                                    }
                                    else if (obj.Type.Name.StartsWith("System.Collections.Concurrent.ConcurrentDi"))
                                    {
                                        var lstNodes = new List<ClrObject>();
                                        obj.EnumerateCollectionContent((oNode) =>
                                        {
                                            lstNodes.Add((ClrObject)oNode);
                                            return true;
                                        });
                                        //note: this assumes the key,value are both objects. Fails if valuetype like Struct or Int
                                        var qchildren = from oNode in lstNodes
                                                        let Key = oNode.GetObjectMember("^[m]?_key", IsRegex: true)
                                                        let Value = oNode.GetObjectMember("^[m]?_value", IsRegex: true)
                                                        select new
                                                        {
                                                            _clrobj = oNode,
                                                            Address = oNode.GetAddressAsString(),
                                                            Key = Key.GetObjectDisplayValue(),
                                                            Value = Value.GetObjectDisplayValue()
                                                        };
                                        var brChildren = new BrowsePanel(qchildren);
                                        _MyMainClass.AddItemsToContextMenu(brChildren);
                                        dpDetails.Children.Add(brChildren);
                                    }
                                    else if (obj.Type.Name.StartsWith("System.Collections.Concurrent.ConcurrentStack"))
                                    {
                                        var lstNodes = new List<ClrObject>();
                                        obj.EnumerateCollectionContent((oNode) =>
                                        {
                                            lstNodes.Add((ClrObject)oNode);
                                            return true;
                                        }, _mainWindowClrObjExp);
                                        var qchildren = from oNode in lstNodes
                                                        select new
                                                        {
                                                            _clrobj = oNode,
                                                            Address = oNode.GetAddressAsString(),
                                                            Value = oNode.GetObjectDisplayValue()
                                                        };
                                        var brChildren = new BrowsePanel(qchildren);
                                        _MyMainClass.AddItemsToContextMenu(brChildren);
                                        dpDetails.Children.Add(brChildren);
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                            }
                        };

                    }

                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            }
        }
    }
}