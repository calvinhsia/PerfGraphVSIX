﻿//Desc: Show WPF elements and their contents

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: ..\util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using System.Reflection.Emit;
using System.Runtime.Remoting.Messaging;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        //        public static string WpfBaseType = "System.Windows.Media.Visual";
        public static string WpfBaseType = "System.Windows.DependencyObject";
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            _mainWindowClrObjExp.AddStatusMsg(_clrUtil._dumpFileName);
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                System.Reflection.Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition/>
    </Grid.ColumnDefinitions>
    <DockPanel x:Name = ""dpTypes"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3""/>
        <Grid Grid.Row = ""1""  Grid.Column = ""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""20""/>
                <RowDefinition Height = ""200""/>
                <RowDefinition Height = ""3""/>
                <RowDefinition/>
            </Grid.RowDefinitions>
            <DockPanel x:Name = ""dpLabel"" Grid.Row=""0"" />
            <DockPanel x:Name = ""dpInstances"" Grid.Row = ""1""/>
            <GridSplitter Grid.Row=""2"" Height=""3"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name = ""dpTree"" Grid.Row=""3"" />
        </Grid>
</Grid>
";
            var strReader = new System.IO.StringReader(strxaml);
            var xamlreader = XmlReader.Create(strReader);
            var grid = (Grid)(XamlReader.Load(xamlreader));
            var dpLabel = (DockPanel)grid.FindName("dpLabel");
            var dpTypes = (DockPanel)grid.FindName("dpTypes");
            var dpInstances = (DockPanel)grid.FindName("dpInstances");
            var dpTree = (DockPanel)grid.FindName("dpTree");
            dpLabel.Children.Add(new TextBlock() { Text = "Select a type to show details" });
            var dictDependencyPropertiesByName = new Dictionary<string, ClrObject>();
            var dictDependencyPropertiesByIndex = new Dictionary<int, ClrObject>();
            using (var _progress = new ProgressOwnUI<string>("Getting all types"))
            {
                var dependencyProperties = _clrUtil.GetObjectsOfType("System.Windows.DependencyProperty");
                //var query = from obj in dependencyProperties
                //            select new
                //            {
                //                _clrobj = obj,
                //                Address = obj.GetAddressAsString(),
                //                PropName = obj.GetObjectMember("_name").AsString(),
                //                packedData = obj.GetFieldValue<int>("_packedData").ToString("x8")
                //            };
                var lstTypes = new List<ClrType>();
                // for generics, these types only show generic params, like "List<T>", and not "List<int>"
                _clrUtil.clrRuntime.EnumerateTypes((type) =>
                {
                    if (DoesInheritFrom(WpfBaseType, type))
                    {
                        lstTypes.Add(type);
                    }
                    return true; // keep enumerating
                });
                var query = from typ in lstTypes
                            select new
                            {
                                _type = typ,
                                typ.Name,
                                BaseType = typ.BaseType == null ? "" : typ.BaseType.Name,
                                typ.Module,
                            };
                var br = new BrowsePanel(query);
//                AddItemsToContextMenu(br);
                dpTypes.Children.Add(br);
                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("WpfViewer", $"");
                tabItem.Content = grid;
                br.BrowseList.SelectionChanged += (om, em) =>
                 {
                     try
                     {
                         dpTree.Children.Clear();
                         BrowseList lv = om as BrowseList;
                         if (lv != null && lv.SelectedItems.Count == 1)
                         {
                             var selectedItem = lv.SelectedItems[0];
                             var typeDesc = TypeDescriptor.GetProperties(selectedItem)["_type"];
                             var type = (ClrType)typeDesc.GetValue(selectedItem);
                             var lstObjs = _clrUtil.GetObjectsOfType(type.Name);
                             var q = from obj in lstObjs
                                     select new
                                     {
                                         _clrobj = obj,
                                         Address = obj.GetAddressAsString(),
                                         Type = obj.Type.Name
                                     };
                             var brObjs = new BrowsePanel(q, ShowFilter: false);
                             dpInstances.Children.Clear();
                             dpInstances.Children.Add(brObjs);
                             AddItemsToContextMenu(brObjs);
                             brObjs.BrowseList.SelectionChanged += (om2, em2) =>
                             {
                                 try
                                 {
                                     BrowseList lv2 = om2 as BrowseList;
                                     if (lv2 != null && lv2.SelectedItems.Count == 1)
                                     {
                                         var selectedObjItem = lv2.SelectedItems[0];
                                         var typeDescobj = TypeDescriptor.GetProperties(selectedObjItem)["_clrobj"];
                                         var clrObj = (ClrObject)typeDescobj.GetValue(selectedObjItem);
                                         dpTree.Children.Clear();
                                         var tv = new MyTreeViewBase();
                                         dpTree.Children.Add(tv);
                                         GetWpfTreeFromObj(clrObj, tv);
                                     }
                                 }
                                 catch (Exception ex)
                                 {
                                     _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                                 }
                             };
                         }
                     }
                     catch (Exception ex)
                     {
                         _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                     }
                 };
            }
        }
        public static void GetWpfTreeFromObj(ClrObject clrObject, ItemsControl tvItemParent)
        {
            clrObject.EnumerateReferences(oChild =>
                {
                    var tvItem = new WpfTreeViewItem(oChild);
                    tvItemParent.Items.Add(tvItem);
                    tvItem.Items.Add(new WpfTreeViewItem() { IsDummy = true });
                    return true;
                });
        }
        public static bool DoesInheritFrom(string baseClassName, ClrType type)
        {
            if (baseClassName == type.Name)
            {
                return true;
            }
            if (type.Name == "System.Object" || type.BaseType == null)
            {
                return false;
            }
            return DoesInheritFrom(baseClassName, type.BaseType);
        }
        internal enum FullValueSource : short
        {
            // Bit used to store BaseValueSourceInternal = 0x01
            // Bit used to store BaseValueSourceInternal = 0x02
            // Bit used to store BaseValueSourceInternal = 0x04
            // Bit used to store BaseValueSourceInternal = 0x08

            ValueSourceMask = 0x000F,
            ModifiersMask = 0x0070,
            IsExpression = 0x0010,
            IsAnimated = 0x0020,
            IsCoerced = 0x0040,
            IsPotentiallyADeferredReference = 0x0080,
            HasExpressionMarker = 0x0100,
            IsCoercedWithCurrentValue = 0x200,
        }

        // Note that these enum values are arranged in the reverse order of
        // precendence for these sources. Local value has highest
        // precedence and Default value has the least. Note that we do not
        // store default values in the _effectiveValues cache unless it is
        // being coerced/animated.
        internal enum BaseValueSourceInternal : short
        {
            Unknown = 0,
            Default = 1,
            Inherited = 2,
            ThemeStyle = 3,
            ThemeStyleTrigger = 4,
            Style = 5,
            TemplateTrigger = 6,
            StyleTrigger = 7,
            ImplicitReference = 8,
            ParentTemplate = 9,
            ParentTemplateTrigger = 10,
            Local = 11,
        }
        struct EffectiveValueEntry
        {
            public IntPtr _value;
            public Int16 _propertyIndex;
            public FullValueSource _source;
        }
        public class WpfTreeViewItem : MyTreeViewItem
        {
            public bool IsDummy = false;
            public readonly ClrObject _clrObject;
            internal WpfTreeViewItem()
            {
                this.Expanded += (o, e) =>
                {
                    if (this.Items.Count == 1 && (this.Items[0] as WpfTreeViewItem).IsDummy)
                    {
                        Items.Clear();//clear dummy
                        switch (_clrObject.Type.Name)
                        {
                            case "System.Windows.EffectiveValueEntry[]":
                                {
                                    ClrArray objAsArray = _clrObject.AsArray();
                                    var len = objAsArray.Length;
                                    var arr = objAsArray.ReadValues<EffectiveValueEntry>(start: 0, count: len);
                                    this.Items.Add(new WpfTreeViewItem($"{arr.Length}"));
                                    foreach (var elem in arr)
                                    {
                                        var elemObj = MainWindowClrObjExp.g_Instance._clrUtil._heap.GetObject((ulong)elem._value.ToInt64());
                                        var str = string.Empty;
                                        if (elemObj.IsValid)
                                        {
                                            str = elemObj.GetObjectDisplayValue();
                                        }
                                        this.Items.Add(new WpfTreeViewItem(MyAddrFormatter.AddrFormat($"{elem._value:x}") + $" {elem._propertyIndex:x4} {(int)elem._source:x4} {str}"));
                                    }
                                }
                                break;
                            default:
                                _clrObject.EnumerateReferences(oChild =>
                                {
                                    if (MyMainClass.DoesInheritFrom(MyMainClass.WpfBaseType, _clrObject.Type))
                                    {
                                        MyMainClass.GetWpfTreeFromObj(oChild, this);
                                    }
                                    return true;
                                });
                                break;
                        }
                    }
                };
            }
            public WpfTreeViewItem(ClrObject clrObject) : this()
            {
                this._clrObject = clrObject;
                Header = $"{clrObject.GetAddressAsString()} {clrObject.Type.Name}";
            }
            public WpfTreeViewItem(string header) : this()
            {
                Header = header;
            }
            public override string ToString() => $"{Header}";
        }
    }
}
