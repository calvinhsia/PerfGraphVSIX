﻿//Desc: Enumerate all types

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: ..\util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;


namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            using (var _progress = new ProgressOwnUI<string>("Getting all types"))
            {
                var lstTypes = new List<ClrType>();
                // for generics, these types only show generic params, like "List<T>", and not "List<int>"
                _clrutil.clrRuntime.EnumerateTypes((type) =>
                {
                    lstTypes.Add(type);
                    return true; // keep enumerating
                });
                var query = from typ in lstTypes
                            select new
                            {
                                typ.Name,
                                typ.Module,
                                FieldCount = typ.Fields.Length
                            };
                var br = new BrowsePanel(query);
                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("Types", $"");
                tabItem.Content = br;
            }
        }
    }
}
