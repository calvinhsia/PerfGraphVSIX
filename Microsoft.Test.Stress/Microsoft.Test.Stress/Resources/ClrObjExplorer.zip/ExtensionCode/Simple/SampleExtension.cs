﻿//Desc: Extension Sample
//Desc: Shows how to find types, display selected members

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: ..\util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using ClrLib;
using ClrObjExplorer;
using Utility;


namespace ClrObjExtension
{
    public class MyMainClass: BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args): base(args)
        {

        }
        private void DoMainInternal()
        {
            var typeToFind = "WpfPdfViewer.TOCEntry";
            using (var _progress = new ProgressOwnUI<string>("Finding Extension"))
            {
                _progress.Report($"Finding {typeToFind}");
                var sb = new StringBuilder();
                var objs = _clrutil.GetObjectsOfType(typeToFind);
                if (objs.Count > 0)
                {
                    var q = from obj in objs
                            select new
                            {
                                Addr = obj.GetAddressAsString(),
                                SongName = obj.GetObjectDisplayValue("<SongName>k__BackingField"),
                                Composer = obj.GetObjectDisplayValue("<Composer>k__BackingField"),
                                Notes = obj.GetObjectDisplayValue("<Notes>k__BackingField"),
                                Date = obj.GetObjectDisplayValue("<Date>k__BackingField"),
                            };
                    var br = new BrowsePanel(q);
                    var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("Music", $"{typeToFind}");
                    tabItem.Content = br;
                    var typ = objs[0].Type;
                    foreach (var fld in typ.Fields)
                    {
                        sb.AppendLine(fld.Name);
                    }
                    _mainWindowClrObjExp.AddStatusMsg(objs[0].GetGCRootPathsAsString());
                    ObjRefView.MakeObjRefTree(_clrutil, objs[0], _mainWindowClrObjExp);
                }
                _mainWindowClrObjExp.AddStatusMsg(sb.ToString());

            }
        }
    }
}
