﻿//Desc: Show WPF Freezable Objects

//Include: ..\util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var ctrl = new EventSubscribersControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("EventSubscribers", $"Subscribers to a particular class events");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
    }
    public class EventSubscribersControl : UserControl
    {
        MyMainClass _MyMainClass;
        MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
        ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
        public EventSubscribersControl(MyMainClass myMainClass)
        {
            _MyMainClass = myMainClass;
        }
        public void Initialize()
        {
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" >
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""800""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height = ""800""/>
            <RowDefinition Height = ""3""/>
            <RowDefinition Height = ""*""/>
        </Grid.RowDefinitions>
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbTypes"" Text=""Types"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name=""dpTypes"" Grid.Row=""1""/>
        </Grid>

        <GridSplitter Grid.Row = ""1"" VerticalAlignment=""Center"" HorizontalAlignment=""Stretch"" Height = ""3"" Background=""LightBlue""/>
        <Grid Grid.Row=""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbEventNames""  Text=""Event Names"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name=""dpEventNames"" Grid.Row = ""1""/>
        </Grid>
    </Grid>
    <GridSplitter Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Column = ""2"">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbInstances"" Text=""Instances"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name = ""dpInstances"" Grid.Row=""1""/>
        </Grid>
    </Grid>
    <GridSplitter Grid.Column = ""3"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Column = ""4"">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
                <RowDefinition Height = ""3""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbEventHandlers"" Text=""EventHandlers"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name = ""dpEventHandlers"" Grid.Row=""1"" />
            <GridSplitter Grid.Row = ""2"" VerticalAlignment=""Center"" HorizontalAlignment=""Stretch"" Height = ""4"" Background=""LightBlue""/>
            <DockPanel x:Name = ""dpEventHandlerGroup"" Grid.Row=""3"" />
        </Grid>
    </Grid>
</Grid>
";
            var grid = (Grid)(XamlReader.Parse(strxaml));
            this.Content = grid;
            grid.DataContext = this;

            var dpTypes = (DockPanel)grid.FindName("dpTypes");
            var tbTypes = (TextBox)grid.FindName("tbTypes");
            var dpEventNames = (DockPanel)grid.FindName("dpEventNames");
            var tbEventNames = (TextBox)grid.FindName("tbEventNames");
            var dpInstances = (DockPanel)grid.FindName("dpInstances");
            var tbInstances = (TextBox)grid.FindName("tbInstances");
            var dpEventHandlers = (DockPanel)grid.FindName("dpEventHandlers");
            var tbEventHandlers = (TextBox)grid.FindName("tbEventHandlers");
            var dpEventHandlerGroup = (DockPanel)grid.FindName("dpEventHandlerGroup");

            tbTypes.Text = $@"Select a type that publishes Events. (Use the StringFilter) The EventNames will be shown below. Select an Event name and the Instances of the Type will show, along with a count column of # of subscribers. 
A MultiCastDelegate can have a single target, or a Invocationlist.
Choose an Instance to see the EventHandlers on the right. Right-Click to see various options";

            var lstFreezables = new List<string>();
            using (var progress = new ProgressOwnUI<string>($"Finding Freezable types"))
            {
                try
                {
                    foreach (var typeName in _clrUtil.EnumerateObjectTypes())
                    {
                        var oneObjOfType = _clrUtil.GetObjectsOfType(typeName);
                        var ptype = oneObjOfType[0].Type;
                        var curtype = ptype;
                        while (curtype != null && curtype.Name != "System.Object")
                        {
                            if (curtype.Name == "System.Windows.Freezable")
                            {
                                lstFreezables.Add(ptype.Name);
                            }
                            curtype = curtype.BaseType;
                        }
                    }
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            }
            var qTypes = from TypeName in lstFreezables
                         let Count = _clrUtil.GetObjectsOfType(TypeName).Count
                         orderby Count descending
                         select new
                         {
                             Count,
                             TypeName
                         };
            var brTypes = new BrowsePanel(qTypes, colWidths: new[] { 90 });
            dpTypes.Children.Add(brTypes);

            brTypes.BrowseList.SelectionChanged += (o, e) =>
             {
                 try
                 {
                     if (brTypes.BrowseList.SelectedItems.Count == 1)
                     {
                         //https://referencesource.microsoft.com/#WindowsBase/Base/System/Windows/DependencyObject.cs,373340cb72bd37e0

                         var selectedItem = brTypes.BrowseList.SelectedItems[0];
                         var typeName = (string)TypeDescriptor.GetProperties(selectedItem)["TypeName"].GetValue(selectedItem);
                         var lstInstances = _clrUtil.GetObjectsOfType(typeName);
                         var qInstances = from obj in lstInstances
                                          let PackedData = obj.ReadField<UInt32>("_packedData")
                                          let DO_Sealed = ((PackedData & 0x004000000) != 0)
                                          let FreezableFrozen = DO_Sealed
                                          select new
                                          {
                                              _clrobj = obj,
                                              Address = obj.GetAddressAsString(),
                                              Obj = obj.GetObjectDisplayValue(),
                                              PackedData = PackedData.ToString("x8"),
                                              FreezableFrozen
                                          };
                         var brInstances = new BrowsePanel(qInstances);
                         _MyMainClass.AddItemsToContextMenu(brInstances);
                         dpInstances.Children.Clear();
                         dpInstances.Children.Add(brInstances);

                     }
                 }
                 catch (Exception ex)
                 {
                     _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                 }
             };
        }
    }
}
