﻿//Desc: ScopeStudio type: show members, show how to get References

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: ..\util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Media;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;


namespace ClrObjExtension
{
    public class MyMainClass: BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var typeToFind = "Microsoft.Cosmos.ScopeStudio.BusinessObjects.JobObjectModel.ComosOnYarnOnlineJobInfo";
            using (var _progress = new ProgressOwnUI<string>($"Finding {typeToFind}"))
            {
                _progress.Report($"Finding {typeToFind}");
                var objs = _clrutil.GetObjectsOfType(typeToFind);
                if (objs.Count > 0)
                {
                    var q = from obj in objs
                            select new
                            {
                                _clrobj = obj,
                                Address = obj.GetAddressAsString(),
                                Name = obj.GetObjectDisplayValue("<Name>k__BackingField"),
                                UserName = obj.GetObjectDisplayValue("<UserName>k__BackingField"),
                                RuntimeState = obj.GetObjectDisplayValue("<RuntimeState>k__BackingField"),
                                RuntimeName = obj.GetObjectDisplayValue("<RuntimeName>k__BackingField"),
                            };
                    var brObjs = new BrowsePanel(q);
                    var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("Scope", $"{typeToFind}");
                    tabItem.Content = brObjs;

                    brObjs.BrowseList.ContextMenu.AddMenuItem(async (o, e) =>
                    {
                        await Task.Delay(200);
                        var items = brObjs.BrowseList.SelectedItems;
                        if (items == null || items.Count < 1)
                        {
                            items = brObjs.BrowseList.Items;
                        }
                        var sb = new StringBuilder();
                        foreach (var itm in items)
                        {
                            var tdescitem = TypeDescriptor.GetProperties(itm)["_clrobj"];
                            var objRoot = (ClrObject)tdescitem.GetValue(itm);
                            var tiptxt = objRoot.GetToolTipAsString();
                            sb.AppendLine(tiptxt);
                        }
                        BrowseList.WriteOutputToTempFile(sb.ToString());
                    }, "ShowToolTip In Notepad", "", InsertPos: 0);
                    brObjs.BrowseList.AddHandler(System.Windows.UIElement.MouseMoveEvent, new RoutedEventHandler((om, em) =>
                    {
                        try
                        {
                            BrowseList lv = om as BrowseList;
                            if (lv != null)
                            {
                                var tb = em.OriginalSource as TextBlock;
                                if (tb != null)
                                {
                                    ToolTip tip = null;
                                    switch (tb.Name)
                                    {
                                        case "Address":
                                            var clrobj = (ClrObject)TypeDescriptor.GetProperties(tb.DataContext)["_clrobj"].GetValue(tb.DataContext);

                                            var tiptxt = clrobj.GetToolTipAsString(nMaxDumpSize: 1024);
                                            tip = _mainWindowClrObjExp.CreateNewToolTip();
                                            var tbTip = new TextBox()
                                            {
                                                BorderThickness = new System.Windows.Thickness(0),
                                                FontFamily = new FontFamily("Courier New"),
                                                FontSize = 9,
                                                Background = Brushes.LightYellow,
                                                Text = tiptxt
                                            };
                                            tip.Content = tbTip;

                                            break;
                                    }
                                    if (tip != null)
                                    {
                                        tip.PlacementTarget = tb;
                                        tip.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
                                        tip.IsOpen = true;
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                        }
                    }));
                }
            }
        }
    }
}
