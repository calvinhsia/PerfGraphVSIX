﻿//Desc: Extension Sample

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: ..\util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;


namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public string TypeNameFilter { get; set; }
        public MyMainClass(object[] args) : base(args)
        {

        }
        private void DoMainInternal()
        {
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" Margin=""5,5,5,5"">
<Grid.RowDefinitions>
    <RowDefinition/>
    <RowDefinition Height=""25"" />
</Grid.RowDefinitions>
<DockPanel Grid.Row=""0"">
    <Grid>
        <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""120""/>
        <ColumnDefinition/>
        </Grid.ColumnDefinitions>
        <StackPanel Name=""inputPanel"" >
            <Label Content=""TypeNameFilter""/>
            <l:MyTextBox 
                Text =""{Binding Path=TypeNameFilter}"" 
                ToolTip=""some tooltip"" />
            <Button 
                Name=""btnGo"" 
                Content=""_Go"" 
                HorizontalAlignment=""Left"" 
                Margin=""10,2,0,0"" 
                VerticalAlignment=""Top"" 
                Width=""55""/>

        </StackPanel>
        <UserControl Name=""MyUserControl"" Grid.Column=""1""></UserControl>
    </Grid>
</DockPanel>
</Grid>
";

            var strReader = new System.IO.StringReader(strxaml);
            var xamlreader = XmlReader.Create(strReader);
            var grid = (Grid)(XamlReader.Load(xamlreader));
            var btnGo = (Button)grid.FindName("btnGo");
            var MyUserControl = (UserControl)grid.FindName("MyUserControl");
            btnGo.Click += (o, e) =>
            {
                try
                {
                    AsyncPump.Run(async () =>
                    {
                        using (var _progress = new ProgressOwnUI<string>($"Types {TypeNameFilter}"))
                        {
                            await Task.Delay(TimeSpan.FromSeconds(1));
                            var lstTypes = new List<ClrType>();
                            // for generics, these types only show generic params, like "List<T>", and not "List<int>"
                            _clrUtil.clrRuntime.EnumerateTypes((type) =>
                            {
                                if (type.Name.IndexOf(TypeNameFilter, StringComparison.OrdinalIgnoreCase) >= 0)
                                {
                                    lstTypes.Add(type);
                                }
                                return true; // keep enumerating
                            });
                            var query = from typ in lstTypes
                                        select new
                                        {
                                            typ.Name,
                                            typ.Module,
                                            FieldCount = typ.Fields.Length
                                        };
                            var br = new BrowsePanel(query);
                            MyUserControl.Content = br;
                        }
                    });
                }
                catch (global::System.Exception)
                {
                }
            };
            grid.DataContext = this;

            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("WpfSample", $"");
            tabItem.Content = grid;

        }
    }
    // a textbox that selects all when focused:
    public class MyTextBox : TextBox
    {
        public MyTextBox()
        {
            this.GotFocus += (o, e) =>
            {
                this.SelectAll();
            };
        }
    }
}
