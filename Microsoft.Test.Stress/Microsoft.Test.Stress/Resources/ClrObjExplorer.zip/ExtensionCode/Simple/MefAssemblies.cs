﻿//Desc: Extension Sample
//Desc: Shows Microsoft.VisualStudio.ExtensibilityHosting.FaultCatchingAssemblyLoader

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: ..\util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Xml;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;


namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }
        /*
Children of '-- Microsoft.VisualStudio.ExtensibilityHosting.FaultCatchingAssemblyLoader 00000276`5338e330'
-- Microsoft.VisualStudio.ExtensibilityHosting.FaultCatchingAssemblyLoader 00000276`5338e330
 -> LoadedAssemblies = System.Collections.Generic.Dictionary<System.Reflection.AssemblyName, System.Reflection.Assembly> 00000276`5338e3b0
  -> buckets = System.Int32[] 00000276`5475f7a8
  -> comparer = Microsoft.VisualStudio.ExtensibilityHosting.AssemblyNameComparer 00000276`5338e400
  -> entries = System.Collections.Generic.Dictionary<System.Reflection.AssemblyName, System.Reflection.Assembly>+Entry[] 00000276`5475f928
   -> System.Reflection.AssemblyName 00000277`530076b8
    -> _CodeBase = System.String 00000277`53007610 file:///C:/Windows/Microsoft.NET/Framework64/v4.0.30319/mscorlib.dll file:///C:/Windows/Microsoft.NET/Framework64/v4.0.30319/mscorlib.dll
    -> _CultureInfo = System.Globalization.CultureInfo 00000277`53007720
    -> _Name = System.String 00000277`530077a0 mscorlib mscorlib
    -> _PublicKeyToken = System.Byte[] 00000277`530077d0
    -> _Version = System.Version 00000277`530077f0
   -> System.Reflection.RuntimeAssembly 00000277`521e3fa8
   -> System.Reflection.AssemblyName 00000276`53417e38
    -> _CodeBase = System.String 00000276`53417cf0 file:///c:/program files/microsoft visual studio/2022/preview/common7/ide/commonextensions/microsoft/project/Microsoft.VisualStudio.ProjectSystem.dll file:///c:/program files/microsoft visual studio/2022/preview/common7/ide/commonextensions/microsoft/project/Microsoft.VisualStudio.ProjectSystem.dll
    -> _CultureInfo = System.Globalization.CultureInfo 00000276`53417ea0
    -> _Name = System.String 00000276`53417f20 Microsoft.VisualStudio.ProjectSystem Microsoft.VisualStudio.ProjectSystem
    -> _PublicKeyToken = System.Byte[] 00000276`53417f88
    -> _Version = System.Version 00000276`53417fa8
   -> System.Reflection.RuntimeAssembly 00000276`534184f8
         */
        private void DoMainInternal()
        {
            var typeToFind = "Microsoft.VisualStudio.ExtensibilityHosting.FaultCatchingAssemblyLoader";
            using (var _progress = new ProgressOwnUI<string>($"Finding {typeToFind}"))
            {
                _progress.Report($"Finding {typeToFind}");
                var objs = _clrUtil.GetObjectsOfType(typeToFind);
                if (objs.Count > 0)
                {
                    var entries = objs.First().GetObjectMember("LoadedAssemblies").GetObjectMember("entries");
                    _mainWindowClrObjExp.AddStatusMsg($"got entries {entries.GetAddressAsString()}");

                    var q = from entry in entries.EnumerateReferences()
                            where entry.Type.Name == "System.Reflection.AssemblyName"
                            select new
                            {
                                Addr = entry.GetAddressAsString(),
                                Name = entry.GetObjectMember("_Name").GetObjectDisplayValue(),
                                CodeBase = entry.GetObjectMember("_CodeBase").GetObjectDisplayValue(),
                            };
                    var br = new BrowsePanel(q);
                    var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("MefAsms", $"{typeToFind}");
                    tabItem.Content = br;
                }
            }
        }
    }
}
