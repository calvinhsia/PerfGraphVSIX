﻿//Desc: Given an object type, search around it to find identifiable stuff (e.g. Who created lots of unrooted NewtonSoft.JValue ?)

//Include: ..\util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var ctrl = new NewtonsoftJsonControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("Newtonsoft", $"Json");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
    }
    /// <summary>
    /// Specifies the type of token.
    ///https://github.com/JamesNK/Newtonsoft.Json/blob/master/Src/Newtonsoft.Json/Linq/JTokenType.cs
    /// </summary>
    public enum JTokenType
    {
        /// <summary>
        /// No token type has been set.
        /// </summary>
        None = 0,

        /// <summary>
        /// A JSON object.
        /// </summary>
        Object = 1,

        /// <summary>
        /// A JSON array.
        /// </summary>
        Array = 2,

        /// <summary>
        /// A JSON constructor.
        /// </summary>
        Constructor = 3,

        /// <summary>
        /// A JSON object property.
        /// </summary>
        Property = 4,

        /// <summary>
        /// A comment.
        /// </summary>
        Comment = 5,

        /// <summary>
        /// An integer value.
        /// </summary>
        Integer = 6,

        /// <summary>
        /// A float value.
        /// </summary>
        Float = 7,

        /// <summary>
        /// A string value.
        /// </summary>
        String = 8,

        /// <summary>
        /// A boolean value.
        /// </summary>
        Boolean = 9,

        /// <summary>
        /// A null value.
        /// </summary>
        Null = 10,

        /// <summary>
        /// An undefined value.
        /// </summary>
        Undefined = 11,

        /// <summary>
        /// A date value.
        /// </summary>
        Date = 12,

        /// <summary>
        /// A raw JSON value.
        /// </summary>
        Raw = 13,

        /// <summary>
        /// A collection of bytes value.
        /// </summary>
        Bytes = 14,

        /// <summary>
        /// A Guid value.
        /// </summary>
        Guid = 15,

        /// <summary>
        /// A Uri value.
        /// </summary>
        Uri = 16,

        /// <summary>
        /// A TimeSpan value.
        /// </summary>
        TimeSpan = 17
    }
    public class NewtonsoftJsonControl : UserControl
    {
        MyMainClass _MyMainClass;
        MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
        ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
        public NewtonsoftJsonControl(MyMainClass myMainClass)
        {
            _MyMainClass = myMainClass;
        }
        public void Initialize()
        {
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" >
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""800""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <Grid>
        <DockPanel x:Name = ""dpData""/>
    </Grid>
    <GridSplitter Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Column = ""2"">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <DockPanel x:Name = ""dpSummary"" Grid.Row=""1""/>
        </Grid>
    </Grid>
    <GridSplitter Grid.Column = ""3"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Column = ""4"">
        <Grid>
            <DockPanel x:Name = ""dpSummaryVal""/>
        </Grid>
    </Grid>
</Grid>
";
            var grid = (Grid)(XamlReader.Parse(strxaml));
            this.Content = grid;
            grid.DataContext = this;

            var dpData = (DockPanel)grid.FindName("dpData");
            var dpSummary = (DockPanel)grid.FindName("dpSummary");
            var dpSummaryVal = (DockPanel)grid.FindName("dpSummaryVal");

            var typeName = "Newtonsoft.Json.Linq.JValue";
            var lstObjs = _clrUtil.GetObjectsOfType(typeName);
            _mainWindowClrObjExp.AddStatusMsg($"got list {lstObjs.Count:n0} objs");

            var qInstances = from obj in lstObjs.Take(10000)
                             let valueType = ((JTokenType)obj.ReadField<int>("_valueType"))
                             let Val = obj.GetObjectDisplayValue("_value")
                             select new
                             {
                                 _clrobj = obj,
                                 Address = obj.GetAddressAsString(),
                                 Obj = obj.GetObjectDisplayValue(),
                                 ValueType = valueType.ToString(),
                                 Val
                             };
            var brInstances = new BrowsePanel(qInstances);
            dpData.Children.Clear();
            dpData.Children.Add(brInstances);
            _MyMainClass.AddItemsToContextMenu(brInstances);

            var sumryJsonType = from obj in lstObjs
                                let ValueType = ((JTokenType)obj.ReadField<int>("_valueType"))
                                group obj by ValueType into grp
                                select new
                                {
                                    JValueType = grp.Key,
                                    Count = grp.Count(),
                                };
            var brSummary = new BrowsePanel(sumryJsonType);
            dpSummary.Children.Clear();
            dpSummary.Children.Add(brSummary);
            brSummary.BrowseList.SelectionChanged += async (_, __) =>
            {
                try
                {
                    await Task.Delay(100);
                    if (brSummary.BrowseList.SelectedItems.Count == 1)
                    {
                        var selItem = brSummary.BrowseList.SelectedItems[0];
                        var jtype = (JTokenType)TypeDescriptor.GetProperties(selItem)["JValueType"].GetValue(selItem);
                        var sumryJsonTypeVal = from obj in lstObjs
                                               let ValueType = ((JTokenType)obj.ReadField<int>("_valueType"))
                                               where ValueType == jtype
                                               let Val = obj.GetObjectDisplayValue("_value")
                                               group obj by new { ValueType, Val } into grp
                                               select new
                                               {
                                                   JValueType = grp.Key.ValueType,
                                                   Value = grp.Key.Val,
                                                   Count = grp.Count(),
                                               };
                        var brSummaryVal = new BrowsePanel(sumryJsonTypeVal);
                        dpSummaryVal.Children.Clear();
                        dpSummaryVal.Children.Add(brSummaryVal);
                    }
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }

            };


        }
    }
}
