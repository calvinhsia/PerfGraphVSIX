﻿//Desc: Extension Sample
//Desc: Shows how to find types, display selected members

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: ..\util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using ClrLib;
using ClrObjExplorer;
using Utility;


namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }
        /*
Children of '-> m_state = System.Threading.Tasks.Task+DelayPromise 254398ac'
-> m_state = System.Threading.Tasks.Task+DelayPromise 254398ac
 -> m_continuationObject = System.Action 254399a4 System.Runtime.CompilerServices.AsyncMethodBuilderCore+MoveNextRunner System.Runtime.CompilerServices.AsyncMethodBuilderCore+MoveNextRunner.Run System.Runtime.CompilerServices.AsyncMethodBuilderCore+MoveNextRunner System.Runtime.CompilerServices.AsyncMethodBuilderCore+MoveNextRunner.Run
  -> _target = System.Runtime.CompilerServices.AsyncMethodBuilderCore+MoveNextRunner 25439994
   -> m_context = System.Threading.ExecutionContext 25439968
   -> m_stateMachine = MyCodeToExecute.MyClass+BigStuffWithLongNameSoICanSeeItBetter+<>c__DisplayClass4_0+<<DoTheDelay>b__1>d 2543988c
    -> <>4__this = MyCodeToExecute.MyClass+BigStuffWithLongNameSoICanSeeItBetter+<>c__DisplayClass4_0 254397fc
     -> <>4__this = MyCodeToExecute.MyClass+BigStuffWithLongNameSoICanSeeItBetter 254397ec
     -> tcs = System.Threading.Tasks.TaskCompletionSource<System.Int32> 2543980c
    -> <>t__builder.m_builder.m_task = System.Threading.Tasks.Task<System.Threading.Tasks.VoidTaskResult> 254399c4 WaitingForActivation WaitingForActivation
    -> <>u__1.m_task = System.Threading.Tasks.Task+DelayPromise 254398ac
 -> Timer = System.Threading.Timer 254398ec
         */
        private void DoMainInternal()
        {
            var typeToFind = "System.Threading.Tasks.Task+DelayPromise";
            using (var _progress = new ProgressOwnUI<string>($"Finding {typeToFind}"))
            {
                _progress.Report($"Finding {typeToFind}");
                var oPromises = _clrutil.GetObjectsOfType(typeToFind);
                // shows empty list if none
                {
                    var qDelayTasks = from oPromise in oPromises
                                          //                            where obj.GetAddressAsString() == "254398ac"
                                      let ContinueObj = oPromise.GetObjectMember("m_continuationObject")
                                      where ContinueObj.IsValid
                                      let target = ContinueObj.GetObjectMember("_target")
                                      where target.IsValid
                                      let stateMachine = target.GetObjectMember("m_stateMachine")
                                      where stateMachine.IsValid
                                      let this4 = stateMachine.GetObjectMember("<>4__this")
                                      where this4.IsValid
                                      let timer = oPromise.GetObjectMember("Timer")
                                      let timerHolder = timer.GetObjectMember("m_timer")
                                      let timerqtimer = timerHolder.GetObjectMember("m_timer")
                                      let StartTicks = timerqtimer.GetFieldValue<int>("m_startTicks")
                                      let dueTimems = timerqtimer.GetFieldValue<uint>("m_dueTime") // mseconds
                                      select new
                                      {
                                          Addr = oPromise.GetAddressAsString(),
                                          DelayPromise = oPromise.Type.Name,
                                          //Timer = timer.GetObjectDisplayValue(),
                                          //timerHolder,
                                          //timerqtimer,
                                          StartTicks,
                                          dueTimems,
                                          //                                          durationRest,
                                          //continueObj = ContinueObj.GetObjectDisplayValue(),
                                          //Target = target.GetObjectDisplayValue(),
                                          StateMachine = stateMachine.GetObjectDisplayValue(),
                                          This4 = this4.Type?.Name
                                      };
                    var br = new BrowsePanel(qDelayTasks);
                    var qAgg = from itm in qDelayTasks
                               group itm by $"{itm.dueTimems}:" + itm.This4 // assumes that all delays have the same duration
                               into grp
                               where grp.Count() > 0
                               orderby grp.Count() descending
                               select new
                               {
                                   Count = grp.Count(),
                                   DelayBlame = grp.Key // nMsecs + ":" + blame
                               };
                    var brAgg = new BrowsePanel(qAgg);
                    var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("DelayPromise", $"{typeToFind}");

                    var grid = new Grid();
                    tabItem.Content = grid;
                    grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(50) });
                    grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(500) });
                    grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(3) });
                    grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
                    var tb = new TextBlock() { Text = $"Total # of {typeToFind} = {oPromises.Count:n0}" };
                    Grid.SetRow(tb, 0);
                    grid.Children.Add(tb);

                    Grid.SetRow(brAgg, 1);
                    grid.Children.Add(brAgg);

                    var splitter = new GridSplitter() { HorizontalAlignment = HorizontalAlignment.Stretch, Height = 3 };
                    Grid.SetRow(splitter, 2);
                    grid.Children.Add(splitter);

                    Grid.SetRow(br, 3);
                    grid.Children.Add(br);
                }
            }
        }
    }
}

