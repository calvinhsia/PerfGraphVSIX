﻿//Desc: Show CLR Handles, like GCHandle, WeakShort, Dependent,AsyncPinned

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: ..\util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using System.Reflection.Emit;
using System.Runtime.Remoting.Messaging;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            _mainWindowClrObjExp.AddStatusMsg(_clrUtil._dumpFileName);
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                System.Reflection.Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition/>
    </Grid.ColumnDefinitions>
    <DockPanel x:Name = ""dpRunTimeType"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <DockPanel x:Name = ""dpSummary"" Grid.Row=""2"" Grid.Column=""3"" />
</Grid>
";
            var strReader = new System.IO.StringReader(strxaml);
            var xamlreader = XmlReader.Create(strReader);
            var grid = (Grid)(XamlReader.Load(xamlreader));
            var dpRunTimeType = (DockPanel)grid.FindName("dpRunTimeType");
            var dpSummary = (DockPanel)grid.FindName("dpSummary");
            var typeToFind = "System.RuntimeType";
            ulong GetAddrPointedTo(IntPtr mCache)
            {
                ulong addr = 0;
                if (mCache != IntPtr.Zero)
                {
                    var bytes = ClrUtil.g_ClrUtil.ReadBytes((ulong)mCache.ToInt64(), IntPtr.Size);
                    if (IntPtr.Size == 4)
                    {
                        addr = BitConverter.ToUInt32(bytes, 0);
                    }
                    else
                    {
                        addr = BitConverter.ToUInt64(bytes, 0);
                    }
                }
                return addr;
            }
            using (var _progress = new ProgressOwnUI<string>($"Getting all {typeToFind}"))
            {
                var lstObjs = _clrUtil.GetObjectsOfType(typeToFind);
                var query = from obj in lstObjs
                            let mHandle = obj.GetFieldValue<IntPtr>("m_handle")
                            let mCache = obj.GetFieldValue<IntPtr>("m_cache")
                            let rttypecache = ClrUtil.g_ClrUtil._heap.GetObject(GetAddrPointedTo(mCache))
                            let handleObj = GetAddrPointedTo(mHandle)
                            select new
                            {
                                Address = obj.GetAddressAsString(),
                                Handle = MyAddrFormatter.AddrFormat($"{mHandle:x}"),
                                HandleObj = MyAddrFormatter.AddrFormat($"{handleObj:x}"),
                                Cache = MyAddrFormatter.AddrFormat($"{mCache:x}"),
                                RTTC = rttypecache.GetObjectDisplayValue(),
                                Name = rttypecache.GetObjectDisplayValue("m_name"),
                                FullName = rttypecache.GetObjectDisplayValue("m_fullname"),
                                ToString = rttypecache.GetObjectDisplayValue("m_toString"),
                            };
                var br = new BrowsePanel(query);
                dpRunTimeType.Children.Add(br);

                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem($"{typeToFind}", $"");
                tabItem.Content = grid;
            }
        }
    }
}
