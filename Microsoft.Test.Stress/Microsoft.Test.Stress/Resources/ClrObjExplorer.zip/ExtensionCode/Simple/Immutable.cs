﻿//Desc: Show System.Collections.Immutable

//Include: ..\util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.Xaml.dll

// see also https://github.com/dotnet/runtime/blob/main/src/libraries/System.Collections.Immutable/src/System/Collections/Immutable/ImmutableHashSet.cs


using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("Immutable", $"System.Collections.Immutable");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
    }
    public class MyUserControl : UserControl
    {
        public List<string> ClrTypes { get; set; } = new List<string>();
        MyMainClass _MyMainClass;
        MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
        ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
        public MyUserControl(MyMainClass myMainClass)
        {
            _MyMainClass = myMainClass;
        }
        public void Initialize()
        {
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" >
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""1000""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <Grid>
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbTypes"" Text=""Types"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name=""dpTypes"" Grid.Row=""1""/>
        </Grid>
    </Grid>
    <GridSplitter Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Column = ""2"">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbInstances"" Text=""Instances"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name = ""dpInstances"" Grid.Row=""1""/>
        </Grid>
    </Grid>
    <GridSplitter Grid.Column = ""3"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Column = ""4"">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbContents"" Text=""Contents"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name = ""dpContents"" Grid.Row=""1"" />
        </Grid>
    </Grid>
</Grid>
";
            var grid = (Grid)(XamlReader.Parse(strxaml));
            this.Content = grid;
            grid.DataContext = this;

            var dpTypes = (DockPanel)grid.FindName("dpTypes");
            var tbTypes = (TextBox)grid.FindName("tbTypes");
            var dpInstances = (DockPanel)grid.FindName("dpInstances");
            var tbInstances = (TextBox)grid.FindName("tbInstances");
            var dpContents = (DockPanel)grid.FindName("dpContents");
            var tbContents = (TextBox)grid.FindName("tbContents");

            tbTypes.Text = $@"Select a type (Use the StringFilter)
Choose an Instance. Right-Click to see various options";
            using (var progress = new ProgressOwnUI<string>($"Enumerating types"))
            {
                try
                {
                    foreach (var type in _clrUtil.EnumerateObjectTypes(regexFilter: @"^System\.Collections\.Immutable\.Immutable(Dictionary|HashSet|List|Array|)<"))
                    {
                        if (!type.EndsWith("[]") && !type.Contains("+"))
                        {
                            ClrTypes.Add(type);
                        }
                    }
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            }

            var qTypes = from TypeName in ClrTypes
                         let InstanceCount = _clrUtil.GetObjectsOfType(TypeName).Count
                         orderby InstanceCount descending
                         select new
                         {
                             InstanceCount,
                             TypeName
                         };
            var brTypes = new BrowsePanel(qTypes, colWidths: new[] { 90 });
            dpTypes.Children.Add(brTypes);
            brTypes.BrowseList.SelectionChanged += (o, e) =>
             {
                 try
                 {
                     BrowseList lv = o as BrowseList;
                     if (lv != null && lv.SelectedItems.Count == 1)
                     {
                         dpContents.Children.Clear();
                         var selectedItem = lv.SelectedItems[0];
                         var typeName = (string)TypeDescriptor.GetProperties(selectedItem)["TypeName"].GetValue(selectedItem);
                         var oneObjOfType = _clrUtil.GetObjectsOfType(typeName);
                         var ptype = oneObjOfType[0].Type;
                         var lstObjs = _clrUtil.GetObjectsOfType(ptype.Name);
                         var qobjInstances = from obj in lstObjs
                                             let Count = obj.GetCollectionCount()
                                             orderby Count descending
                                             select new
                                             {
                                                 _clrobj = obj,
                                                 Address = obj.GetAddressAsString(),
                                                 Count,
                                                 Obj = obj.GetObjectDisplayValue(),
                                             };
                         var brInstances = new BrowsePanel(qobjInstances, colWidths: new[] { 125 });
                         _MyMainClass.AddItemsToContextMenu(brInstances);

                         dpInstances.Children.Clear();
                         dpInstances.Children.Add(brInstances);
                         tbInstances.Text = $"Instances of {ptype.Name}";
                         tbContents.Text = $"Contents";
                         brInstances.BrowseList.SelectionChanged += (oi, ei) =>
                         {
                             try
                             {
                                 BrowseList lv = oi as BrowseList;
                                 if (lv != null && lv.SelectedItems.Count == 1)
                                 {
                                     dpContents.Children.Clear();
                                     var selectedItem = lv.SelectedItems[0];
                                     var clrObj = (ClrObject)TypeDescriptor.GetProperties(selectedItem)["_clrobj"].GetValue(selectedItem);
                                     if (clrObj.Type.Name.StartsWith("System.Collections.Immutable.ImmutableHashSet"))
                                     {
                                         var lstObjs = new List<ClrObject>();
                                         clrObj.EnumerateCollectionContent((objOrValue) =>
                                         {
                                             if (objOrValue is ClrValueType oValue)
                                             {
                                                 var fldFirstValue = oValue.Type.GetFieldByName("_firstValue");
                                                 if (fldFirstValue.Type.ElementType != ClrElementType.Struct)
                                                 {
                                                     var o = oValue.ReadObjectField("_firstValue");
                                                     if (o.IsValid)
                                                     {
                                                         lstObjs.Add(o);
                                                     }
                                                 }
                                                 else
                                                 {
                                                     var valStruct = fldFirstValue.ReadStruct(oValue.Address, interior: true);

                                                 }
                                             }
                                             else if (objOrValue is ClrObject oObj)
                                             {
                                                 lstObjs.Add(oObj);
                                             }
                                             return true;
                                         });
                                         var qContent = from obj in lstObjs
                                                        select new
                                                        {
                                                            _clrobj = obj,
                                                            Address = obj.GetAddressAsString(),
                                                            Obj = obj.GetObjectDisplayValue(),
                                                        };
                                         var brContents = new BrowsePanel(qContent);
                                         dpContents.Children.Add(brContents);
                                         _MyMainClass.AddItemsToContextMenu(brContents);
                                     }
                                     else if (clrObj.Type.Name.StartsWith("System.Collections.Immutable.ImmutableDictionary"))
                                     {
                                         var dictContent = new Dictionary<string, ClrObject>();
                                         clrObj.EnumerateCollectionContent((objOrValue) =>
                                         {
                                             if (objOrValue is ClrValueType oKeyNode)
                                             {
                                                 var ofirstValue = oKeyNode.ReadValueTypeField("_firstValue");
                                                 var oKey = ofirstValue.ReadObjectField("key");
                                                 var fldValue = ofirstValue.Type.GetFieldByName("value");
                                                 if (fldValue.Type.ElementType != ClrElementType.Struct)
                                                 {
                                                     var oValue = ofirstValue.ReadObjectField("value");
                                                     if (oValue.IsValid)
                                                     {
                                                         dictContent[oKey.GetObjectDisplayValue()] = oValue;
                                                     }
                                                 }
                                                 else
                                                 {
                                                     var valStruct = fldValue.ReadStruct(ofirstValue.Address, interior: true);
                                                     switch (valStruct.Type.Name)
                                                     {
                                                         case "System.Collections.Immutable.ImmutableArray<System.__Canon>":
                                                             //foreach (var fld in valStruct.Type.Fields)
                                                             //{
                                                             //    _mainWindowClrObjExp.AddStatusMsg($"  flds {fld} '{fld.Name}' {fld.Type.Name}   ET={fld.Type.ElementType}");
                                                             //}
                                                             var array = valStruct.ReadObjectField("array");
                                                             if (array.IsValid)
                                                             {
                                                                 var oArray = array.AsArray();
                                                                 for (var ndx = 0; ndx < oArray.Length; ndx++)
                                                                 {
                                                                     var elem = oArray.GetObjectValue(ndx);
                                                                     if (elem.IsValid)
                                                                     {
                                                                         dictContent[oKey.GetObjectDisplayValue()] = elem;
                                                                     }
                                                                 }
                                                             }
                                                             break;
                                                     }
                                                 }
                                             }
                                             return true;
                                         }, _mainWindowClrObjExp);
                                         var qContent = from obj in dictContent
                                                        select new
                                                        {
                                                            obj.Key,
                                                            _clrobj = obj.Value,
                                                            Address = obj.Value.GetAddressAsString(),
                                                            Obj = obj.Value.GetObjectDisplayValue(),
                                                        };
                                         var brContents = new BrowsePanel(qContent);
                                         dpContents.Children.Add(brContents);
                                         _MyMainClass.AddItemsToContextMenu(brContents);
                                     }
                                     else if (clrObj.Type.Name.StartsWith("System.Collections.Immutable.ImmutableList"))
                                     {
                                         var lstobjs = new List<ClrObject>();
                                         clrObj.EnumerateCollectionContent((objOrValue) =>
                                         {
                                             lstobjs.Add((ClrObject)objOrValue);
                                             return true;
                                         });
                                         var qContent = from obj in lstobjs
                                                        select new
                                                        {
                                                            _clrobj = obj,
                                                            Address = obj.GetAddressAsString(),
                                                            Obj = obj.GetObjectDisplayValue(),
                                                        };
                                         var brContents = new BrowsePanel(qContent);
                                         _MyMainClass.AddItemsToContextMenu(brContents);
                                         dpContents.Children.Add(brContents);
                                     }
                                     else if (clrObj.Type.Name.StartsWith("System.Collections.Immutable.ImmutableArray"))
                                     {
                                         var oarray = clrObj.GetObjectMember("array");
                                         var objArray = oarray.AsArray();
                                         var nElem = objArray.Length;
                                         var lstobjs = new List<ClrObject>();
                                         oarray.EnumerateRefsOfObject((oChild) =>
                                         {
                                             lstobjs.Add(oChild);
                                             return true; // continue 
                                         });
                                         var qContent = from obj in lstobjs
                                                        select new
                                                        {
                                                            _clrobj = obj,
                                                            Address = obj.GetAddressAsString(),
                                                            Obj = obj.GetObjectDisplayValue(),
                                                        };
                                         var brContents = new BrowsePanel(qContent);
                                         _MyMainClass.AddItemsToContextMenu(brContents);
                                         dpContents.Children.Add(brContents);
                                     }
                                 }
                             }
                             catch (Exception ex)
                             {
                                 _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                             }
                         };
                     }
                 }
                 catch (Exception ex)
                 {
                     _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                 }
             };
        }
    }
}
