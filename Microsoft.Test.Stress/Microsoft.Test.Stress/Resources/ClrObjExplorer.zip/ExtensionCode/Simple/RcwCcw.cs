﻿//Desc: RCW/CCW

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: ..\util\BaseExtension.cs

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using ClrLib;
using ClrObjExplorer;
using Utility;
using Microsoft.Diagnostics.Runtime;


namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }
        private void DoMainInternal()
        {
            using (var _progress = new ProgressOwnUI<string>("Finding RcwCcw"))
            {
                var lstRcw = new List<RuntimeCallableWrapper>();
                var lstCcw = new List<ComCallableWrapper>();
                var hashVisited = new SortedList<ulong, HashSet<ulong>>();
                void ProcessObj(ClrObject obj)
                {
                    if (obj.IsValid)
                    {
                        var hashPart = hashVisited.GetPartitionForObject(obj.Address, _clrUtil.PartitionMask);
                        if (!hashPart.Contains(obj.Address))
                        {
                            hashPart.Add(obj.Address);
                            if (obj.HasRuntimeCallableWrapper)
                            {
                                var rcw = obj.GetRuntimeCallableWrapper();
                                lstRcw.Add(rcw);
                            }
                            if (obj.HasComCallableWrapper)
                            {
                                var ccw = obj.GetComCallableWrapper();
                                lstCcw.Add(ccw);
                            }
                        }
                    }
                }
                foreach (var obj in _clrUtil._heap.EnumerateObjects())
                {
                    ProcessObj(obj);
                }
                foreach ((ClrStaticField statfld, ClrObject oroot) in _clrUtil.clrRuntime.EnumerateStaticVars())
                {
                    ProcessObj(oroot);
                }
                foreach (var root in _clrUtil._heap.EnumerateRoots()) // could yield dupes
                {
                    ProcessObj(root.Object);
                }
                var qrcw = from rcw in lstRcw
                           let _obj = _clrUtil._heap.GetObject(rcw.Object)
                           select new
                           {
                               ObjAddress = _obj.GetAddressAsString(),
                               ObjType = _obj.Type?.Name,
                               RCWId = MakeAnIdentifier(rcw.Interfaces),
                               Address = MyAddrFormatter.AddrFormat($"{rcw.Address:x}"),
                               VTablePointer = MyAddrFormatter.AddrFormat($"{rcw.VTablePointer:x}"),
                               ManagedThreadId = rcw.CreatorThread?.ManagedThreadId,
                               rcw.RefCount,
                               rcw.IsDisconnected
                           };

                var qAggrcw = from rcw in lstRcw
                              let RcwId = MakeAnIdentifier(rcw.Interfaces)
                              group rcw by RcwId into grp
                              orderby grp.Count() descending
                              select new
                              {
                                  Count = grp.Count(),
                                  RcwId = grp.Key
                              };
                CloseableTabItem AddCtrls(string desc, IEnumerable qAgg, IEnumerable q)
                {
                    var brAgg = new BrowsePanel(qAgg);
                    var br = new BrowsePanel(q, colWidths: new[] { MainWindowClrObjExp.AddrColWidth, 300, 600, MainWindowClrObjExp.AddrColWidth, MainWindowClrObjExp.AddrColWidth });
                    var ctrls = _mainWindowClrObjExp.AddNewCloseableTabItem(desc, "");
                    var grid = new Grid();
                    ctrls.Content = grid;
                    grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(500)});
                    grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(3) });
                    grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
                    Grid.SetRow(brAgg, 0);
                    grid.Children.Add(brAgg);
                    var splitter = new GridSplitter() { HorizontalAlignment = HorizontalAlignment.Stretch, Height = 3 };
                    Grid.SetRow(splitter, 1);
                    grid.Children.Add(splitter);
                    Grid.SetRow(br, 2);
                    grid.Children.Add(br);
                    return ctrls;
                }
                AddCtrls("RCW", qAggrcw, qrcw);
                var qccw = from ccw in lstCcw
                           let _obj = _clrUtil._heap.GetObject(ccw.Object)
                           select new
                           {
                               ObjAddress = _obj.GetAddressAsString(),
                               Obj = _obj.GetObjectDisplayValue(),
                               CCWId = MakeAnIdentifier(ccw.Interfaces),
                               Address = MyAddrFormatter.AddrFormat($"{ccw.Address:x}"),
                               Handle = MyAddrFormatter.AddrFormat($"{ccw.Handle:x}"),
                               IUnknown = MyAddrFormatter.AddrFormat($"{ccw.IUnknown:x}"),
                               ccw.RefCount
                           };
                var qAggCcw = from ccw in lstCcw
                              let _obj = _clrUtil._heap.GetObject(ccw.Object)
                              let ccwId = MakeAnIdentifier(ccw.Interfaces)
                              group ccw by _obj.Type?.Name into grp
                              orderby grp.Count() descending
                              select new
                              {
                                  Count = grp.Count(),
                                  ObjType = grp.Key
                              };
                AddCtrls("CCW", qAggCcw, qccw);
            }
        }
        string MakeAnIdentifier(ImmutableArray<ComInterfaceData> interfaces)
        {
            var ident = string.Empty;
            foreach (var intfc in interfaces)
            {
                if (intfc.Type != null)
                {
                    if (!string.IsNullOrEmpty(ident))
                    {
                        ident += ";";
                    }
                    ident += intfc.Type.Name;
                }
            }
            return ident;
        }
    }
}
