﻿//Desc: Utility to show WPF elements in a Treeview


using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using System.Reflection.Emit;
using System.Runtime.Remoting.Messaging;

namespace ClrObjExtension
{
    public class WpfTreeViewPanel : UserControl, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        void RaisePropChanged([CallerMemberName] string propName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }
        public MainWindowClrObjExp _mainWindowClrObjExp;
        public WpfTreeView _WpfTreeView;
        public string txtSearch { get; set; }
        public int NumItems { get; set; }
        public WpfTreeViewPanel(MainWindowClrObjExp mainWindowClrObjExp)
        {
            _mainWindowClrObjExp = mainWindowClrObjExp;
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                System.Reflection.Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
$@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@">
    <Grid.RowDefinitions>
        <RowDefinition Height=""Auto""/>
        <RowDefinition Height=""*""/>
    </Grid.RowDefinitions>
    <StackPanel Orientation=""Horizontal"">
        <Label Content=""# items = ""/>
        <TextBlock Text=""{Binding NumItems}"" Margin=""0,0,10,0""/>
        <Label Content=""FindInTree""/>
        <TextBox x:Name=""txtSearch"" Text=""{Binding txtSearch}"" Width = ""200"" ToolTip=""Find or find next""/>
        <Button x:Name=""btnSearch"" Content=""Search""/>
    </StackPanel>
    <l:WpfTreeView x:Name = ""wpfTreeView"" Grid.Row=""1""/>
</Grid>
";
            //      <l:WpfTreeView x:Name = ""wpfTreeView"" Grid.Row=""1"" VirtualizingStackPanel.IsVirtualizing = ""True"" VirtualizingStackPanel.VirtualizationMode=""Recycling"" />


            this.DataContext = this;
            var grid = (Grid)XamlReader.Parse(strxaml);
            _WpfTreeView = (WpfTreeView)grid.FindName("wpfTreeView");
            _WpfTreeView._mainWindowClrObjExp = mainWindowClrObjExp;
            this.Content = grid;
            int initiallastSearchResult = 1;
            int lastSearchResult = initiallastSearchResult;
            var btnSearch = (Button)grid.FindName("btnSearch");
            var tbxSearch = (TextBox)grid.FindName("txtSearch");
            tbxSearch.TextChanged += (_, __) => { lastSearchResult = initiallastSearchResult; };
            _WpfTreeView.ItemAdded += (o, e) =>
            {
                NumItems++;
                RaisePropChanged(nameof(NumItems));
                lastSearchResult = initiallastSearchResult;
            };
            _WpfTreeView.SelectedItemChanged += (_, __) => { lastSearchResult = -1; };
            btnSearch.Click += (_, __) =>
            {
                try
                {
                    if (!string.IsNullOrEmpty(txtSearch))
                    {
                        var currentordinal = 0;
                        var targ = FindTreeViewItem(_WpfTreeView, (node) =>
                        {
                            if (node.ToString().IndexOf(txtSearch, StringComparison.OrdinalIgnoreCase) != -1)
                            {
                                currentordinal++;
                                //                                if (currentordinal == lastSearchResult)
                                {
                                    lastSearchResult++;
                                    _mainWindowClrObjExp.AddStatusMsg($"   Search GTV {lastSearchResult} {node}");
                                    return true;
                                }
                            }
                            return false;
                        });
                        if (targ != null)
                        {
                            targ.IsSelected = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            };
        }
        //private TreeViewItem FindTreeViewItem(ItemsControl container, Func<ItemsControl, bool> predicate, bool CollapseIntermediateNodes = false, int nLevel = 0)
        //{
        //    if (container == null) return null;
        //    _mainWindowClrObjExp.AddStatusMsg($"  {new string(' ', nLevel)} GTT  {container}");
        //    predicate(container);
        //    for (int i = 0; i < container.Items.Count; i++)
        //    {
        //        FindTreeViewItem((TreeViewItem)(container.Items[i]), predicate, CollapseIntermediateNodes, nLevel + 1);
        //    }
        //    return null;
        //}

        /// <summary>
        /// Recursively search for an item in this subtree.
        /// </summary>
        /// <param name="container">
        /// The parent ItemsControl. This can be a TreeView or a TreeViewItem.
        /// </param>
        /// <returns>
        /// The TreeViewItem that contains the specified item.
        /// </returns>
        private TreeViewItem FindTreeViewItem(ItemsControl container, Func<ItemsControl, bool> predicate, bool CollapseIntermediateNodes = false, int nLevel = 0)
        {
            if (container != null)
            {
                _mainWindowClrObjExp.AddStatusMsg($"  {new string(' ', nLevel)} GTV  {container}");
                if (predicate(container))
                {
                    _mainWindowClrObjExp.AddStatusMsg($"  GTV Success {container}");
                    return container as TreeViewItem;
                }
                // Expand the current container
                if (container is TreeViewItem && !((TreeViewItem)container).IsExpanded)
                {
                    container.SetValue(TreeViewItem.IsExpandedProperty, true);
                }

                // Try to generate the ItemsPresenter and the ItemsPanel.
                // by calling ApplyTemplate.  Note that in the
                // virtualizing case even if the item is marked
                // expanded we still need to do this step in order to
                // regenerate the visuals because they may have been virtualized away.

                container.ApplyTemplate();
                ItemsPresenter itemsPresenter = (ItemsPresenter)container.Template.FindName("ItemsHost", container);
                if (itemsPresenter != null)
                {
                    itemsPresenter.ApplyTemplate();
                }
                else
                {
                    // The Tree template has not named the ItemsPresenter,
                    // so walk the descendents and find the child.
                    itemsPresenter = FindVisualChild<ItemsPresenter>(container);
                    if (itemsPresenter == null)
                    {
                        container.UpdateLayout();

                        itemsPresenter = FindVisualChild<ItemsPresenter>(container);
                    }
                }

                Panel itemsHostPanel = (Panel)VisualTreeHelper.GetChild(itemsPresenter, 0);

                // Ensure that the generator for this panel has been created.
                UIElementCollection children = itemsHostPanel.Children;
                //for (int i = 0; i < container.Items.Count; i++)
                //{
                //    FindTreeViewItem((TreeViewItem)(container.Items[i]), predicate, CollapseIntermediateNodes, nLevel + 1);
                //}

                var virtualizingPanel = itemsHostPanel as VirtualizingStackPanel;

                for (int i = 0, count = container.Items.Count; i < count; i++)
                {
                    TreeViewItem subContainer;
                    if (virtualizingPanel != null)
                    {
                        // Bring the item into view so
                        // that the container will be generated.
                        virtualizingPanel.BringIntoView();

                        subContainer =
                            (TreeViewItem)container.ItemContainerGenerator.
                            ContainerFromIndex(i);
                    }
                    else
                    {
                        subContainer =
                            (TreeViewItem)container.ItemContainerGenerator.
                            ContainerFromIndex(i);

                        // Bring the item into view to maintain the
                        // same behavior as with a virtualizing panel.
                        subContainer.BringIntoView();
                        _mainWindowClrObjExp.AddStatusMsg($"  GTV BringN {subContainer}");
                    }

                    if (subContainer != null)
                    {
                        // Search the next level for the object.
                        TreeViewItem resultContainer = FindTreeViewItem(subContainer, predicate, CollapseIntermediateNodes, nLevel + 1);
                        if (resultContainer != null)
                        {
                            return resultContainer;
                        }
                        else
                        {
                            if (CollapseIntermediateNodes)
                            {
                                _mainWindowClrObjExp.AddStatusMsg($"  GTV collapse {subContainer}");
                                // The object is not under this TreeViewItem
                                // so collapse it.
                                subContainer.IsExpanded = false;
                            }
                        }
                    }
                    else
                    {
                        _mainWindowClrObjExp.AddStatusMsg($"  GTV nullsubc {container.Items[i]}");
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Search for an element of a certain type in the visual tree.
        /// </summary>
        /// <typeparam name="T">The type of element to find.</typeparam>
        /// <param name="visual">The parent element.</param>
        /// <returns></returns>
        private T FindVisualChild<T>(Visual visual) where T : Visual
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(visual); i++)
            {
                Visual child = (Visual)VisualTreeHelper.GetChild(visual, i);
                if (child != null)
                {
                    T correctlyTyped = child as T;
                    if (correctlyTyped != null)
                    {
                        return correctlyTyped;
                    }

                    T descendent = FindVisualChild<T>(child);
                    if (descendent != null)
                    {
                        return descendent;
                    }
                }
            }

            return null;
        }
        public void Clear()
        {
            NumItems = 0;
            RaisePropChanged(nameof(NumItems));
            _WpfTreeView.Items.Clear();
        }
    }

    public delegate void ItemAddedEventHandler(object sender, ItemAddedEventArgs e);
    public class ItemAddedEventArgs
    {
        public WpfTreeViewItem ItemAdded;
        public ItemAddedEventArgs(WpfTreeViewItem itemAdded)
        {
            this.ItemAdded = itemAdded;
        }
    }
    public class WpfTreeView : MyTreeViewBase
    {
        public event ItemAddedEventHandler ItemAdded;
        public static string WpfBaseType = "System.Windows.DependencyObject";
        public MainWindowClrObjExp _mainWindowClrObjExp;
        public ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
        public WpfTreeView()
        {
            //VirtualizingStackPanel.SetIsVirtualizing(this, false);
            //SetValue(ScrollViewer.IsDeferredScrollingEnabledProperty, true);
            //VirtualizingStackPanel.SetVirtualizationMode(this, VirtualizationMode.Standard);
            //SetValue(VirtualizingStackPanel.IsVirtualizingProperty, true);
            //SetValue(VirtualizingStackPanel.VirtualizationModeProperty, VirtualizationMode.Recycling);
            //SetValue(ScrollViewer.IsDeferredScrollingEnabledProperty, true);
            this.ContextMenu.AddMenuItem((_, _) =>
            {
                try
                {
                    var sel = this.SelectedItem as WpfTreeViewItem;
                    if (sel != null)
                    {
                        ObjRefView.MakeObjRefTree(_clrUtil, sel._clrObject, _mainWindowClrObjExp);
                    }
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }

            }, "_References", "Show Object References", InsertPos: 0);
            this.ContextMenu.AddMenuItem((_, __) =>
            {
                try
                {
                    var tvitem = this.SelectedItem as WpfTreeViewItem;
                    if (tvitem != null)
                    {
                        var strAddrDump = tvitem._clrObject.GetToolTipAsString(nMaxDumpSize: 0);
                        BrowseList.WriteOutputToTempFile(strAddrDump);
                    }
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            }, "_Dump Tooltip To Notepad", "", InsertPos: 0);
            this.MouseMove += (_, e) =>
            {
                try
                {
                    var tb = e.OriginalSource as TextBlock;
                    if (tb != null && tb.Tag != null && (int)tb.Tag == 1) // tooltip only on the arrow
                    {
                        var tvitem = UtilityUI.GetAncestor<WpfTreeViewItem>(tb);
                        if (tvitem != null && !tvitem.IsDummyItem && tb.ToolTip== null)
                        {
                            var tip = new MyToolTip(tb, (tip) =>
                            {
                                var strAddrDump = tvitem._clrObject.GetToolTipAsString(nMaxDumpSize: 1024);
                                var tbxDump = new TextBox()
                                {
                                    Text = strAddrDump,
                                    BorderThickness = new System.Windows.Thickness(0),
                                    FontFamily = new FontFamily("Courier New"),
                                    FontSize = _mainWindowClrObjExp._options.ToolTipFontSize,
                                    Background = Brushes.LightYellow
                                };
                                tip.Content = tbxDump;
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            };
        }
        public void Initialize(ClrObject clrObj)
        {
            Items.Clear();
            var tvItem = new WpfTreeViewItem(this, clrObj);
            this.Items.Add(tvItem);
            ItemAdded?.Invoke(this, new ItemAddedEventArgs(tvItem));
            tvItem.IsExpanded = true;
        }
        public UIElement ShowEffectiveValues(ClrObject clrObj)
        {
            var effVals = clrObj.GetEffectiveValues();
            var q = from effval in effVals
                    let elemObj = _clrUtil._heap.GetObject((ulong)effval._value.ToInt64())
                    where elemObj.IsValid
                    let PropertyName = _clrUtil._dictDependencyProperties.Value.ContainsKey(effval._propertyIndex) ? _clrUtil._dictDependencyProperties.Value[effval._propertyIndex].PropertyName : ""
                    orderby PropertyName
                    select new
                    {
                        _clrobj = elemObj,
                        Address = elemObj.GetAddressAsString(),
                        PropertyIndex = effval._propertyIndex,
                        FullValueSource = ((int)effval._source).ToString("x4"),
                        PropertyName,
                        Value = elemObj.GetObjectDisplayValue()
                    };
            var brEffVal = new BrowsePanel(q);
            return brEffVal;
        }

        public void DoPossiblyModifiedValue(ClrObject clrObj, EffectiveValueEntry effVal, Action<ClrObject> act)
        {
            if (clrObj.IsValid)
            {
                if (clrObj.Type.Name == "System.Windows.ModifiedValue")
                {
                    if (effVal._source.HasFlag(FullValueSource.IsCoerced) || effVal._source.HasFlag(FullValueSource.IsCoercedWithCurrentValue))
                    {
                        var coercedValue = clrObj.GetObjectMember("_coercedValue");
                        if (coercedValue.IsValid)
                        {
                            act(coercedValue);
                        }
                    }
                    else
                    {
                        var expressionValue = clrObj.GetObjectMember("_expressionValue");
                        if (expressionValue.IsValid)
                        {
                            act(expressionValue);
                        }
                    }
                }
                else if (clrObj.Type.Name == "Microsoft.VisualStudio.Platform.WindowManagement.WindowFrameTitle")
                {
                    var title = clrObj.GetEffectiveValue("Title");
                    if (title != null)
                    {
                        var otitle = _clrUtil._heap.GetObject((ulong)title.Value._value.ToInt64());
                        if (otitle.IsValid)
                        {
                            DoPossiblyModifiedValue(otitle, effVal, act); // recur
                        }
                    }
                }
                else
                {
                    act(clrObj);
                }
            }
        }
        public void DoWpfObject(ClrObject clrObj, Func<ClrObject, WpfTreeViewItem> actChild)
        {
            //            _mainWindowClrObjExp.AddStatusMsg($"{nameof(DoWpfObject)} {clrObj}");
            if (!clrObj.IsValid)
            {
                return;
            }
            if (clrObj.InheritsFrom("System.Windows.Controls.ContentControl") ||
                clrObj.InheritsFrom("System.Windows.Controls.ContentPresenter") ||
                clrObj.InheritsFrom("Microsoft.VisualStudio.PlatformUI.Shell.View"))
            {
                if (clrObj.InheritsFrom("System.Windows.Controls.HeaderedContentControl"))
                {
                    var headerEffVal = clrObj.GetEffectiveValue("Header");
                    if (headerEffVal != null)
                    {
                        var header = _clrUtil._heap.GetObject((ulong)headerEffVal.Value._value.ToInt64());
                        if (header.IsValid && !header.Type.IsValueType && !header.Type.IsString)  // don't add a simple string as a child to reduce clutter
                        {
                            actChild(header);
                        }
                    }
                }
                var contentEffVal = clrObj.GetEffectiveValue("Content");
                if (contentEffVal != null)
                {
                    var contentObj = _clrUtil._heap.GetObject((ulong)contentEffVal.Value._value.ToInt64());
                    if (contentObj.IsValid && !contentObj.Type.IsValueType && !contentObj.Type.IsString) // don't add a simple string as a child to reduce clutter
                    {
                        DoPossiblyModifiedValue(contentObj, contentEffVal.Value, (obj =>
                        {
                            actChild(obj);
                        }));
                    }
                }
            }
            else if (clrObj.InheritsFrom("System.Windows.Controls.Panel")) // notdp _uiElementCollection
            {
                var uielementCollection = clrObj.GetObjectMember("_uiElementCollection");
                if (uielementCollection.IsValid)
                {
                    var visualChildren = uielementCollection.GetObjectMember("_visualChildren"); // System.Windows.Media.VisualCollection
                    if (visualChildren.IsValid)
                    {
                        var oitems = visualChildren.GetObjectMember("_items");
                        if (oitems.IsValid && oitems.IsArray)
                        {
                            var items = oitems.AsArray(); //System.Windows.Media.Visual[]
                            for (int i = 0; i < items.Length; i++)
                            {
                                var obj = items.GetObjectValue(i);
                                if (obj.IsValid)
                                {
                                    actChild(obj);
                                }
                            }
                        }
                    }
                }
            }
            else if (clrObj.InheritsFrom("System.Windows.Controls.ItemsControl"))
            {
                var itemsHost = clrObj.GetObjectMember("_itemsHost");
                if (itemsHost.IsValid)
                {
                    actChild(itemsHost);
                }
                else
                {
                    var items = clrObj.GetObjectMember("_items");
                    if (items.IsValid)
                    {
                        void DoArrayList(ClrObject arrayList)
                        {
                            if (arrayList.IsValid)
                            {
                                var viewListItems = arrayList.GetObjectMember("_items"); // System.Object[]
                                if (viewListItems.IsValid && viewListItems.IsArray)
                                {
                                    var viewlistItemsArray = viewListItems.AsArray();
                                    for (int i = 0; i < viewlistItemsArray.Length; i++)
                                    {
                                        var oChild = viewlistItemsArray.GetObjectValue(i);
                                        if (oChild.IsValid)
                                        {
                                            actChild(oChild);
                                        }
                                    }
                                }
                            }
                        }
                        var internalView = items.GetObjectMember("_internalView"); // MS.Internal.Controls.InnerItemCollectionView
                        if (internalView.IsValid)
                        {
                            var viewList = internalView.GetObjectMember("_viewList"); // System.Collections.ArrayList
                            if (viewList.IsValid)
                            {
                                DoArrayList(viewList);
                            }
                        }
                        var collectionView = items.GetObjectMember("_collectionView"); // MS.Internal.Data.EnumerableCollectionView
                        if (collectionView.IsValid)
                        {
                            var view = collectionView.GetObjectMember("_view"); // System.Windows.Data.ListCollectionView
                            if (view.IsValid)
                            {
                                var internalList = view.GetObjectMember("_internalList"); // System.Collections.ArrayList
                                DoArrayList(internalList);
                            }
                        }
                    }
                }
            }
            else if (clrObj.InheritsFrom("System.Windows.Controls.Decorator")) // _child System.Windows.UIElement
            {
                var child = clrObj.GetObjectMember("_child");
                if (child.IsValid)
                {
                    actChild(child);
                }
            }
            else if (clrObj.InheritsFrom("System.Windows.Controls.ContentPresenter")) // dp Content
            {
                var contentEffVal = clrObj.GetEffectiveValue("Content");
                if (contentEffVal != null)
                {
                    var contentObj = _clrUtil._heap.GetObject((ulong)contentEffVal.Value._value.ToInt64());
                    if (contentObj.IsValid)
                    {
                        actChild(contentObj);
                    }
                }
            }
            else if (clrObj.InheritsFrom("Microsoft.VisualStudio.PlatformUI.Shell.ViewGroup"))
            {
                var oitems = clrObj.GetObjectMember("visibleChildren")
                    .GetObjectMember("items")
                    .GetObjectMember("_items");
                if (oitems.IsValid && oitems.IsArray)
                {
                    var items = oitems.AsArray(); //System.Windows.Media.Visual[]
                    for (int i = 0; i < items.Length; i++)
                    {
                        var obj = items.GetObjectValue(i);
                        if (obj.IsValid)
                        {
                            actChild(obj);
                        }
                    }
                }
            }
        }

        public string GetWpfExtraInfoFromEffectiveValues(ClrObject clrObj, StackPanel sp = null)
        {
            var retVal = string.Empty;
            GetStringOrModifiedValue(clrObj, "Name");
            GetStringOrModifiedValue(clrObj, "Header");
            GetStringOrModifiedValue(clrObj, "Text");
            GetStringOrModifiedValue(clrObj, "Title");
            if (clrObj.InheritsFrom("System.Windows.Controls.ContentControl")) // like a Button or Label with just simple text
            {
                GetStringOrModifiedValue(clrObj, "Content");
            }
            return retVal;
            void GetStringOrModifiedValue(ClrObject clrO, string EffValueName)
            {
                var effVal = clrO.GetEffectiveValue(EffValueName);
                if (effVal != null)
                {
                    var val = _clrUtil._heap.GetObject((ulong)effVal.Value._value.ToInt64());
                    if (val.IsValid)
                    {
                        DoPossiblyModifiedValue(val, effVal.Value, (obj =>
                        {
                            var value = obj.GetObjectDisplayValue();
                            retVal += $"{EffValueName}='{value}'";
                            if (sp != null)
                            {
                                sp.Children.Add(new TextBlock() { Text = $" {EffValueName}=", FontWeight = FontWeights.Bold });
                                sp.Children.Add(new TextBlock() { Text = $"{value}", Foreground = Brushes.DarkCyan });
                            }
                        }));
                    }
                }
            }
        }
        public void ItemWasAdded(WpfTreeViewItem newitem)
        {
            ItemAdded?.Invoke(this, new ItemAddedEventArgs(newitem));
        }
    }

    public class WpfTreeViewItem : MyTreeViewItem
    {
        WpfTreeView _tv;
        public readonly ClrObject _clrObject;
        public WpfTreeViewItem(WpfTreeView tv, ClrObject clrObject)
        {
            this._clrObject = clrObject;
            this._tv = tv;
            this.Expanded += (o, e) =>
            {
                try
                {
                    if (this.IsDummyItem)
                    {
                        Items.Clear();//clear dummy
                        _tv.DoWpfObject(_clrObject, (oChild) =>
                        {
                            var newItem = new WpfTreeViewItem(_tv, oChild);
                            this.Items.Add(newItem);
                            _tv.ItemWasAdded(newItem);
                            newItem.IsExpanded = true;
                            return newItem;
                        });
                    }
                    e.Handled = true;
                }
                catch (Exception ex)
                {
                    _tv._mainWindowClrObjExp.AddStatusMsg($"{ex}");
                }
            };
            var sp = new StackPanel() { Orientation = Orientation.Horizontal };
            Header = sp;

            sp.Children.Add(new TextBlock() { Text = "->", Tag = 1, Background = Brushes.LightSalmon });
            sp.Children.Add(new TextBlock() { Text = $"{clrObject.GetObjectDisplayValue()}", Tag = 0 });
            _tv.GetWpfExtraInfoFromEffectiveValues(_clrObject, sp);

            this.Items.Add(new MyTreeViewItem()); // add a dummy
        }

        public bool IsDummyItem => this.Items.Count == 1 && (this.Items[0].GetType().Name == "MyTreeViewItem");
        public override string ToString() => $"{_clrObject.GetObjectDisplayValue()} {_tv.GetWpfExtraInfoFromEffectiveValues(_clrObject)}";
    }
}
