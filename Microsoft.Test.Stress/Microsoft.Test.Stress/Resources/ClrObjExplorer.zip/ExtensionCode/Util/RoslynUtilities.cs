﻿//Desc: Roslyn Utilities: to be included via '//Include:' add references for Extensions

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;

namespace ClrObjExtension
{
    public static class RoslynExtensionMethods
    {
        public static int GetRoslynImmutableHashSetCount(this ClrObject obj)
        {
            var cnt = 0;
            if (obj.IsValid)
            {
                var Root = obj.GetObjectMember("_root");
                if (Root.IsValid)
                {
                    if (Root.Type.Name.EndsWith("+ValueBucket"))
                    {
                        cnt = 1;
                    }
                    else if (Root.Type.Name.EndsWith("+HashBucket"))
                    {
                        cnt = Root.ReadField<Int32>("_count");
                    }
                    else if (Root.Type.Name.EndsWith("+HashBucket"))
                    {
                        //                        cnt = Root.ReadField<Int32>("_count");
                    }
                }
            }
            return cnt;
        }
        public static string GetRoslynDisplayData(this ClrObject clrObj)
        {
            var str = string.Empty;
            if (clrObj.Type.Name == "Microsoft.CodeAnalysis.ProjectId" || clrObj.Type.Name == "Microsoft.CodeAnalysis.DocumentId")
            {
                var debugname = clrObj.GetObjectMember("_debugName").GetObjectDisplayValue();
                var guid = clrObj.ReadField<Guid>("<Id>k__BackingField");
                str = $"{debugname} {guid}";
            }
            else if (clrObj.Type.Name == "Microsoft.CodeAnalysis.Document")
            {
                str = clrObj.GetObjectMember("<State>k__BackingField")
                            .GetObjectMember("<TextAndVersionSource>k__BackingField")
                            .GetObjectMember("_filePath")
                            .GetObjectDisplayValue();

            }
            else
            {
                str = clrObj.GetObjectDisplayValue();
            }
            return str;
        }

        public static void GetRoslynImmutableHashSetData(this ClrObject obj, Func<ClrObject, ClrObject, bool> func) // key,value, return true to continue
        {
            var oRoot = obj.GetObjectMember("_root");
            var queue = new Queue<ClrObject>();
            queue.Enqueue(oRoot);
            while (queue.Count > 0)
            {
                var item = queue.Dequeue();
                if (item.Type.Name.EndsWith("+ValueBucket"))
                {
                    var oKey = item.GetObjectMember("Key");
                    var oValue = item.GetObjectMember("Value");
                    if (!func(oKey, oValue))
                    {
                        break;
                    }
                }
                item.EnumerateRefsOfObject((oChild) =>
                {
                    if (oChild.Type.Name.EndsWith("+HashBucket") || oChild.Type.Name.EndsWith("+Bucket[]"))
                    {
                        oChild.EnumerateRefsOfObject((oBucket) =>
                        {
                            queue.Enqueue(oBucket);
                            return true;
                        });

                    }
                    return true;
                });
            }
        }

    }
}