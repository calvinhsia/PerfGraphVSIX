﻿//Desc: Extension Base: to be included via '//Include:' add references for Extensions
// For samples of dynamically compiled code see https://github.com/calvinhsia/PerfGraphVSIX/tree/main/PerfGraphVSIX/CodeSamples

// This code will be compiled and run in the ClrObjExplorer Process. Any error msgs will be shown in the status log.
// References are automatically added to 
//   Microsoft.Diagnostics.Runtime
//   ClrLib
//   MainWindowClrObjExplorer

//Pragma: showwarnings = true
//Pragma: verbose = false
// Define where the VS root is (so the compiler can be found. Can be 32 or 64 bit)
//VSRoot: C:\Program Files (x86)\Microsoft Visual Studio\2019\Preview
//Ref: %ClrLib%
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\PresentationFramework.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\PresentationCore.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\WindowsBase.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.Xaml.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.Xml.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.ComponentModel.Composition.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.Core.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.Windows.Forms.dll

using System;
using System.Linq;
using System.Text;
using System.Threading;
using ClrLib;
using ClrObjExplorer;

namespace ClrObjExtension
{
    public class BaseExtension
    {
        protected ClrUtil _clrutil;
        protected MainWindowClrObjExp _mainWindowClrObjExp;
        protected CancellationToken _token;
        protected string _pathFileToExecute;

        public BaseExtension(object[] args)
        {
            _clrutil = (ClrUtil)args[0];
            _mainWindowClrObjExp = (MainWindowClrObjExp)args[1];
            _token = (CancellationToken)args[2];
            _pathFileToExecute = (string)args[3];
            _mainWindowClrObjExp.AddStatusMsg($"Compiling Extension {_pathFileToExecute}");
        }
    }
}