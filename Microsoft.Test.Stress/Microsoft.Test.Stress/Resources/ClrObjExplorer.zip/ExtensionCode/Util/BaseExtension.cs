﻿//Desc: Extension Base: to be included via '//Include:' add references for Extensions
// For samples of dynamically compiled code see https://github.com/calvinhsia/PerfGraphVSIX/tree/main/PerfGraphVSIX/CodeSamples

// This code will be compiled and run in the ClrObjExplorer Process. Any error msgs will be shown in the status log.
// References are automatically added to 
//   Microsoft.Diagnostics.Runtime
//   ClrLib
//   MainWindowClrObjExplorer

//Pragma: showwarnings = true
//Pragma: verbose = false
// Define where the VS root is (so the compiler can be found. Can be 32 or 64 bit)
//VSRoot: C:\Program Files (x86)\Microsoft Visual Studio\2019\Preview
//Ref: %ClrLib%
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\PresentationFramework.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\PresentationCore.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\WindowsBase.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xaml.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xml.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.ComponentModel.Composition.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Core.dll
//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Windows.Forms.dll

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;

namespace ClrObjExtension
{
    public class BaseExtension
    {
        public ClrUtil _clrUtil;
        public MainWindowClrObjExp _mainWindowClrObjExp;
        public CancellationToken _token;
        public string _pathFileToExecute;

        public BaseExtension(object[] args)
        {
            _clrUtil = (ClrUtil)args[0];
            _mainWindowClrObjExp = (MainWindowClrObjExp)args[1];
            _token = (CancellationToken)args[2];
            _pathFileToExecute = (string)args[3];
            _mainWindowClrObjExp.AddStatusMsg($"Compiling Extension {_pathFileToExecute}");
        }
    }
#nullable enable

    public static class Extensions
    {
        public static int GetCollectionCount(this ClrObject obj, MainWindowClrObjExp? _mainWindowClrObjExp = null)
        {
            int count = 0;
            if (obj.IsValid && obj.Type != null && obj.Type.Name != null)
            {
                var itemType = obj.Type.Name;
                if (!itemType.Contains("+") && !itemType.EndsWith("[]"))
                {
                    var ndxLeftAngleBracket = itemType.IndexOf("<");
                    if (ndxLeftAngleBracket > 0)
                    {
                        itemType = itemType.Substring(0, ndxLeftAngleBracket);
                    }
                    switch (itemType)
                    {
                        case "System.Collections.Concurrent.ConcurrentBag":
                            {
                                var curList = obj.GetObjectMember("^[m]?_headList", IsRegex: true);
                                while (curList.IsValid)
                                {
                                    count += curList.GetFieldValue<int>("m_count");
                                    curList = curList.ReadObjectField("m_nextList");
                                }
                            }
                            break;
                        case "System.Collections.Concurrent.ConcurrentQueue":
                            {
                                //https://github.com/dotnet/runtime/blob/57bfe474518ab5b7cfe6bf7424a79ce3af9d6657/src/libraries/System.Private.CoreLib/src/System/Collections/Concurrent/ConcurrentQueue.cs
                                var m_head = obj.GetObjectMember("^[m]?_head", IsRegex: true);
                                if (m_head.IsValid && m_head.Type != null)
                                {
                                    var fldLow = m_head.Type.GetFieldByName("m_low");
                                    if (fldLow != null)
                                    {
                                        var headlow = m_head.ReadField<int>("m_low");
                                        var m_tail = obj.ReadObjectField("m_tail");
                                        var tailhigh = m_tail.ReadField<int>("m_high");
                                        if (m_head == m_tail)
                                        {
                                            count = tailhigh - headlow + 1;
                                        }
                                        else
                                        {
                                            count = SEGMENT_SIZE - headlow; // head seg
                                            count += SEGMENT_SIZE * ((int)(m_tail.ReadField<int>("m_index") - m_head.ReadField<int>("m_index") - 1)); // middle segs
                                            count += tailhigh + 1; // tail seg
                                        }
                                    }
                                    else
                                    {
                                        var curSeg = obj.GetObjectMember("_head");
                                        var tail = obj.GetObjectMember("_tail");
                                        while (curSeg.IsValid)
                                        {
                                            var slots = curSeg.GetObjectMember("_slots");
                                            slots.EnumerateRefsOfObject((oChild) =>
                                            {
                                                count++;
                                                return true;
                                            });
                                            var nextSeg = curSeg.GetObjectMember("_nextSegment");
                                            curSeg = nextSeg;
                                        }
                                    }
                                }
                            }
                            break;
                        case "System.Collections.Concurrent.ConcurrentDictionary":
                            {
                                var m_tables = obj.GetObjectMember("^[m]?_tables", IsRegex: true);
                                var m_countPerLock = m_tables.GetObjectMember("^[m]?_countPerLock", IsRegex: true).AsArray();
                                for (int i = 0; i < m_countPerLock.Length; i++)
                                {
                                    count += m_countPerLock.GetValue<int>(i);
                                }
                            }
                            break;
                        case "System.Collections.Concurrent.ConcurrentStack":
                            {
                                var curnode = obj.GetObjectMember("^[m]?_head", IsRegex: true);
                                while (curnode.IsValid)
                                {
                                    count++;
                                    curnode = curnode.GetObjectMember("^[m]?_next", IsRegex: true);
                                }
                            }
                            break;


                        case "System.Collections.Generic.Dictionary":
                        case "System.Collections.Generic.HashSet":
                            {
                                count = obj.GetFieldValue<int>("^[m]?[_]?count", IsRegex: true);
                            }
                            break;
                        case "System.Collections.Generic.List":
                        case "System.Collections.Generic.Queue":
                        case "System.Collections.Generic.Stack":
                            {
                                count = obj.ReadField<int>("_size");
                            }
                            break;


                        case "System.Collections.Immutable.ImmutableDictionary":
                        case "System.Collections.Immutable.ImmutableHashSet":
                            count = obj.ReadField<int>("_count");
                            break;
                        case "System.Collections.Immutable.ImmutableList":
                            {
                                var oRoot = obj.GetObjectMember("_root");
                                if (oRoot.IsValid)
                                {
                                    count = oRoot.ReadField<int>("_count");
                                }
                            }
                            break;
                        case "System.Collections.Immutable.ImmutableArray":
                            {
                                var oarray = obj.GetObjectMember("array");
                                if (oarray.IsValid)
                                {
                                    var objArray = oarray.AsArray();
                                    count = objArray.Length;
                                }
                            }
                            break;
                    }
                }
            }
            return count;
        }

        public static void EnumerateCollectionContent(this ClrObject obj, Func<object, bool> act, MainWindowClrObjExp? _MainWindowClrObjExp = null)
        {
            if (obj.IsValid && obj.Type != null && obj.Type.Name != null)
            {
                var itemType = obj.Type.Name;
                if (!itemType.Contains("+") && !itemType.EndsWith("[]"))
                {
                    var ndxLeftAngleBracket = itemType.IndexOf("<");
                    if (ndxLeftAngleBracket > 0)
                    {
                        itemType = itemType.Substring(0, ndxLeftAngleBracket);
                    }
                    switch (itemType)
                    {
                        case "System.Collections.Concurrent.ConcurrentBag":
                            {
                                var curList = obj.ReadObjectField("m_headList");
                                while (curList.IsValid)
                                {
                                    var curNode = curList.ReadObjectField("m_head");
                                    while (curNode.IsValid)
                                    {
                                        var nodeval = curNode.ReadObjectField("m_value");
                                        if (!act(nodeval))
                                        {
                                            return;
                                        }
                                        curNode = curNode.ReadObjectField("m_next");
                                    }
                                    curList = curList.ReadObjectField("m_nextList");
                                }
                            }
                            break;
                        case "System.Collections.Concurrent.ConcurrentQueue":
                            {
                                var m_headSeg = obj.GetObjectMember("^[m]?_head", IsRegex: true);
                                if (m_headSeg.IsValid && m_headSeg.Type != null)
                                {
                                    var fldLow = m_headSeg.Type.GetFieldByName("m_low");
                                    if (fldLow != null)
                                    {
                                        var headlow = m_headSeg.ReadField<int>("m_low");
                                        var m_tailSeg = obj.ReadObjectField("m_tail");
                                        var tailhigh = m_tailSeg.ReadField<int>("m_high");
                                        void AddToList(ClrObject segment, int start, int end)
                                        {
                                            for (int i = start; i <= end; i++)
                                            {
                                                var segarr = segment.ReadObjectField("m_array");
                                                if (segarr.IsValid && segarr.Type != null)
                                                {
                                                    var elemAddr = segarr.Type.GetArrayElementAddress(segarr.Address, i);
                                                    ulong elemVal;
                                                    if (IntPtr.Size == 4)
                                                    {
                                                        elemVal = BitConverter.ToUInt32(ClrUtil.g_ClrUtil.ReadBytes(elemAddr, IntPtr.Size), 0);
                                                    }
                                                    else
                                                    {
                                                        elemVal = BitConverter.ToUInt64(ClrUtil.g_ClrUtil.ReadBytes(elemAddr, IntPtr.Size), 0);
                                                    }
                                                    var oChild = obj.Type.Heap.GetObject(elemVal);
                                                    if (oChild.IsValid)
                                                    {
                                                        if (!act(oChild))
                                                        {
                                                            return;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        if (m_headSeg == m_tailSeg)
                                        {
                                            AddToList(m_headSeg, headlow, tailhigh);
                                        }
                                        else
                                        {
                                            //                        int SEGMENT_SIZE = 32;
                                            AddToList(m_headSeg, headlow, SEGMENT_SIZE - 1);
                                            var currseg = m_headSeg.ReadObjectField("m_next");
                                            while (currseg != m_tailSeg)
                                            {
                                                AddToList(currseg, 0, SEGMENT_SIZE - 1);
                                                currseg = currseg.ReadObjectField("m_next");
                                            }
                                            AddToList(m_tailSeg, 0, tailhigh);
                                        }
                                    }
                                    else
                                    {
                                        var curSeg = obj.GetObjectMember("_head");
                                        var tail = obj.GetObjectMember("_tail");
                                        var fContinue = true;
                                        while (curSeg.IsValid && fContinue)
                                        {
                                            var slots = curSeg.GetObjectMember("_slots");
                                            slots.EnumerateRefsOfObject((oChild) =>
                                            {
                                                if (!act(oChild))
                                                {
                                                    fContinue = false;
                                                    return false;
                                                }
                                                return true;
                                            });
                                            var nextSeg = curSeg.GetObjectMember("_nextSegment");
                                            curSeg = nextSeg;
                                        }
                                    }
                                }
                            }
                            break;
                        case "System.Collections.Concurrent.ConcurrentDictionary":
                            {
                                var m_tables = obj.GetObjectMember("^[m]?_tables", IsRegex: true);
                                var m_buckets = m_tables.GetObjectMember("^[m]?_buckets", IsRegex: true);
                                //var m_bucketsArray = m_buckets.AsArray();
                                var elemType = obj.Type.ComponentType;
                                // m_buckets.Type.ElementType == SZArray.
                                // m_buckets.Type.ElementType.ComponentType == System.Collections.Concurrent.ConcurrentDictionary<System.String, System.Object>+Node

                                var lstNodes = new List<ClrObject>();
                                m_buckets.EnumerateReferences(ochild =>
                                {
                                    return act(ochild);
                                });
                            }
                            break;
                        case "System.Collections.Concurrent.ConcurrentStack":
                            {
                                var curnode = obj.ReadObjectField("m_head");
                                while (curnode.IsValid)
                                {
                                    var nodeval = curnode.ReadObjectField("m_value");
                                    if (!act(nodeval))
                                    {
                                        return;
                                    }
                                    curnode = curnode.ReadObjectField("m_next");
                                }
                            }
                            break;


                        case "System.Collections.Generic.HashSet":
                        case "System.Collections.Generic.Dictionary":
                            {
                                var nameEntries = itemType == "System.Collections.Generic.HashSet" ? "slots":"entries";
                                var entries = obj.GetObjectMember($"^[m]?[_]?{nameEntries}", IsRegex: true);
                                var count = obj.GetFieldValue<int>("^[m]?[_]?count", IsRegex: true);

                                if (entries.IsValid && entries.IsArray)
                                {
                                    var arrEntries = entries.AsArray(); // the array length is longer than the count
                                    for (int i = 0; i < count; i++)
                                    {
                                        var entry = arrEntries.GetStructValue(i);

                                        if (!act(entry))
                                        {
                                            break;
                                        }
                                    }
                                }
                            }
                            break;
                        case "System.Collections.Generic.List":
                            {
                                var list = obj.GetObjectMember("_items");
                                list.EnumerateRefsOfObject((ochild) =>
                                {
                                    return act(ochild);
                                });
                            }
                            break;
                        case "System.Collections.Generic.Queue":
                        case "System.Collections.Generic.Stack":
                            {
                                var list = obj.GetObjectMember("_array");
                                list.EnumerateRefsOfObject((ochild) =>
                                {
                                    return act(ochild);
                                });
                            }
                            break;

                        case "System.Collections.Immutable.ImmutableDictionary":
                        case "System.Collections.Immutable.ImmutableHashSet":
                        case "System.Collections.Immutable.ImmutableList":
                        case "System.Collections.Immutable.ImmutableArray":
                            {
                                //_MainWindowClrObjExp?.AddStatusMsg($"{obj}");
                                var root = obj.GetObjectMember("_root"); // System.Collections.Immutable.SortedInt32KeyNode`1[[System.Collections.Immutable.ImmutableDictionary`2+HashBucket[TKey,TValue], System.Collections.Immutable]]
                                var queue = new Queue<ClrObject>();
                                queue.Enqueue(root);
                                while (queue.Count > 0)
                                {
                                    var node = queue.Dequeue();
                                    var left = node.GetObjectMember("_left");
                                    if (left.IsValid)
                                    {
                                        queue.Enqueue(left);
                                    }
                                    var right = node.GetObjectMember("_right");
                                    if (right.IsValid)
                                    {
                                        queue.Enqueue(right);
                                    }
                                    var valuefld = node.Type?.GetFieldByName("_value");
                                    if (valuefld != null)
                                    {
                                        var firstvalue = node.ReadValueTypeField("_value");
                                        if (firstvalue.IsValid)
                                        {
                                            act(firstvalue);
                                            var objaddl = firstvalue.ReadObjectField("_additionalElements");
                                            if (objaddl.IsValid)
                                            {
                                                var count = objaddl.ReadField<int>("_count");
                                                if (count > 0)
                                                {
                                                    EnumerateCollectionContent(objaddl, (obj) =>
                                                    {
                                                        return act(obj);
                                                    });
                                                }
                                            }
                                            var keyFld = firstvalue.Type?.GetFieldByName("_key");
                                            if (keyFld != null)
                                            {
                                                var oKey = node.ReadObjectField("_key");
                                                if (oKey.IsValid)
                                                {
                                                    act(oKey);
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (node.IsValid && node.Type != null)
                                        {
                                            var keyFld = node.Type.GetFieldByName("_key");
                                            if (keyFld != null)
                                            {
                                                var oKey = node.ReadObjectField("_key");
                                                if (oKey.IsValid)
                                                {
                                                    act(oKey);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            break;

                    }
                }
            }
        }


        const int SEGMENT_SIZE = 32; // for concurrent queue
    }
}
