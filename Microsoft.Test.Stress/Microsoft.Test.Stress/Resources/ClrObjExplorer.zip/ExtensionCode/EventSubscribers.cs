﻿//Desc: Show obj type and subscribers to specified event

//Include: util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var ctrl = new EventSubscribersControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("EventSubscribers", $"Subscribers to a particular class events");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
    }
    public class EventSubscribersControl : UserControl
    {
        public List<string> ClrTypes { get; set; } = new List<string>();
        MyMainClass _MyMainClass;
        MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
        ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
        public EventSubscribersControl(MyMainClass myMainClass)
        {
            _MyMainClass = myMainClass;
        }
        public void Initialize()
        {

            using (var progress = new ProgressOwnUI<string>($"Enumerating types"))
            {
                try
                {
                    foreach (var type in _clrUtil.EnumerateObjectTypes())
                    {
                        ClrTypes.Add(type);
                    }
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            }

            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" >
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""800""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""900""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height = ""800""/>
            <RowDefinition Height = ""3""/>
            <RowDefinition Height = ""*""/>
        </Grid.RowDefinitions>
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbTypes"" Text=""Types"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name=""dpTypes"" Grid.Row=""1""/>
        </Grid>

        <GridSplitter Grid.Row = ""1"" VerticalAlignment=""Center"" HorizontalAlignment=""Stretch"" Height = ""3"" Background=""LightBlue""/>
        <Grid Grid.Row=""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbEventNames""  Text=""Event Names"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name=""dpEventNames"" Grid.Row = ""1""/>
        </Grid>
    </Grid>
    <GridSplitter Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Column = ""2"">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbInstances"" Text=""Instances"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name = ""dpInstances"" Grid.Row=""1""/>
        </Grid>
    </Grid>
    <GridSplitter Grid.Column = ""3"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Column = ""4"">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
                <RowDefinition Height = ""3""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbEventHandlers"" Text=""EventHandlers"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name = ""dpEventHandlers"" Grid.Row=""1"" />
            <GridSplitter Grid.Row = ""2"" VerticalAlignment=""Center"" HorizontalAlignment=""Stretch"" Height = ""4"" Background=""LightBlue""/>
            <DockPanel x:Name = ""dpEventHandlerGroup"" Grid.Row=""3"" />
        </Grid>
    </Grid>
</Grid>
";
            var strReader = new System.IO.StringReader(strxaml);
            var xamlreader = XmlReader.Create(strReader);
            var grid = (Grid)(XamlReader.Load(xamlreader));
            this.Content = grid;
            grid.DataContext = this;

            var dpTypes = (DockPanel)grid.FindName("dpTypes");
            var tbTypes = (TextBox)grid.FindName("tbTypes");
            var dpEventNames = (DockPanel)grid.FindName("dpEventNames");
            var tbEventNames = (TextBox)grid.FindName("tbEventNames");
            var dpInstances = (DockPanel)grid.FindName("dpInstances");
            var tbInstances = (TextBox)grid.FindName("tbInstances");
            var dpEventHandlers = (DockPanel)grid.FindName("dpEventHandlers");
            var tbEventHandlers = (TextBox)grid.FindName("tbEventHandlers");
            var dpEventHandlerGroup = (DockPanel)grid.FindName("dpEventHandlerGroup");

            tbTypes.Text = $@"Select a type that publishes Events. (Use the StringFilter) The EventNames will be shown at bottom. Select an Event name and the Instances of the Type will show, along with a Invocation count column of # of subscribers. 
A MultiCastDelegate can have a single target, or a Invocationlist.
Choose an Instance to see the EventHandlers on the right. Right-Click to see various options";

            var qTypes = from TypeName in ClrTypes
                         select new
                         {
                             TypeName
                         };
            var brTypes = new BrowsePanel(qTypes, colWidths: new[] { 700 });
            dpTypes.Children.Add(brTypes);
            brTypes.BrowseList.SelectionChanged += (o, e) =>
             {
                 try
                 {
                     BrowseList lv = o as BrowseList;
                     if (lv != null && lv.SelectedItems.Count == 1)
                     {
                         var selectedItem = lv.SelectedItems[0];
                         var typeName = (string)TypeDescriptor.GetProperties(selectedItem)["TypeName"].GetValue(selectedItem);
                         var oneObjOfType = _clrUtil.GetObjectsOfType(typeName);
                         var ptype = oneObjOfType[0].Type;
                         var lstEvHandlers = new List<Tuple<string, ClrType>>(); // fieldname, type
                         foreach (var fld in ptype.Fields)
                         {
                             var IsEventHandler = false;
                             var curtype = fld.Type;
                             while (!IsEventHandler && curtype != null && curtype.Name != "System.Object")
                             {
                                 if (curtype.Name == "System.MulticastDelegate")
                                 {
                                     lstEvHandlers.Add(Tuple.Create(fld.Name, fld.Type));
                                     IsEventHandler = true;
                                     break;
                                 }
                                 curtype = curtype.BaseType;
                             }
                         }
                         dpEventNames.Children.Clear();
                         dpInstances.Children.Clear();
                         dpEventHandlers.Children.Clear();
                         tbInstances.Text = "";
                         tbEventHandlers.Text = "";
                         if (lstEvHandlers.Count > 0)
                         {
                             var qFields = from tup in lstEvHandlers
                                           select new
                                           {
                                               _clrType = tup.Item2,
                                               EventFieldName = tup.Item1,
                                               FieldType = tup.Item2.Name
                                           };
                             var brFields = new BrowsePanel(qFields, ShowFilter: true);
                             dpEventNames.Children.Add(brFields);
                             tbEventNames.Text = $@"Events (members that derive from MultiCastDelegate) {typeName}";
                             brFields.BrowseList.SelectionChanged += (of, ef) =>
                              {
                                  try
                                  {
                                      BrowseList lv = of as BrowseList;
                                      if (lv != null && lv.SelectedItems.Count == 1)
                                      {
                                          var selectedItem = lv.SelectedItems[0];
                                          var eventFieldName = (string)TypeDescriptor.GetProperties(selectedItem)["EventFieldName"].GetValue(selectedItem);
                                          var clrType = (ClrType)TypeDescriptor.GetProperties(selectedItem)["_clrType"].GetValue(selectedItem);
                                          var lstObjs = _clrUtil.GetObjectsOfType(ptype.Name);
                                          var qobjInstances = from obj in lstObjs
                                                              let evntMember = obj.GetObjectMember(eventFieldName)
                                                              let targ = (!evntMember.IsValid ? default(ClrObject) : evntMember.GetObjectMember("_target"))
                                                              //let invocationlist = evntMember.GetObjectMember("_invocationList")
                                                              let InvocationCount = (!evntMember.IsValid ? 0 : evntMember.ReadField<IntPtr>("_invocationCount").ToInt64())
                                                              orderby InvocationCount descending
                                                              select new
                                                              {
                                                                  _clrobj = obj,
                                                                  _evntMember = evntMember,
                                                                  Address = obj.GetAddressAsString(),
                                                                  InvocationCount,
                                                                  Obj = obj.GetObjectDisplayValue(),
                                                                  Dat = (obj.Type.Name == "Microsoft.VisualStudio.Text.Editor.Implementation.WpfTextViewHost" ? obj.GetObjectMember("_textView").GetObjectDisplayValue() : string.Empty),
                                                                  Targ = (!targ.IsValid ? "" : targ.GetObjectDisplayValue()),
                                                              };
                                          var brInstances = new BrowsePanel(qobjInstances, colWidths: new[] { 125, 100, 800, 400 });
                                          _mainWindowClrObjExp.AddItemsToContextMenu(brInstances);

                                          dpInstances.Children.Clear();
                                          dpInstances.Children.Add(brInstances);
                                          dpEventHandlers.Children.Clear();
                                          dpEventHandlerGroup.Children.Clear();
                                          tbInstances.Text = $"(Multiselect to show common handlers) Instances of {typeName} and the count of {eventFieldName}";
                                          tbEventHandlers.Text = "";
                                          brInstances.BrowseList.SelectionChanged += (oi, ei) =>
                                            {
                                                try
                                                {
                                                    BrowseList lv = oi as BrowseList;
                                                    if (lv != null && lv.SelectedItems.Count > 0)
                                                    {
                                                        var dictHandlers = new Dictionary<string, int>(); // eventhandler=>count
                                                        var lstHandlers = new HashSet<ClrObject>();
                                                        foreach (var selectedItem in lv.SelectedItems)
                                                        {
                                                            lstHandlers.Clear();
                                                            var clrObj = (ClrObject)TypeDescriptor.GetProperties(selectedItem)["_clrobj"].GetValue(selectedItem);
                                                            var objevntMember = clrObj.GetObjectMember(eventFieldName);
                                                            var targ = objevntMember.GetObjectMember("_target");
                                                            if (targ != null && targ.Address != objevntMember.Address)
                                                            {
                                                                lstHandlers.Add(targ);
                                                            }
                                                            var invocationlist = objevntMember.GetObjectMember("_invocationList");
                                                            if (invocationlist != null)
                                                            {
                                                                invocationlist.EnumerateRefsOfObject((ochild) =>
                                                                {
                                                                    lstHandlers.Add(ochild);
                                                                    return true;
                                                                });
                                                            }
                                                            foreach (var objH in lstHandlers)
                                                            {
                                                                var key = objH.GetObjectDisplayValue();
                                                                if (!dictHandlers.ContainsKey(key))
                                                                {
                                                                    dictHandlers[key] = 1;
                                                                }
                                                                else
                                                                {
                                                                    dictHandlers[key]++;
                                                                }
                                                            }
                                                        }
                                                        if (lv.SelectedItems.Count == 1)
                                                        {
                                                            var qh = from objH in lstHandlers
                                                                     select new
                                                                     {
                                                                         _clrobj = objH,
                                                                         Address = objH.GetAddressAsString(),
                                                                         Obj = objH.GetObjectDisplayValue(),
                                                                     };
                                                            var brHandlers = new BrowsePanel(qh);
                                                            _mainWindowClrObjExp.AddItemsToContextMenu(brHandlers);

                                                            dpEventHandlers.Children.Clear();
                                                            dpEventHandlers.Children.Add(brHandlers);
                                                            tbEventHandlers.Text = $"EventHandlers of {typeName} {eventFieldName}";
                                                            dpEventHandlerGroup.Children.Clear();
                                                        }
                                                        else
                                                        {
                                                            dpEventHandlers.Children.Clear();
                                                            dpEventHandlerGroup.Children.Clear();
                                                            var qh = from kvp in dictHandlers
                                                                     orderby kvp.Value descending
                                                                     select new
                                                                     {
                                                                         Cnt =kvp.Value,
                                                                         EventHandler = kvp.Key
                                                                     };
                                                            var brHandlers = new BrowsePanel(qh);
                                                            dpEventHandlerGroup.Children.Add(brHandlers);
                                                        }
                                                    }
                                                }
                                                catch (Exception ex)
                                                {
                                                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                                                }

                                            };
                                      }
                                  }
                                  catch (Exception ex)
                                  {
                                      _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                                  }
                              };
                         }
                         else
                         {
                             tbEventNames.Text = "No Fields deriving from MultiCastDelegate";
                         }
                     }
                 }
                 catch (Exception ex)
                 {
                     _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                 }
             };
        }
    }
}
