﻿//Desc: Show obj types and their Disposed  member

//Include: util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }
        private void DoMainInternal()
        {
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <DockPanel x:Name = ""dpSummary"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""4"" Background=""LightBlue""/>
        <Grid Grid.Row = ""1""  Grid.Column = ""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""20""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <DockPanel x:Name = ""dpLabel"" Grid.Row=""0"" />
            <DockPanel x:Name = ""dpDisposed"" Grid.Row=""1"" />
        </Grid>
</Grid>
";
            var strReader = new System.IO.StringReader(strxaml);
            var xamlreader = XmlReader.Create(strReader);
            var grid = (Grid)(XamlReader.Load(xamlreader));
            var dpLabel = (DockPanel)grid.FindName("dpLabel");
            var dpSummary = (DockPanel)grid.FindName("dpSummary");
            var dpDisposed = (DockPanel)grid.FindName("dpDisposed");
            try
            {
                var setDisposedObjs = new HashSet<ClrObject>();
                using (var progress = new ProgressOwnUI<string>($"Finding Disposed Objects"))
                {
                    foreach (var clrobjType in _clrUtil.EnumerateObjectTypes())
                    {
                        try
                        {
                            var lstObjs = _clrUtil.GetObjectsOfType(clrobjType);
                            var oneObjOfType = lstObjs[0];
                            var ptype = oneObjOfType.Type;
                            var IsIDisposable = false;
                            var curtype = ptype;
                            while (!IsIDisposable && curtype != null && curtype.Name != "System.Object")
                            {
                                foreach (var intface in curtype.EnumerateInterfaces())
                                {
                                    if (intface.Name == "System.IDisposable")
                                    {
                                        IsIDisposable = true;
                                        break;
                                    }
                                }
                                curtype = curtype.BaseType;
                            }
                            if (IsIDisposable)
                            {
                                foreach (var fld in ptype.Fields)
                                {
                                    if (fld.IsValueType && fld.ElementType == ClrElementType.Boolean)
                                    {
                                        if (fld.Name.IndexOf("disposed", StringComparison.OrdinalIgnoreCase) >= 0)
                                        {
                                            foreach (var obj in lstObjs)
                                            {
                                                var IsDisposed = obj.ReadField<bool>(fld.Name);
                                                if (IsDisposed)
                                                {
                                                    setDisposedObjs.Add(obj); // adding twice ok if 2 fields named "disposed","disposedContext": hashset
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                        }
                    }
                }

                var qSummary = from obj in setDisposedObjs
                               group obj by obj.Type.Name
                               into grp
                               orderby grp.Count() descending
                               select new
                               {
                                   Type=grp.Key,
                                   CountDisposed=grp.Count(),
                                   CountTotalNumInstances = _clrUtil.GetObjectsOfType(grp.Key).Count()
                               };
                var brSummary = new BrowsePanel(qSummary);
                dpSummary.Children.Add(brSummary);
                brSummary.BrowseList.SelectionChanged += (om, em) =>
                {
                    try
                    {
                        BrowseList lv = om as BrowseList;
                        if (lv != null && lv.SelectedItems.Count == 1)
                        {
                            var selectedItem = lv.SelectedItems[0];
                            var typeDesc = TypeDescriptor.GetProperties(selectedItem)["Type"];
                            var typename = (string)typeDesc.GetValue(selectedItem);
                            dpLabel.Children.Clear();
                            dpLabel.Children.Add(new TextBlock() { Text = $"{typename}" });
                            var setDisposableButNotDisposed = new HashSet<ClrObject>();
                            foreach (var obj in _clrUtil.GetObjectsOfType(typename))
                            {
                                if (!setDisposedObjs.Contains(obj))
                                {
                                    setDisposableButNotDisposed.Add(obj);
                                }
                            }
                            var setDisposedSelected = setDisposedObjs.Where(o => o.Type.Name == typename);
                            var setObjsOfSelectedType = setDisposedObjs.Select(p => new { Obj = p, IsDisposed = true }).
                                    Union(setDisposableButNotDisposed.Select(p => new { Obj = p, IsDisposed = false }));
                            var q = from obj in setObjsOfSelectedType
                                    select new
                                    {
                                        _clrobj = obj.Obj,
                                        Address = obj.Obj.GetAddressAsString(),
                                        Obj = obj.Obj.GetObjectDisplayValue(),
                                        IsDisposed = obj.IsDisposed,
                                        IsFinalizeSuppressed = obj.Obj.Type.IsFinalizeSuppressed(obj.Obj),
                                    };
                            var brObjs = new BrowsePanel(q);
                            dpDisposed.Children.Clear();
                            dpDisposed.Children.Add(brObjs);
                            _mainWindowClrObjExp.AddItemsToContextMenu(brObjs);
                        }
                    }
                    catch (Exception ex)
                    {
                        _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                    }
                };
                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("Disposed", $"{_clrUtil._dumpFileName}");
                tabItem.Content = grid;
            }
            catch (Exception ex)
            {
                _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
            }
        }
    }
}
