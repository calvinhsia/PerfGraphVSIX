﻿//Desc: Enumerate all types and show Statics

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;
using System.Windows.Media;


namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            using (var _progress = new ProgressOwnUI<string>("Getting all types"))
            {
                var lstStatFields = new List<ClrStaticField>();
                // for generics, these types only show generic params, like "List<T>", and not "List<int>"
                _clrUtil.clrRuntime.EnumerateTypes((type) =>
                {
                    if (type.StaticFields != null)
                    {
                        lstStatFields.AddRange(type.StaticFields);
                    }
                    return true; // keep enumerating
                });
                var appdomain0 = ClrUtil.g_ClrUtil.clrRuntime.AppDomains[0];

                // statFld.GetAddress(ClrAppDomain appDomain);
                var query = from statFld in lstStatFields
                            let appdomainAddr = statFld.GetAddress(appdomain0)
                            let addrStat = _clrUtil._target.DataReader.ReadPointer(appdomainAddr)
                            let obj = _clrUtil._heap.GetObject(addrStat)
                            select new
                            {
                                _clrobj = obj,
                                Address = obj.GetAddressAsString(),
                                statFld.Name,
                                Type = statFld.Type?.Name,
                                Module = statFld.Type?.Module?.Name
                            };
                var br = new BrowsePanel(query);
                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("StaticFields", $"");
                tabItem.Content = br;
                br.BrowseList.AddHandler(System.Windows.UIElement.MouseMoveEvent, new RoutedEventHandler((om, em) =>
                {
                    try
                    {
                        BrowseList lv = om as BrowseList;
                        if (lv != null)
                        {
                            var tb = em.OriginalSource as TextBlock;
                            if (tb != null)
                            {
                                ToolTip tip = null;
                                switch (tb.Name)
                                {
                                    case "Address":
                                        var clrobj = (ClrObject)TypeDescriptor.GetProperties(tb.DataContext)["_clrobj"].GetValue(tb.DataContext);
                                        if (clrobj.IsValid)
                                        {
                                            var tiptxt = clrobj.GetToolTipAsString(nMaxDumpSize: 1024);
                                            tip = _mainWindowClrObjExp.CreateNewToolTip();
                                            var tbTip = new TextBox()
                                            {
                                                BorderThickness = new System.Windows.Thickness(0),
                                                FontFamily = new FontFamily("Courier New"),
                                                FontSize = 9,
                                                Background = Brushes.LightYellow,
                                                Text = tiptxt
                                            };
                                            tip.Content = tbTip;
                                        }
                                        break;
                                }
                                if (tip != null)
                                {
                                    tip.PlacementTarget = tb;
                                    tip.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
                                    tip.IsOpen = true;
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                    }
                }));
            }
        }
    }
}
