﻿//Desc: Show WpfAnimation

//Include: util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }
        private void DoMainInternal()
        {
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <DockPanel x:Name = ""dpSummary"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""4"" Background=""LightBlue""/>
        <Grid Grid.Row = ""1""  Grid.Column = ""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""20""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <DockPanel x:Name = ""dpLabel"" Grid.Row=""0"" />
            <DockPanel x:Name = ""dpData"" Grid.Row=""1"" />
        </Grid>
</Grid>
";
            var strReader = new System.IO.StringReader(strxaml);
            var xamlreader = XmlReader.Create(strReader);
            var grid = (Grid)(XamlReader.Load(xamlreader));
            var dpLabel = (DockPanel)grid.FindName("dpLabel");
            var dpSummary = (DockPanel)grid.FindName("dpSummary");
            var dpData = (DockPanel)grid.FindName("dpData");
            try
            {
                var strWpfAnimationClock= "System.Windows.Media.Animation.AnimationClock";
                using (var progress = new ProgressOwnUI<string>($"Finding Closed {strWpfAnimationClock}"))
                {
                    var wpfClocks = _clrUtil.GetObjectsOfType(strWpfAnimationClock);
                    var q = from wpfClock in wpfClocks
                            let currentState = wpfClock.GetObjectDisplayValue("_currentClockState")
                            select new
                            {
                                _clrobj = wpfClock,
                                Address = wpfClock.GetAddressAsString(),
                                WpfClock = wpfClock.GetObjectDisplayValue(),
                                currentState
                            };
                    var brSummary = new BrowsePanel(q);
                    _mainWindowClrObjExp.AddItemsToContextMenu(brSummary);
                    dpSummary.Children.Add(brSummary);
                    brSummary.BrowseList.SelectionChanged += (om, em) =>
                    {
                        try
                        {
                            //BrowseList lv = om as BrowseList;
                            //if (lv != null && lv.SelectedItems.Count == 1)
                            //{
                            //    var selectedItem = lv.SelectedItems[0];
                            //    var typeDesc = TypeDescriptor.GetProperties(selectedItem)["_clrobj"];
                            //    var wpfTextViewHost = (ClrObject)typeDesc.GetValue(selectedItem);
                            //    dpLabel.Children.Clear();
                            //    dpLabel.Children.Add(new TextBlock() { Text = $"{wpfTextViewHost.ToString()}" });
                            //    var closedEvent = wpfTextViewHost.GetObjectMember("Closed");
                            //    var invoclist = closedEvent.GetObjectMember("_invocationList");
                            //    var subscribers = new List<ClrObject>();
                            //    invoclist.EnumerateRefsOfObject(child =>
                            //    {
                            //        subscribers.Add(child);
                            //        return true;
                            //    });

                            //    var q = from obj in subscribers
                            //            select new
                            //            {
                            //                _clrobj = obj,
                            //                Address = obj.GetAddressAsString(),
                            //                Obj = obj.GetObjectDisplayValue(),
                            //            };
                            //    var brObjs = new BrowsePanel(q);
                            //    dpData.Children.Clear();
                            //    dpData.Children.Add(brObjs);
                            //    _mainWindowClrObjExp.AddItemsToContextMenu(brObjs);
                            //}
                        }
                        catch (Exception ex)
                        {
                            _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                        }
                    };
                }
                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("WpfAnimation", $"{_clrUtil._dumpFileName}");
                tabItem.Content = grid;
            }
            catch (Exception ex)
            {
                _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
            }
        }
    }
}
