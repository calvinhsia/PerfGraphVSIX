﻿//Desc: Show GCRoots (like statics or stack or pinned or refcounted...)

//Include: util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }
        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("GC Roots", $"");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
        public class MyUserControl : UserControl
        {
            MyMainClass _MyMainClass;
            MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
            ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
            public MyUserControl(MyMainClass myMainClass)
            {
                _MyMainClass = myMainClass;
                this.DataContext = this;
            }
            public void Initialize()
            {
                try
                {

                    // Make a namespace referring to our namespace and assembly
                    // using the prefix "l:"
                    //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
                    var nameSpace = this.GetType().Namespace;
                    var asm = System.IO.Path.GetFileNameWithoutExtension(
                        Assembly.GetExecutingAssembly().Location);

                    var xmlns = string.Format(
        @"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
                    //there are a lot of quotes (and braces) in XAML
                    //and the C# string requires quotes to be doubled
                    var strxaml =
        @"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
        @" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <DockPanel x:Name = ""dpData"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""4"" Background=""LightBlue""/>
        <Grid Grid.Row = ""1""  Grid.Column = ""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""20""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <DockPanel x:Name = ""dpLabel"" Grid.Row=""0"" />
            <DockPanel x:Name = ""dpDataxx"" Grid.Row=""1"" />
        </Grid>
</Grid>
";
                    var grid = (Grid)(XamlReader.Parse(strxaml));
                    this.Content = grid;
                    var dpLabel = (DockPanel)grid.FindName("dpLabel");
                    var dpData = (DockPanel)grid.FindName("dpData");
                    var lst = new List<Tuple<ClrStaticField, IClrRoot, ClrObject>>();
                    using (var progress = new ProgressOwnUI<string>($"GCRoot Objects"))
                    {
                        foreach ((ClrStaticField statfld, ClrObject oroot) in ClrUtil.g_ClrUtil.clrRuntime.EnumerateStaticVars())
                        {
                            lst.Add(Tuple.Create(statfld, (IClrRoot)null, oroot));
                        }
                        foreach (var clrRoot in ClrUtil.g_ClrUtil.clrRuntime.Heap.EnumerateRoots())
                        {
                            lst.Add(Tuple.Create((ClrStaticField)null, clrRoot, clrRoot.Object));
                        }
                    }
                    var qroot = from tup in lst
                                select new
                                {
                                    _address = tup.Item3.Address,
                                    Address = MyAddrFormatter.AddrFormat($"{tup.Item3.Address:x}"),
                                    StaticField = tup.Item1 == null ? string.Empty : $"{tup.Item1.ContainingType.Name}.{tup.Item1.Name} {tup.Item1.Type?.Name}",
                                    RootKind = tup.Item2 == null ? string.Empty : $"{tup.Item2.RootKind}",
                                    Name = !tup.Item3.IsValid ? string.Empty : $"{tup.Item3.Type?.Name}",
                                    //Val = tup.Item3.GetObjectDisplayValue(),
                                    IsInterior = tup.Item2 == null ? string.Empty : $"{tup.Item2.IsInterior}",
                                    IsPinned = tup.Item2 == null ? string.Empty : $"{tup.Item2.IsPinned}",
                                };

                    var brRoot = new BrowsePanel(qroot);
                    brRoot.BrowseList.ContextMenu.AddMenuItem(async (o, e) =>
                    {
                        try
                        {
                            await Task.Delay(100); // allow time for menu to close
                            var items = brRoot.BrowseList.SelectedItems;
                            if (items == null || items.Count < 1)
                            {
                                items = brRoot.BrowseList.Items;
                            }
                            var lst = new List<ulong>();
                            var nameofRefobj = "_address";
                            foreach (var itm in items)
                            {
                                var tdescitem = TypeDescriptor.GetProperties(itm)[nameofRefobj]; // e.g. "_clrobj"
                                ClrObject objRoot = default;
                                switch (nameofRefobj)
                                {
                                    case "_address":
                                        var addr = (ulong)tdescitem.GetValue(itm);
                                        lst.Add(addr);
                                        objRoot = _clrUtil.clrRuntime.Heap.GetObject(addr);
                                        break;
                                    case "ClassName":
                                        var clsName = (string)tdescitem.GetValue(itm);
                                        var objs = _clrUtil.GetObjectsOfType(clsName);
                                        objs.ForEach((o) => lst.Add(o.Address));
                                        break;
                                }
                            }
                            foreach (var addr in lst.Take(3))
                            {
                                var obj = _clrUtil._heap.GetObject(addr);
                                ObjRefView.MakeObjRefTree(_clrUtil, obj, this._mainWindowClrObjExp);
                            }
                        }
                        catch (Exception ex)
                        {
                            _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                        }

                    }, "References", "", InsertPos: 0);
                    dpData.Children.Clear();
                    dpData.Children.Add(brRoot);
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            }
        }
    }
}