﻿//Desc: Show JoinableTask data

//Include: util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var ctrl = new JoinableTaskControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("JoinableTask", $"JoinableTask data");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
    }
    public class JoinableTaskControl : UserControl
    {
        MyMainClass _MyMainClass;
        MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
        ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
        public JoinableTaskControl(MyMainClass myMainClass)
        {
            _MyMainClass = myMainClass;
        }
        string[] JoinableTypes = new[] {
            "Microsoft.VisualStudio.Threading.JoinableTask",
            "Microsoft.VisualStudio.Threading.JoinableTaskCollection",
            "Microsoft.VisualStudio.Threading.IJoinableTaskDependent[]",
        };
        public void Initialize()
        {
            var lstIJoinableTaskDependent = new List<ClrObject>();
            using (var progress = new ProgressOwnUI<string>($"Enumerating types that inherit from IJoinableTaskDependent"))
            {
                try
                {
                    foreach (var clrobjType in _clrUtil.EnumerateObjectTypes())
                    {
                        var lstObjs = _clrUtil.GetObjectsOfType(clrobjType);
                        var oneObjOfType = lstObjs[0];
                        var ptype = oneObjOfType.Type;
                        var IsIJoinableTaskDependent = false;
                        var curtype = ptype;
                        while (!IsIJoinableTaskDependent && curtype != null && curtype.Name != "System.Object")
                        {
                            foreach (var intface in curtype.EnumerateInterfaces())
                            {
                                if (intface.Name == "Microsoft.VisualStudio.Threading.IJoinableTaskDependent")
                                {
                                    IsIJoinableTaskDependent = true;
                                    lstIJoinableTaskDependent.AddRange(lstObjs);
                                    break;
                                }
                            }
                            curtype = curtype.BaseType;
                        }
                    }
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            }
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" >
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""800""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height = ""Auto""/>
            <RowDefinition Height = ""*""/>
        </Grid.RowDefinitions>
        <TextBox x:Name = ""tbJoinableTypes"" Text=""Types"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
        <DockPanel x:Name=""dpJoinableTypes"" Grid.Row=""1""/>
    </Grid>
    <GridSplitter Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""4"" Background=""LightBlue""/>
    <Grid Grid.Column=""2"">
        <Grid.RowDefinitions>
            <RowDefinition Height = ""Auto""/>
            <RowDefinition Height = ""*""/>
            <RowDefinition Height = ""3""/>
            <RowDefinition Height = ""*""/>
        </Grid.RowDefinitions>
        <TextBox x:Name = ""tbWrapped"" Text=""Types"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
        <DockPanel x:Name=""dpWrapped"" Grid.Row=""1""/>
        <GridSplitter Grid.Row = ""2"" VerticalAlignment=""Center"" HorizontalAlignment=""Stretch"" Height = ""4"" Background=""LightBlue""/>
        <DockPanel x:Name=""dpJoinableTypeSummary"" Grid.Row=""3""/>
    </Grid>
    <GridSplitter Grid.Column = ""3"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""4"" Background=""LightBlue""/>
</Grid>
";
            var strReader = new System.IO.StringReader(strxaml);
            var xamlreader = XmlReader.Create(strReader);
            var grid = (Grid)(XamlReader.Load(xamlreader));
            this.Content = grid;
            grid.DataContext = this;

            var dpJoinableTypes = (DockPanel)grid.FindName("dpJoinableTypes");
            var tbJoinableTypes = (TextBox)grid.FindName("tbJoinableTypes");
            var dpWrapped = (DockPanel)grid.FindName("dpWrapped");
            var dpdpJoinableTypeSummary = (DockPanel)grid.FindName("dpJoinableTypeSummary");

            var qjoinableObjects = from joinableObject in lstIJoinableTaskDependent
                                   let DisplayName = joinableObject.GetObjectMember("displayName").GetObjectDisplayValue()
                                   let jContext = joinableObject.GetObjectMember("<Context>k__BackingField")
                                   let pendingTasks = jContext.GetObjectMember("pendingTasks")
                                   let initialDelegate = joinableObject.GetObjectMember("initialDelegate")
                                   let wrappedTask = joinableObject.GetObjectMember("wrappedTask")
                                   select new
                                   {
                                       _clrobj = joinableObject,
                                       Address = joinableObject.GetAddressAsString(),
                                       Type = joinableObject.Type.Name,
                                       State = joinableObject.GetObjectDisplayValue("state"),
                                       WrappedTask = wrappedTask.GetObjectDisplayValue(),
                                       JContext = jContext.GetObjectDisplayValue(),
                                       DisplayName,
                                       InitialDelegate = initialDelegate.GetObjectDisplayValue(),
                                       PendingTaskCount = (pendingTasks.IsValid ? pendingTasks.ReadField<int>("m_count") : 0),
                                       Obj = joinableObject.GetObjectDisplayValue()
                                   };
            var brjoinableObjects = new BrowsePanel(qjoinableObjects, colWidths: new[] { 100 });
            _mainWindowClrObjExp.AddItemsToContextMenu(brjoinableObjects);
            dpJoinableTypes.Children.Add(brjoinableObjects);

            var qWrappedTaskState = from tsk in qjoinableObjects
                                    group tsk by tsk.WrappedTask into grp
                                    select new
                                    {
                                        WrappedTask = grp.Key,
                                        Cnt=grp.Count()
                                    };
            dpWrapped.Children.Add(new BrowsePanel(qWrappedTaskState));

            var qJoinableTaskSummary = from tsk in qjoinableObjects
                                        group tsk by tsk.Type into grp
                                        let Count = grp.Count()
                                        orderby Count descending
                                        select new
                                        {
                                            Count,
                                            JoinableTaskType = grp.Key
                                        };
            var brJoinableTaskSummary = new BrowsePanel(qJoinableTaskSummary);
            dpdpJoinableTypeSummary.Children.Clear();
            dpdpJoinableTypeSummary.Children.Add(brJoinableTaskSummary);

            brjoinableObjects.BrowseList.SelectionChanged += (o, e) =>
             {
                 try
                 {
                     BrowseList lv = o as BrowseList;
                     if (lv != null && lv.SelectedItems.Count == 1)
                     {
                         var selectedItem = lv.SelectedItems[0];
                         var typeName = (string)TypeDescriptor.GetProperties(selectedItem)["_clrobj"].GetValue(selectedItem);
                     }
                 }
                 catch (Exception ex)
                 {
                     _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                 }
             };
        }
    }
}
