﻿//Desc: Show how to use the progress bar on a private UI thread

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using ClrLib;
using ClrObjExplorer;
using Utility;


namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {
        }
        private void DoMainInternal()
        {
            // Progress bar is WPF which means it must run on UI thread.
            // We create a ProgBar on it's own thread so UI thread can deal with issues like SingleThreadedApartment (STA) COM objects like Clr runtime and MSCorDacWks.dll which also require UI thread
            // This way we can update the ProgBar UI without using the busy main thread.
            AsyncPump.Run(async () =>
            {
                var cts = new CancellationTokenSource();
                using (var progress = new ProgressOwnUI<string>("Progress Bar Demo: NonDeterministic with string reports", cts: cts))
                {
                    for (int i = 0; i < 10; i++)
                    {
                        progress.Report($"Step {i}");
                        if (cts.IsCancellationRequested)
                        {
                            _mainWindowClrObjExp.AddStatusMsg("Cancelled");
                            break;
                        }
                        await Task.Delay(TimeSpan.FromSeconds(1));
                    }
                }
                using (var progress = new ProgressOwnUI<int>("Progress Bar Demo: Deterministic", MaxValue: 10))
                {
                    for (int i = 0; i < 10; i++)
                    {
                        progress.Report(i);
                        await Task.Delay(TimeSpan.FromSeconds(1));
                    }
                }
                using (var progress = new ProgressOwnUI<int>("Progress Bar Demo: NonDeterministic"))
                {
                    for (int i = 0; i < 10; i++)
                    {
                        progress.Report(i);
                        await Task.Delay(TimeSpan.FromSeconds(1));
                    }
                }
                using (var progress = new ProgressOwnUI<int>("Progress Bar Demo: Nested"))
                {
                    for (int i = 0; i < 10; i++)
                    {
                        progress.Report(i);
                        using (var prog2 = new ProgressOwnUI<string>("Nested"))
                        {
                            for (int j = 0; j < 10; j++)
                            {
                                await Task.Delay(TimeSpan.FromMilliseconds(100));
                                prog2.Report($"Nested {i} {j}");
                            }
                        }
                    }
                }

            });
        }
    }
}
