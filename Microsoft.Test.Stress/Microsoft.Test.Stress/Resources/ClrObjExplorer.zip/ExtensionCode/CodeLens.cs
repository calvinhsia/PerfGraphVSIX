﻿//Desc: Show CodeLensAdornments

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: util\BaseExtension.cs
//Include: util\WpfTreeView.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using System.Reflection.Emit;
using System.Runtime.Remoting.Messaging;
using System.IO;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("CodeLens", $"CodeLens instances");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
        public class MyUserControl : UserControl
        {
            internal MyMainClass _MyMainClass;
            internal MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
            internal ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
            public MyUserControl(MyMainClass myMainClass)
            {
                _MyMainClass = myMainClass;
            }
            public void Initialize()
            {
                _mainWindowClrObjExp.AddStatusMsg($"CodeLens Adornment Extension. This is an extensionGarbage foobar");
                // Make a namespace referring to our namespace and assembly
                // using the prefix "l:"
                //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
                var nameSpace = this.GetType().Namespace;
                var asm = System.IO.Path.GetFileNameWithoutExtension(
                    System.Reflection.Assembly.GetExecutingAssembly().Location);

                var xmlns = string.Format(
    @"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
                //there are a lot of quotes (and braces) in XAML
                //and the C# string requires quotes to be doubled
                var strxaml =
    @"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
    @">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width=""1100""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width=""*""/>
    </Grid.ColumnDefinitions>
    <DockPanel x:Name = ""dpLabel""/>
    <DockPanel x:Name = ""dpTypes"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Row = ""1""  Grid.Column = ""2"">
        <Grid.RowDefinitions>
            <RowDefinition Height = ""25""/>
            <RowDefinition Height = ""300""/>
            <RowDefinition Height = ""3""/>
            <RowDefinition Height = ""25""/>
            <RowDefinition Height = ""*""/>
        </Grid.RowDefinitions>
        <Label Content=""WPF Visual Tree""/>
        <DockPanel x:Name = ""dpData"" Grid.Row=""1"" />
        <GridSplitter Grid.Row = ""2"" HorizontalAlignment=""Stretch"" VerticalAlignment=""Center"" Height = ""3"" Background=""LightBlue""/>
        <Label Content=""Object Reference Tree"" Grid.Row=""3""/>
        <DockPanel x:Name = ""dpRefs"" Grid.Row = ""4"" />
    </Grid>
</Grid>
";
                var grid = (Grid)(XamlReader.Parse(strxaml));
                this.Content = grid;
                var dpLabel = (DockPanel)grid.FindName("dpLabel");
                var dpTypes = (DockPanel)grid.FindName("dpTypes");
                var dpData = (DockPanel)grid.FindName("dpData");
                var dpRefs = (DockPanel)grid.FindName("dpRefs");
                var AdornmentTypeName = "Microsoft.VisualStudio.Language.Intellisense.CodeLensAdornment";
                var lstAdornments = _clrUtil.GetObjectsOfType(AdornmentTypeName);
                if (lstAdornments.Count() == 0)
                {
                    return;
                }
                var qBase = from adornment in lstAdornments
                            let IsConnected = (bool)adornment.GetFieldValue("<IsConnected>k__BackingField")
                            let AdornmentHost = adornment.GetObjectMember("_parent")
                            orderby IsConnected descending
                            select new
                            {
                                adornment,
                                IsConnected,
                                AdornmentHost
                            };

                var q = from item in qBase
                        let adornment = item.adornment
                        let tag = adornment.GetObjectMember("tag")
                        let descriptor = tag.GetObjectMember("descriptor")
                        let descriptorInfo = GetDescriptorInfo(tag, descriptor)
                        let AdornmentHost = item.AdornmentHost
                        let AdornmentHostIsIDisposed = (AdornmentHost.IsValid ? (AdornmentHost.GetObjectDisplayValue("isDisposed")) : " ")
                        let WpfTextView = AdornmentHost
                                    .GetObjectMember("adornmentTagger")
                                    .GetObjectMember("WpfTextView")
                        let WpfTextViewClosed = (WpfTextView.IsValid ? ((bool)WpfTextView.GetFieldValue("_isClosed")).ToString() : " ")
                        select new
                        {
                            _clrobj = adornment,
                            Address = adornment.GetAddressAsString(),
                            item.IsConnected,
                            AdornmentHostIsValid = AdornmentHost.IsValid,
                            AdornmentHostIsIDisposed,
                            WpfTextViewClosed,
                            descriptorInfo.FileName,
                            descriptorInfo.Description,
                            WpfTextView = WpfTextView.GetObjectDisplayValue()
                        };
                dpLabel.Children.Add(new TextBlock()
                {
                    Text = $@"{AdornmentTypeName} TotalCount={qBase.Count()}" +
                        $@"  Connected={qBase.Where(t => t.IsConnected).Count()}" +
                        $@"  ConnButNoHost={qBase.Where(t => t.IsConnected && !t.AdornmentHost.IsValid).Count()}"
                });

                var br = new BrowsePanel(q);
                _mainWindowClrObjExp.AddItemsToContextMenu(br);
                var wpfTreeViewPanel = new WpfTreeViewPanel(_mainWindowClrObjExp);
                var wpfTreeView = wpfTreeViewPanel._WpfTreeView;
                br.BrowseList.SelectionChanged += (_, __) =>
                {
                    try
                    {
                        dpData.Children.Clear();
                        dpRefs.Children.Clear();
                        if (br.BrowseList.SelectedItems.Count == 1)
                        {
                            var selectedItem = br.BrowseList.SelectedItems[0];
                            var adornment = (ClrObject)TypeDescriptor.GetProperties(selectedItem)["_clrobj"].GetValue(selectedItem);

                            wpfTreeView.Initialize(adornment);
                            ((MyTreeViewItem)(wpfTreeView.Items[0])).ExpandAll();
                            dpData.Children.Add(wpfTreeViewPanel);
                            //var sb = new StringBuilder();
                            //((MyTreeViewItem)wpfTreeView.Items[0]).DumpChildren(sb, 0);
                            var tvPanel = new TVObjRefPanel(_clrUtil, adornment, _mainWindowClrObjExp, pathToOpen: null);
                            dpRefs.Children.Add(tvPanel);
                        }
                    }
                    catch (Exception ex)
                    {
                        _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                    }
                };
                dpTypes.Children.Add(br);
            }
            (string Description, string FileName) GetDescriptorInfo(ClrObject oTag, ClrObject clrODescriptor)
            {
                var description = string.Empty;
                var filename = string.Empty;
                if (clrODescriptor.IsValid && oTag.IsValid)
                {
                    var type = clrODescriptor.Type.Name;
                    switch (type)
                    {
                        case "Microsoft.VisualStudio.CodeSense.Editor.Roslyn.CodeElementTag+CodeElementDescriptor":
                            description = clrODescriptor
                                .GetObjectMember("elementDescription")
                                .GetObjectDisplayValue();
                            filename = clrODescriptor
                                .GetObjectMember("<FilePath>k__BackingField")
                                .GetObjectDisplayValue();
                            break;
                        case "Microsoft.VisualStudio.VC.CppCodeLensDescriptor":
                            description = clrODescriptor
                                .GetObjectMember("<ElementDescription>k__BackingField")
                                .GetObjectDisplayValue();
                            description += $" | (Line={(oTag.GetObjectDisplayValue("startLine"))}) {(oTag.GetObjectMember("fullyQualifiedName").GetObjectDisplayValue())}";
                            filename = clrODescriptor
                                .GetObjectMember("<FilePath>k__BackingField")
                                .GetObjectDisplayValue();
                            break;
                        case "Microsoft.VisualStudio.CodeSense.FileIndicator.Provider.FileIndicatorDescriptor":
                            description = clrODescriptor
                                .GetObjectMember("filePath")
                                .GetObjectDisplayValue();
                            filename = clrODescriptor
                                .GetObjectMember("filePath")
                                .GetObjectDisplayValue();
                            break;
                    }
                    if (!string.IsNullOrEmpty(filename))
                    {
                        filename = Path.GetFileName(filename);
                    }
                }
                return (description, filename);
            }
        }
    }
}
