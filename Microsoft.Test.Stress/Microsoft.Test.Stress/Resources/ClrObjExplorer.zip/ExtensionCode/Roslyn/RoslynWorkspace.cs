﻿//Desc: Show Roslyn WorkSpace info for ServiceHub.RoslynCodeAnalysisService.exe

//Include: ..\util\BaseExtension.cs
//Include: ..\util\RoslynUtilities.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;



namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args) { }
        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("RoslynWorkspace", $"{_pathFileToExecute}");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }

        public class MyUserControl : UserControl
        {
            MyMainClass _MyMainClass;
            MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
            ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
            public MyUserControl(MyMainClass myMainClass)
            {
                _MyMainClass = myMainClass;
                this.DataContext = this;
            }
            public void Initialize()
            {
                // Make a namespace referring to our namespace and assembly
                // using the prefix "l:"
                //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
                var nameSpace = this.GetType().Namespace;
                var asm = System.IO.Path.GetFileNameWithoutExtension(
                    Assembly.GetExecutingAssembly().Location);

                var xmlns = string.Format(
    @"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
                //there are a lot of quotes (and braces) in XAML
                //and the C# string requires quotes to be doubled
                var strxaml =
    @"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
    @" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <StackPanel Orientation=""Horizontal"">
        <Button Content=""_Go"" x:Name = ""btnGo""/>
    </StackPanel>
    <DockPanel x:Name = ""dpTree"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""4"" Background=""LightBlue""/>
        <Grid Grid.Row = ""1""  Grid.Column = ""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""30""/>
                <RowDefinition Height = ""800""/>
                <RowDefinition Height = ""3""/>
                <RowDefinition Height = ""20""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <DockPanel x:Name = ""dpData""  Grid.Row=""1""/>
            <GridSplitter Grid.Row = ""2"" VerticalAlignment=""Center"" HorizontalAlignment=""Stretch"" Height = ""3"" Background=""LightBlue""/>
            <TextBox x:Name = ""tbMemoryLabel"" Grid.Row=""3"" />
        </Grid>
</Grid>
";
                try
                {
                    var globalOptionService = @"Microsoft.CodeAnalysis.Options.GlobalOptionService";
                    var grid = (Grid)(XamlReader.Parse(strxaml));
                    var dpTree = (DockPanel)grid.FindName("dpTree");
                    var dpData = (DockPanel)grid.FindName("dpData");
                    this.Content = grid;
                    var lstRoslynGlobalOptionService = new List<ClrObject>();
                    lstRoslynGlobalOptionService.AddRange(_clrUtil.GetObjectsOfType(globalOptionService));
                    if (lstRoslynGlobalOptionService.Count != 1)
                    {
                        _mainWindowClrObjExp.AddStatusMsg($"did not find 1 instance of {globalOptionService}");
                    }
                    if (lstRoslynGlobalOptionService.Count > 0)
                    {
                        var tvPanel = new TVObjRefPanel(_clrUtil, lstRoslynGlobalOptionService[0], _mainWindowClrObjExp, pathToOpen: null);
                        dpTree.Children.Clear();
                        dpTree.Children.Add(tvPanel);
                        var tvb = (MyTreeViewBase)tvPanel.Children[0];
                        tvb.SelectedItemChanged += (o, e) =>
                         {
                             try
                             {
                                 dpData.Children.Clear();
                                 var item = (TVObjectRefItem)tvb.SelectedItem;
                                 var itemType = item._obj.Type.Name;
                                 var ndxLeftAngleBracket = itemType.IndexOf("<");
                                 if (ndxLeftAngleBracket > 0)
                                 {
                                     itemType = itemType.Substring(0, ndxLeftAngleBracket);
                                 }
                                 switch (itemType)
                                 {
                                     case "Roslyn.Collections.Immutable.ImmutableHashMap":
                                         {
                                             var lstObjects = new List<Tuple<ClrObject, ClrObject>>();
                                             item._obj.GetRoslynImmutableHashSetData((Key, Val) =>
                                             {
                                                 lstObjects.Add(Tuple.Create(Key, Val));
                                                 return true;
                                             });
                                             var qData = from kvp in lstObjects
                                                         select new
                                                         {
                                                             _clrobj = kvp.Item1,
                                                             Address = kvp.Item1.GetAddressAsString(),
                                                             Key = kvp.Item1.GetRoslynDisplayData(),
                                                             Val = kvp.Item2.GetRoslynDisplayData(),
                                                         };
                                             var brData = new BrowsePanel(qData);
                                             _mainWindowClrObjExp.AddItemsToContextMenu(brData);
                                             dpData.Children.Clear();
                                             dpData.Children.Add(brData);
                                         }
                                         break;
                                     default:
                                         break;
                                 }
                                 var tb = new TextBlock() { Text = item.ToString() + $"{item._obj}" };
                                 dpData.Children.Add(tb);

                             }
                             catch (Exception ex)
                             {
                                 _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                             }
                         };
                    }
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            }
        }
    }
}