﻿//Desc: Show Roslyn Collection info: like Roslyn.Collections.Immutable.ImmutableHashMap for ServiceHub.RoslynCodeAnalysisService.exe

//Include: ..\util\BaseExtension.cs
//Include: ..\util\RoslynUtilities.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;



namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args) { }
        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("RoslynCollection", $"{_clrUtil._dumpFileName}");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }

        public class MyUserControl : UserControl
        {
            MyMainClass _MyMainClass;
            MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
            ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
            public MyUserControl(MyMainClass myMainClass)
            {
                _MyMainClass = myMainClass;
                this.DataContext = this;
            }
            public void Initialize()
            {
                // Make a namespace referring to our namespace and assembly
                // using the prefix "l:"
                //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
                var nameSpace = this.GetType().Namespace;
                var asm = System.IO.Path.GetFileNameWithoutExtension(
                    Assembly.GetExecutingAssembly().Location);

                var xmlns = string.Format(
    @"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
                //there are a lot of quotes (and braces) in XAML
                //and the C# string requires quotes to be doubled
                var strxaml =
    @"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
    @" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <StackPanel Orientation=""Horizontal"">
        <Button Content=""_Go"" x:Name = ""btnGo""/>
    </StackPanel>
    <DockPanel x:Name = ""dpColls"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""4"" Background=""LightBlue""/>
        <Grid Grid.Row = ""1""  Grid.Column = ""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""30""/>
                <RowDefinition Height = ""800""/>
                <RowDefinition Height = ""3""/>
                <RowDefinition Height = ""20""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <DockPanel x:Name = ""dpData""  Grid.Row=""1""/>
            <TextBox x:Name = ""tbTotals""/>
            <DockPanel x:Name = ""dpSummary"" Grid.Row = ""1""/>
            <GridSplitter Grid.Row = ""2"" VerticalAlignment=""Center"" HorizontalAlignment=""Stretch"" Height = ""3"" Background=""LightBlue""/>
            <TextBox x:Name = ""tbMemoryLabel"" Grid.Row=""3"" />
            <TextBox x:Name = ""tbMemory"" FontFamily=""Consolas"" Grid.Row=""4"" HorizontalAlignment=""Stretch"" VerticalScrollBarVisibility=""Auto"" HorizontalScrollBarVisibility=""Auto"" />
        </Grid>
</Grid>
";

                try
                {
                    var grid = (Grid)(XamlReader.Parse(strxaml));
                    this.Content = grid;
                    var dpColls = (DockPanel)grid.FindName("dpColls");
                    var dpData = (DockPanel)grid.FindName("dpData");
                    var lstRoslynHashSets = new List<ClrObject>();
                    using (var progress = new ProgressOwnUI<string>($"Finding RoslynImmutableHashSet"))
                    {
                        foreach (var type in _clrUtil.EnumerateObjectTypes(regexFilter: $"^Roslyn.Collections.Immutable.ImmutableHashMap.*"))
                        {
                            if (!type.EndsWith("[]") && !type.Contains("+"))
                            {
                                lstRoslynHashSets.AddRange(_clrUtil.GetObjectsOfType(type));
                            }
                        }
                    }
                    var qobjInstances = from obj in lstRoslynHashSets
                                        let Count = obj.GetRoslynImmutableHashSetCount()
                                        //                                        let Count = Root.IsValid ? obj.ReadField<Int32>("_count") : 0
                                        orderby Count descending
                                        select new
                                        {
                                            _clrobj = obj,
                                            Address = obj.GetAddressAsString(),
                                            Obj = obj.GetObjectDisplayValue(),
                                            Count
                                        };
                    var brInstances = new BrowsePanel(qobjInstances, colWidths: new[] { 125 });
                    _MyMainClass.AddItemsToContextMenu(brInstances);
                    dpColls.Children.Clear();
                    dpColls.Children.Add(brInstances);
                    brInstances.BrowseList.SelectionChanged += (_, __) =>
                     {
                         try
                         {
                             if (brInstances.BrowseList.SelectedItems.Count == 1)
                             {
                                 var selectedItem = brInstances.BrowseList.SelectedItems[0];
                                 var oRoslynColl = (ClrObject)TypeDescriptor.GetProperties(selectedItem)["_clrobj"].GetValue(selectedItem);
                                 var lstObjects = new List<Tuple<ClrObject, ClrObject>>();
                                 oRoslynColl.GetRoslynImmutableHashSetData((Key, Val) =>
                                 {
                                     lstObjects.Add(Tuple.Create(Key, Val));
                                     return true;
                                 });
                                 var qData = from kvp in lstObjects
                                             select new
                                             {
                                                 _clrobj = kvp.Item1,
                                                 Address = kvp.Item1.GetAddressAsString(),
                                                 Obj = kvp.Item1.GetRoslynDisplayData(),
                                                 Val = kvp.Item2.GetAddressAsString(),
                                                 Vald = kvp.Item2.GetRoslynDisplayData(),
                                             };
                                 var brData = new BrowsePanel(qData);
                                 _MyMainClass.AddItemsToContextMenu(brData);
                                 dpData.Children.Clear();
                                 dpData.Children.Add(brData);
                             }
                         }
                         catch (Exception ex)
                         {
                             _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                         }

                     };
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            }
        }
    }
}