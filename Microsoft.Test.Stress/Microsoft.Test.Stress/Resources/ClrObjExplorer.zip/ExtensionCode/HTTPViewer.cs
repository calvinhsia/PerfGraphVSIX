﻿//Desc: Show HTTPRequests

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: util\BaseExtension.cs
//Include: util\WpfTreeView.cs
//Pragma: CompilerOptions=-langversion:9.0 -optimize

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using System.Reflection.Emit;
using System.Runtime.Remoting.Messaging;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args) { }

        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("HTTPRequest", $"HTTPRequest");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
        public class MyUserControl : UserControl
        {
            internal MyMainClass _MyMainClass;
            internal MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
            internal ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
            public MyUserControl(MyMainClass myMainClass)
            {
                _MyMainClass = myMainClass;
            }
            public void Initialize()
            {
                // Make a namespace referring to our namespace and assembly
                // using the prefix "l:"
                //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
                var nameSpace = this.GetType().Namespace;
                var asm = System.IO.Path.GetFileNameWithoutExtension(
                    System.Reflection.Assembly.GetExecutingAssembly().Location);

                var xmlns = string.Format(
    @"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
                //there are a lot of quotes (and braces) in XAML
                //and the C# string requires quotes to be doubled
                var strxaml =
    @"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
    @">
        <Grid.RowDefinitions>
            <RowDefinition Height=""30"" />
            <RowDefinition/>
        </Grid.RowDefinitions>
        <Grid.ColumnDefinitions>
            <ColumnDefinition Width=""500""/>
            <ColumnDefinition Width = ""3""/>
            <ColumnDefinition Width=""1200""/>
            <ColumnDefinition Width = ""3""/>
            <ColumnDefinition Width=""*""/>
        </Grid.ColumnDefinitions>
        <DockPanel x:Name = ""dpHTTPClient"" Grid.Row = ""1"" Grid.Column = ""0""/>
        <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
        <Grid Grid.Row = ""1""  Grid.Column = ""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""20""/>
                <RowDefinition/>
                <RowDefinition Height = ""3""/>
                <RowDefinition/>
            </Grid.RowDefinitions>
            <DockPanel x:Name = ""dpHTTPRequest"" Grid.Row = ""1""/>
            <GridSplitter Grid.Row=""2"" Height=""3"" HorizontalAlignment=""Stretch"" VerticalAlignment = ""Center"" Background=""LightBlue""/>
            <DockPanel x:Name = ""dpTree"" Grid.Row=""3"" />
        </Grid>
        <GridSplitter Grid.Row = ""1"" Grid.Column = ""3"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
        <Grid Grid.Row = ""1""  Grid.Column = ""4"">
            <Grid.RowDefinitions>
                <RowDefinition Height = ""20""/>
                <RowDefinition/>
            </Grid.RowDefinitions>
            <DockPanel x:Name = ""dpHTTPResponse"" Grid.Row = ""1""/>
        </Grid>

    </Grid>
";
                var grid = (Grid)XamlReader.Parse(strxaml);
                this.Content = grid;
                var dpHTTPClient = (DockPanel)grid.FindName("dpHTTPClient");
                var dpHTTPRequest = (DockPanel)grid.FindName("dpHTTPRequest");
                var dpHTTPResponse = (DockPanel)grid.FindName("dpHTTPResponse");

                using (var _progress = new ProgressOwnUI<string>($"Getting HTTP Types"))
                {
                    {
                        var httpClients = _clrUtil.GetObjectsOfType("System.Net.Http.HttpClient");
                        var q = from httpClient in httpClients
                                select new
                                {
                                    _clrobj = httpClient,
                                    Address = httpClient.GetAddressAsString(),
                                    BaseAddress = httpClient.GetObjectDisplayValue("baseAddress"),
                                    Val = httpClient.GetObjectDisplayValue(),
                                };
                        var br = new BrowsePanel(q);
                        _mainWindowClrObjExp.AddItemsToContextMenu(br);
                        dpHTTPClient.Children.Add(br);
                    }
                    {
                        var httpRequests = _clrUtil.GetObjectsOfType("System.Net.HttpWebRequest");
                        var q = from httpRequest in httpRequests
                                select new
                                {
                                    _clrobj = httpRequest,
                                    Uri = httpRequest.GetObjectDisplayValue("_Uri"),
                                    ServicePoint = httpRequest.GetObjectDisplayValue("_ServicePoint"),
                                    Verb = httpRequest.GetObjectDisplayValue("_Verb"),
                                    Address = httpRequest.GetAddressAsString(),
                                    Val = httpRequest.GetObjectDisplayValue()
                                };
                        var br = new BrowsePanel(q);
                        _mainWindowClrObjExp.AddItemsToContextMenu(br);
                        dpHTTPRequest.Children.Add(br);
                    }
                    {
                        var httpResponses = _clrUtil.GetObjectsOfType("System.Net.HttpWebResponse");
                        var q = from httpResponse in httpResponses
                                select new
                                {
                                    _clrobj = httpResponse,
                                    Uri = httpResponse.GetObjectDisplayValue("m_Uri"),
                                    Verb = httpResponse.GetObjectDisplayValue("m_Verb"),
                                    Address = httpResponse.GetAddressAsString(),
                                    Val = httpResponse.GetObjectDisplayValue()
                                };
                        var br = new BrowsePanel(q);
                        _mainWindowClrObjExp.AddItemsToContextMenu(br);
                        dpHTTPResponse.Children.Add(br);
                    }
                }
            }
        }
    }
}
