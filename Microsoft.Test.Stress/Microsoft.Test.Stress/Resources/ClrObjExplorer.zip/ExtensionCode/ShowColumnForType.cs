﻿//Desc: ShowColumnForType : choose a type and an arbitrary field for that type and see that field as a column

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: util\BaseExtension.cs
//Pragma: CompilerOptions=-langversion:9.0 -o

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using System.Reflection.Emit;
using System.Runtime.Remoting.Messaging;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("ColumnForType", $"choose a type and an arbitrary field for that type and see that field as a column");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
        public class MyUserControl : UserControl
        {
            internal MyMainClass _MyMainClass;
            internal MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
            internal ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
            internal DockPanel _dpData;
            public MyUserControl(MyMainClass myMainClass)
            {
                _MyMainClass = myMainClass;
            }
            public void Initialize()
            {
                _mainWindowClrObjExp.AddStatusMsg(_clrUtil._dumpFileName);
                // Make a namespace referring to our namespace and assembly
                // using the prefix "l:"
                //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
                var nameSpace = this.GetType().Namespace;
                var asm = System.IO.Path.GetFileNameWithoutExtension(
                    System.Reflection.Assembly.GetExecutingAssembly().Location);

                var xmlns = string.Format(
    @"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
                //there are a lot of quotes (and braces) in XAML
                //and the C# string requires quotes to be doubled
                var strxaml =
    @"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
    @">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width=""500""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width=""500""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width=""*""/>
    </Grid.ColumnDefinitions>
    <DockPanel x:Name = ""dpTypes"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Row = ""1""  Grid.Column = ""2"">
        <Grid.RowDefinitions>
            <RowDefinition Height = ""20""/>
            <RowDefinition Height = ""*""/>
            <RowDefinition Height = ""3""/>
            <RowDefinition/>
        </Grid.RowDefinitions>
        <DockPanel x:Name = ""dpLabel"" Grid.Row=""0"" />
        <DockPanel x:Name = ""dpFields"" Grid.Row = ""1""/>
        <GridSplitter Grid.Row=""2"" Height=""3"" HorizontalAlignment=""Stretch"" VerticalAlignment = ""Center"" Background=""LightBlue""/>
        <DockPanel x:Name = ""dpTree"" Grid.Row=""3"" />
    </Grid>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""3"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <DockPanel x:Name = ""dpData"" Grid.Row = ""1"" Grid.Column = ""4"" />
</Grid>
";
                var grid = (Grid)(XamlReader.Parse(strxaml));
                this.Content = grid;
                var dpLabel = (DockPanel)grid.FindName("dpLabel");
                var dpTypes = (DockPanel)grid.FindName("dpTypes");
                var dpFields = (DockPanel)grid.FindName("dpFields");
                _dpData = (DockPanel)grid.FindName("dpData");
                dpLabel.Children.Add(new TextBlock() { Text = "Select a type to show details" });

                using (var _progress = new ProgressOwnUI<string>($"Getting Types"))
                {
                    var lstTypes = new List<Tuple<string, int>>();
                    foreach (var type in _clrUtil.EnumerateObjectTypes())
                    {
                        var lstObjs = _clrUtil.GetObjectsOfType(type);
                        lstTypes.Add(Tuple.Create(type, lstObjs.Count));
                    }
                    var query = from tup in lstTypes
                                let typ = tup.Item1
                                select new
                                {
                                    _type = typ,
                                    Instances = tup.Item2,
                                    typ,
                                };
                    var brTypes = new BrowsePanel(query);
                    dpTypes.Children.Add(brTypes);
                    brTypes.BrowseList.SelectionChanged += (om, em) =>
                    {
                        try
                        {
                            dpFields.Children.Clear();
                            _dpData.Children.Clear();
                            BrowseList lv = om as BrowseList;
                            if (lv != null && lv.SelectedItems.Count == 1)
                            {
                                var selectedItem = lv.SelectedItems[0];
                                var typeDesc = TypeDescriptor.GetProperties(selectedItem)["_type"];
                                var type = (string)typeDesc.GetValue(selectedItem);
                                var lstObjs = _clrUtil.GetObjectsOfType(type);
                                var oneObjOfType = lstObjs[0];
                                var ptype = oneObjOfType.Type;

                                var qFlds = from fld in ptype.Fields
                                            select new
                                            {
                                                _Field = fld,
                                                fld.Name,
                                                FieldType = fld.Type.Name,
                                            };
                                var brFlds = new BrowsePanel(qFlds, ShowFilter: true);
                                dpFields.Children.Add(brFlds);
                                _mainWindowClrObjExp.AddItemsToContextMenu(brFlds);
                                brFlds.BrowseList.SelectionChanged += (om2, em2) =>
                                {
                                    try
                                    {
                                        _dpData.Children.Clear();
                                        BrowseList lv2 = om2 as BrowseList;
                                        if (lv2 != null && lv2.SelectedItems.Count == 1)
                                        {
                                            var selectedObjItem = lv2.SelectedItems[0];
                                            var field = (ClrField)TypeDescriptor.GetProperties(selectedObjItem)["_Field"].GetValue(selectedObjItem);
                                            var qObjs = from obj in lstObjs
                                                    select new
                                                    {
                                                        _clrobj = obj,
                                                        Address = obj.GetAddressAsString(),
                                                        Field = obj.GetObjectDisplayValue(field.Name),
                                                        Obj = obj.GetObjectDisplayValue()
                                                    };
                                            var brObjs = new BrowsePanel(qObjs);
                                            _mainWindowClrObjExp.AddItemsToContextMenu(brObjs);
                                            _dpData.Children.Add(brObjs);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                                    }
                                };
                            }
                        }
                        catch (Exception ex)
                        {
                            _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                        }
                    };
                }
            }
        }
    }
}
