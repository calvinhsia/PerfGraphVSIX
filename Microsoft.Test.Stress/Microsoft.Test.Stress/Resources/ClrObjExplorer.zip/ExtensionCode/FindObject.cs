﻿//Desc: FindObject: Given a hex address, find the object for that address

//Include: util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }
        private void DoMainInternal()
        {
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("FindObject", $"{_clrUtil._dumpFileName}");
            var ctrl = new MyUserControl(this);
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
        public class MyUserControl : UserControl
        {
            internal MyMainClass _MyMainClass;
            internal MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
            internal ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
            public string AddressToFind { get; set; }

            public MyUserControl(MyMainClass myMainClass)
            {
                _MyMainClass = myMainClass;
                this.DataContext = this;
            }
            public void Initialize()
            {
                // Make a namespace referring to our namespace and assembly
                // using the prefix "l:"
                //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
                var nameSpace = this.GetType().Namespace;
                var asm = System.IO.Path.GetFileNameWithoutExtension(
                    Assembly.GetExecutingAssembly().Location);

                var xmlns = string.Format(
    @"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
                //there are a lot of quotes (and braces) in XAML
                //and the C# string requires quotes to be doubled
                var strxaml =
    @"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
    @" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <StackPanel Orientation = ""Horizontal"">
        <Label Content=""Addressfind""/>
        <TextBox Text = ""{Binding AddressToFind}"" Width = ""150""/>
        <Button x:Name=""btnGo"" Content=""_Go""/>
    </StackPanel>
    <DockPanel x:Name = ""dpSummary"" Grid.Row=""1"" />
    
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""4"" Background=""LightBlue""/>
    <Grid Grid.Row = ""1""  Grid.Column = ""2"">
        <Grid.RowDefinitions>
            <RowDefinition Height = ""20""/>
            <RowDefinition Height = ""*""/>
        </Grid.RowDefinitions>
        <DockPanel x:Name = ""dpLabel"" Grid.Row=""0"" />
        <DockPanel x:Name = ""dpData"" Grid.Row=""1"" />
    </Grid>
</Grid>
";
                var grid = (Grid)(XamlReader.Parse(strxaml));
                this.Content = grid;
                var dpLabel = (DockPanel)grid.FindName("dpLabel");
                var dpSummary = (DockPanel)grid.FindName("dpSummary");
                var btnGo = (Button)grid.FindName("btnGo");
                var dpData = (DockPanel)grid.FindName("dpData");
                try
                {
                    btnGo.Click += (o, e) =>
                    {
                        try
                        {
                            UtilityUI.UpdateBindings(this);
                            var addr = ulong.Parse(AddressToFind.Replace("0x", ""), System.Globalization.NumberStyles.AllowHexSpecifier);
                            var obj = _clrUtil._heap.GetObject(addr);
                            _mainWindowClrObjExp.AddStatusMsg(MyAddrFormatter.AddrFormat($"{addr:x} {obj.GetObjectDisplayValue()} "));
                            dpSummary.Children.Clear();
                            dpData.Children.Clear();

                            if (obj.IsValid)
                            {
                                var objs = _clrUtil.GetObjectsOfType(obj.Type.Name);
                                var q = from clro in objs
                                        select new
                                        {
                                            _clrobj = clro,
                                            Address = clro.GetAddressAsString(),
                                            Obj = clro.GetObjectDisplayValue()
                                        };
                                var br = new BrowsePanel(q);
                                _mainWindowClrObjExp.AddItemsToContextMenu(br);
                                dpSummary.Children.Add(br);

                                var tvPanel = new TVObjRefPanel(_clrUtil, obj, _mainWindowClrObjExp, pathToOpen: null);
                                dpData.Children.Add(tvPanel);
                            }
                        }
                        catch (Exception ex)
                        {
                            _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                        }
                    };
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            }
        }
    }
}
