﻿//Desc: Extension Sample
//Desc: Shows how to find types, display selected members

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Xml;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;


namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }
        private void DoMainInternal()
        {
            var typeToFind = "Microsoft.VisualStudio.ThreadedWaitDialog.DialogShowArguments";
            using (var _progress = new ProgressOwnUI<string>($"Finding {typeToFind}"))
            {
                _progress.Report($"Finding {typeToFind}");
                var objs = _clrUtil.GetObjectsOfType(typeToFind);
                var qObjs = from obj in objs
                            select new
                            {
                                _clrobj = obj,
                                TWDArgs = obj.GetObjectDisplayValue(),
                                RootWindowCaption = obj.GetObjectDisplayValue("<RootWindowCaption>k__BackingField"),
                                WaitMessage = obj.GetObjectDisplayValue("<WaitMessage>k__BackingField"),
                            };
                var br = new BrowsePanel(qObjs);
                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("ThreadedWaitDialog Args", $"{typeToFind}");
                tabItem.Content = br;
            }
        }
    }
}

