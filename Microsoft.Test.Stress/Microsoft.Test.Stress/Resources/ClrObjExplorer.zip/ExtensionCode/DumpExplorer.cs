﻿//Desc: Explore the raw contents of a dump even if it cannot be loaded

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using DumpUtilities;
using static DumpUtilities.DumpReader.NativeMethods;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }
        private void DoMainInternal()
        {
            if (!File.Exists(_clrUtil._dumpFileName))
            {
                throw new FileNotFoundException($"{_clrUtil._dumpFileName} not found. Choose File->Open to choose a dump (even if it can't be successfully opened");
            }
            _mainWindowClrObjExp.AddStatusMsg($"DumpExplorer {_clrUtil._dumpFileName}  FileSize = {new FileInfo(_clrUtil._dumpFileName).Length:n0}");
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("DumpExplorer", $"Show the streams inside {_clrUtil._dumpFileName}");
            var dumpControl = new MiniDumpControl(_clrUtil._dumpFileName, _mainWindowClrObjExp);
            tabItem.Content = dumpControl;

        }
    }
    public class MiniDumpControl : UserControl, INotifyPropertyChanged, IDisposable
    {
        public event PropertyChangedEventHandler PropertyChanged;
        void RaisePropChanged([CallerMemberName] string propName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }
        public ObservableCollection<string> lstMinidumpStreamTypes { get; set; } = new ObservableCollection<string>();
        DumpReader _dumpReader;
        private readonly string dumpFileName;
        private readonly MainWindowClrObjExp _mainWindowClrObjExp;
        public MiniDumpControl(string dumpfilename, MainWindowClrObjExp mainWindowClrObjExp)
        {
            this.dumpFileName = dumpfilename;
            this._mainWindowClrObjExp = mainWindowClrObjExp;
            this.DataContext = this;
            _dumpReader = new DumpReader(dumpFileName);
            this.ShowMiniDumpReaderData();

        }
        public void ShowMiniDumpReaderData()
        {
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""230""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <Label Content=""Streams found in dump"" ToolTip = ""Click on a stream to show details""/>
    <ListView x:Name = ""lvStreamTypes"" Grid.Row = ""1"" Grid.Column = ""0"" ItemsSource = ""{Binding lstMinidumpStreamTypes}"" FontFamily=""Consolas""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""4"" Background=""LightBlue""/>
    <DockPanel x:Name = ""dpStream"" Grid.Row = ""1"" Grid.Column = ""2""/>
</Grid>
";
            var strReader = new System.IO.StringReader(strxaml);
            var xamlreader = XmlReader.Create(strReader);
            var grid = (Grid)(XamlReader.Load(xamlreader));
            var lvStreamTypes = (ListView)grid.FindName("lvStreamTypes");
            var dpStream = (DockPanel)grid.FindName("dpStream");
            lvStreamTypes.SelectionChanged += (o, e) =>
            {
                if (lvStreamTypes.SelectedItem != null)
                {
                    try
                    {
                        if (Enum.TryParse<MINIDUMP_STREAM_TYPE>(lvStreamTypes.SelectedItem.ToString().Split()[0], out var stype))
                        {
                            //                            using (var progress = new ProgressOwnUI<string>($"Finding {stype}"))
                            {
                                var newui = GetContentForStreamType(stype);
                                dpStream.Children.Clear();
                                dpStream.Children.Add(newui);
                            }
                        }
                    }
                    catch (Exception)
                    {
                    }
                }
            };
            this.Content = grid;
            Trace.WriteLine($"{_dumpReader._minidumpFileSize:n0} ({_dumpReader._minidumpFileSize:x8})");
            var arch = _dumpReader.GetMinidumpStream<MINIDUMP_SYSTEM_INFO>(MINIDUMP_STREAM_TYPE.SystemInfoStream);
            Trace.WriteLine(arch);
            var misc = _dumpReader.GetMinidumpStream<_MINIDUMP_MISC_INFO>(MINIDUMP_STREAM_TYPE.MiscInfoStream);
            Trace.WriteLine(misc);
            var lstStreamDirs = new List<MINIDUMP_DIRECTORY>();
            foreach (var strmtype in Enum.GetValues(typeof(MINIDUMP_STREAM_TYPE)))
            {
                var dir = _dumpReader.ReadMinidumpDirectoryForStreamType((MINIDUMP_STREAM_TYPE)strmtype);
                if (dir.Location.Rva != 0)
                {
                    lstStreamDirs.Add(dir);
                }
            }
            foreach (var dir in lstStreamDirs.OrderBy(d => d.Location.Rva))
            {
                var itmstr = $"{dir.StreamType,-30} Offset={dir.Location.Rva:x8}  Sz={dir.Location.DataSize:x8} ({dir.Location.DataSize:n0})";
                Trace.WriteLine($"   {itmstr}");
                lstMinidumpStreamTypes.Add(itmstr);
            }
        }

        private UIElement GetContentForStreamType(MINIDUMP_STREAM_TYPE streamType)
        {
            UIElement res = null;
            object oTopContent = null;
            switch (streamType)
            {
                case MINIDUMP_STREAM_TYPE.SystemInfoStream:
                    var arch = _dumpReader.GetMinidumpStream<MINIDUMP_SYSTEM_INFO>(MINIDUMP_STREAM_TYPE.SystemInfoStream);
                    res = new TextBlock() { Text = arch.ToString() };
                    break;
                case MINIDUMP_STREAM_TYPE.MiscInfoStream:
                    var misc = _dumpReader.GetMinidumpStream<_MINIDUMP_MISC_INFO>(MINIDUMP_STREAM_TYPE.MiscInfoStream);
                    res = new TextBlock() { Text = misc.ToString() };
                    break;
                case MINIDUMP_STREAM_TYPE.ModuleListStream: // MINIDUMP_MODULE
                    {
                        var lstModules = new List<Tuple<MINIDUMP_MODULE, string>>();
                        var hdr = _dumpReader.EnumerateStreamData<MINIDUMP_MODULE_LIST, MINIDUMP_MODULE>(MINIDUMP_STREAM_TYPE.ModuleListStream, (moddata) =>
                        {
                            var modName = _dumpReader.GetNameFromRva(moddata.ModuleNameRva);
                            lstModules.Add(Tuple.Create(moddata, modName));
                            return true; // continue enumerating
                        });

                        //foreach (var moddata in _dumpReader.EnumerateMinidumpStreamData<MINIDUMP_MODULE_LIST, MINIDUMP_MODULE>(MINIDUMP_STREAM_TYPE.ModuleListStream))
                        //{
                        //    var modName = _dumpReader.GetNameFromRva(moddata.ModuleNameRva);
                        //    lstModules.Add(Tuple.Create(moddata, modName));
                        //    //                            lv.Items.Add(new TextBlock() { Text = $"ImgSz={moddata.SizeOfImage,10:n0} Addr= {moddata.BaseOfImage:x8}   {modName}" });
                        //}
                        var q = from moddata in lstModules
                                select new
                                {
                                    ModuleName = moddata.Item2,
                                    moddata.Item1.SizeOfImage,
                                    BaseAddr = moddata.Item1.BaseOfImage.ToString("x16"),
                                    TimeDateStamp = ToDateTime(moddata.Item1.TimeDateStamp),
                                    Version = moddata.Item1.VersionInfo.GetVersion(),

                                };
                        var br = new BrowsePanel(q);
                        oTopContent = hdr.ToString();
                        res = br;
                    }
                    break;
                case MINIDUMP_STREAM_TYPE.UnloadedModuleListStream:
                    {
                        var lst = new List<Tuple<MINIDUMP_UNLOADED_MODULE, string>>();
                        var hdr = _dumpReader.EnumerateStreamData<MINIDUMP_UNLOADED_MODULE_LIST, MINIDUMP_UNLOADED_MODULE>(MINIDUMP_STREAM_TYPE.UnloadedModuleListStream, item =>
                        {
                            var modName = _dumpReader.GetNameFromRva(item.ModuleNameRva);
                            lst.Add(Tuple.Create(item, modName));
                            return true; // continue enumerating
                        });
                        //foreach (var moddata in _dumpReader.EnumerateMinidumpStreamData<MINIDUMP_UNLOADED_MODULE_LIST, MINIDUMP_UNLOADED_MODULE>(MINIDUMP_STREAM_TYPE.UnloadedModuleListStream))
                        //{
                        //    var modName = _dumpReader.GetNameFromRva(moddata.ModuleNameRva);
                        //    lv.Items.Add(new TextBlock() { Text = $"ImgSz={moddata.SizeOfImage,10:n0} Addr= {moddata.BaseOfImage:x8}   {modName}" });
                        //}
                        var q = from item in lst
                                select new
                                {
                                    BaseOfImage = item.Item1.BaseOfImage.ToString("x16"),
                                    SizeOfImage = item.Item1.SizeOfImage.ToString("x8"),
                                    Checksum = item.Item1.Checksum.ToString("x8"),
                                    TimeDateStamp = item.Item1.TimeDateStamp.ToString("x8"),
                                    Module = item.Item2
                                };
                        var br = new BrowsePanel(q);
                        oTopContent = hdr.ToString();
                        res = br;
                    }
                    break;
                case MINIDUMP_STREAM_TYPE.ThreadListStream: // MINIDUMP_THREAD
                    {
                        var lst = new List<MINIDUMP_THREAD>();
                        var hdr = _dumpReader.EnumerateStreamData<MINIDUMP_THREAD_LIST, MINIDUMP_THREAD>(MINIDUMP_STREAM_TYPE.ThreadListStream, item =>
                        {
                            lst.Add(item);
                            return true; // continue enumerating
                        });
                        var q = from item in lst
                                select new
                                {
                                    item.ThreadId,
                                    item.SuspendCount,
                                    item.PriorityClass,
                                    item.Priority,
                                    Teb = item.Teb.ToString("x16"),
                                    StackStart = item.Stack.StartOfMemoryRange.ToString("x16"),
                                    StackSize = item.Stack.MemoryLocDesc.DataSize
                                };
                        var br = new BrowsePanel(q);
                        oTopContent = hdr.ToString();
                        res = br;
                    }
                    break;
                case MINIDUMP_STREAM_TYPE.ThreadInfoListStream: //MINIDUMP_THREAD_INFO
                    {
                        var lst = new List<MINIDUMP_THREAD_INFO>();
                        var hdr = _dumpReader.EnumerateStreamData<MINIDUMP_THREAD_INFO_LIST, MINIDUMP_THREAD_INFO>(MINIDUMP_STREAM_TYPE.ThreadInfoListStream, item =>
                        {
                            lst.Add(item);
                            return true; // continue enumerating
                        });
                        var q = from item in lst
                                select new
                                {
                                    item.ThreadId,
                                    DumpFlags = item.DumpFlags.ToString("x8"),
                                    item.DumpError,
                                    item.ExitStatus,
                                    ExitTime = item.ExitTime.ToString("x16"),
                                    CreateTime = ToTimeSpan(item.CreateTime),
                                    KernelTime = ToTimeSpan(item.KernelTime),
                                    UserTime = ToTimeSpan(item.UserTime),
                                    StartAddress = item.StartAddress.ToString("x16"),
                                    item.Affinity
                                };
                        var br = new BrowsePanel(q);
                        oTopContent = hdr.ToString();
                        res = br;
                    }
                    break;
                case MINIDUMP_STREAM_TYPE.CommentStreamA:
                    {
                        var dir = _dumpReader.ReadMinidumpDirectoryForStreamType(streamType);
                        if (dir.Location.Rva != 0)
                        {
                            var ptrData = _dumpReader.MapRvaLocation(dir.Location);
                            var str = Marshal.PtrToStringAnsi(ptrData);
                            res = new TextBox() { Text = str, AcceptsReturn = true };
                        }
                    }
                    break;
                case MINIDUMP_STREAM_TYPE.CommentStreamW:
                    {
                        var dir = _dumpReader.ReadMinidumpDirectoryForStreamType(streamType);
                        if (dir.Location.Rva != 0)
                        {
                            var ptrData = _dumpReader.MapRvaLocation(dir.Location);
                            var str = Marshal.PtrToStringUni(ptrData);
                            res = new TextBox() { Text = str, AcceptsReturn = true };
                        }
                    }
                    break;
                case MINIDUMP_STREAM_TYPE.MemoryInfoListStream: // virtualalloc info
                    {
                        var lst = new List<MINIDUMP_MEMORY_INFO>();
                        var hdr = _dumpReader.EnumerateStreamData<MINIDUMP_MEMORY_INFO_LIST, MINIDUMP_MEMORY_INFO>(MINIDUMP_STREAM_TYPE.MemoryInfoListStream, item =>
                        {
                            lst.Add(item);
                            return true; // continue enumerating
                        });
                        var q = from item in lst
                                select new
                                {
                                    _item = item,
                                    BaseAddress = item.BaseAddress.ToString("x16"),
                                    AllocationBase = item.AllocationBase.ToString("x16"),
                                    AllocationProtect = item.AllocationProtect.ToString(),
                                    item.__alignment1,
                                    RegionSize = item.RegionSize.ToString("x16"),
                                    RegionSize10 = item.RegionSize,
                                    State = item.State.ToString(),
                                    Protect = item.Protect.ToString(),
                                    Type = item.Type.ToString(),
                                    item.__alignment2,
                                };
                        var qAggState = from va in lst
                                        group va by va.State
                                         into grp
                                        select new
                                        {
                                            State = grp.Key,
                                            Sum = grp.Sum(v => v.RegionSize),
                                            Count = grp.Count()
                                        };
                        var brAggState = new BrowsePanel(qAggState, ShowFilter: false);
                        var qAggType = from va in lst
                                       group va by va.Type
                                        into grp
                                       select new
                                       {
                                           State = grp.Key,
                                           Sum = grp.Sum(v => v.RegionSize),
                                           Count = grp.Count()
                                       };
                        /*
                         * 4G reserved:
Name
 VirtualReserve
+ ntoskrnl!?
|+ win32kbase!?
||+ win32kfull!?
|||+ win32k!?
||||+ ntoskrnl!?
|||| + ntdll!?
|||| |+ kernelbase!?
|||| ||+ clr!??GetRestrictedPhysicalMemoryLimit
|||| |||+ clr!GCToEEInterface::GetPhysicalMemoryLimit
|||| ||| + clr!SVR::GCHeap::GetValidGen0MaxSize
|||| |||  + clr!SVR::gc_heap::init_static_data
|||| |||   + clr!SVR::gc_heap::initialize_gc
|||| |||    + clr!SVR::GCHeap::Initialize
|||| |||     + clr!EEStartupHelper
|||| |||      + clr!EEStartup
|||| |||       + clr!EnsureEEStarted
|||| |||        + clr!CorRuntimeHostBase::Start
|||| |||         + clr!CorHost2::Start
|||| |||          + devenv!?
|||| |||           + mscoreei!?
|||| |||            + msenv!?
|||| |||             + devenv!?
|||| |||              + kernel32!?
|||| |||               + ntdll!?
|||| |||                + Thread (27116) CPU=5175ms (Startup Thread)
|||| |||                 + Process64 devenv (41384) Args:  
                         */
                        var brAggType = new BrowsePanel(qAggType, ShowFilter: false);
                        brAggType.BrowseList.LayoutTransform = new ScaleTransform(0.7, 0.7);
                        brAggState.BrowseList.LayoutTransform = new ScaleTransform(0.7, 0.7);

                        var br = new BrowsePanel(q);
                        var spTop = new StackPanel() { Orientation = Orientation.Horizontal };
                        oTopContent = spTop;
                        //                        spTop.Children.Add(new Label() { Content = hdr.ToString() });
                        spTop.Children.Add(brAggState);
                        spTop.Children.Add(brAggType);
                        res = br;
                        br.BrowseList.MouseMove += ((om, em) =>
                        {
                            try
                            {
                                BrowseList lv = om as BrowseList;
                                if (lv != null)
                                {
                                    var tb = em.OriginalSource as TextBlock;
                                    if (tb != null)
                                    {
                                        ToolTip tip = null;
                                        switch (tb.Name)
                                        {
                                            case "BaseAddress":
                                                var data = (MINIDUMP_MEMORY_INFO)TypeDescriptor.GetProperties(tb.DataContext)["_item"].GetValue(tb.DataContext);
                                                var tiptxt = string.Empty;
                                                if (data.State == StateEnum.MEM_COMMIT)
                                                {
                                                    tiptxt = ClrUtil.GetMemoryDumpAsString(data.BaseAddress, (ulong)data.RegionSize, nMaxDumpSize: 8192);
                                                }
                                                else
                                                {
                                                    tiptxt = $"{data.BaseAddress:x16} not commited memory";
                                                }
                                                tip = _mainWindowClrObjExp.CreateNewToolTip();
                                                var tbTip = new TextBox()
                                                {
                                                    BorderThickness = new System.Windows.Thickness(0),
                                                    FontFamily = new FontFamily("Courier New"),
                                                    FontSize = 9,
                                                    Background = Brushes.LightYellow,
                                                    Text = tiptxt
                                                };
                                                tip.Content = tbTip;

                                                break;
                                        }
                                        if (tip != null)
                                        {
                                            tip.PlacementTarget = tb;
                                            tip.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
                                            tip.IsOpen = true;
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                            }
                        });
                        br.BrowseList.ContextMenu.AddMenuItem((o, e) =>
                        {
                            try
                            {
                                if (br.BrowseList.SelectedItems.Count == 1)
                                {
                                    var itm = br.BrowseList.SelectedItems[0];
                                    var data = (MINIDUMP_MEMORY_INFO)TypeDescriptor.GetProperties(itm)["_item"].GetValue(itm);
                                    var tiptxt = string.Empty;
                                    if (data.State == StateEnum.MEM_COMMIT)
                                    {
                                        tiptxt = ClrUtil.GetMemoryDumpAsString(data.BaseAddress, (ulong)data.RegionSize, nMaxDumpSize: 8192);
                                    }
                                    else
                                    {
                                        tiptxt = $"{data.BaseAddress:x16} not commited memory";
                                    }
                                    BrowseList.WriteOutputToTempFile(tiptxt);
                                }
                            }
                            catch (Exception ex)
                            {
                                _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                            }

                        }, "Dump ToolTip to notepad", "", InsertPos: 0);
                    }
                    break;
                case MINIDUMP_STREAM_TYPE.MemoryListStream:
                    {
                        var lst = new List<MINIDUMP_MEMORY_DESCRIPTOR>();
                        var hdr = _dumpReader.EnumerateStreamData<MINIDUMP_MEMORY_LIST, MINIDUMP_MEMORY_DESCRIPTOR>(MINIDUMP_STREAM_TYPE.MemoryListStream, item =>
                        {
                            lst.Add(item);
                            return true; // continue enumerating
                        });
                        var q = from item in lst
                                select new
                                {
                                    StartOfMemoryRange = item.StartOfMemoryRange.ToString("x16"),
                                    DataSize = item.MemoryLocDesc.DataSize.ToString("x8")
                                };
                        var br = new BrowsePanel(q);
                        oTopContent = hdr.ToString();
                        res = br;
                    }
                    break;
                case MINIDUMP_STREAM_TYPE.Memory64ListStream:
                    {
                        var lst = new List<MINIDUMP_MEMORY_DESCRIPTOR64>();
                        var hdr = _dumpReader.EnumerateStreamData<MINIDUMP_MEMORY64_LIST, MINIDUMP_MEMORY_DESCRIPTOR64>(MINIDUMP_STREAM_TYPE.Memory64ListStream, item =>
                        {
                            lst.Add(item);
                            return true; // continue enumerating
                        });
                        var q = from item in lst
                                select new
                                {
                                    StartOfMemoryRange = item.StartOfMemoryRange.ToString("x16"),
                                    DataSize = item.DataSize.ToString("x8"),
                                    DataSize10 = item.DataSize
                                };
                        var br = new BrowsePanel(q);
                        oTopContent = hdr.ToString();
                        res = br;
                    }
                    break;
                case MINIDUMP_STREAM_TYPE.HandleDataStream:
                    {
                        var lstHandles = new List<Tuple<MINIDUMP_HANDLE_DESCRIPTOR, string, string>>();
                        var hdr = _dumpReader.EnumerateStreamData<MINIDUMP_HANDLE_DATA_STREAM, MINIDUMP_HANDLE_DESCRIPTOR>(MINIDUMP_STREAM_TYPE.HandleDataStream, item =>
                         {
                             var TypeName = string.Empty;
                             if (item.TypeNameRva != 0)
                             {
                                 TypeName = _dumpReader.GetNameFromRva(item.TypeNameRva);
                             }
                             var ObjectName = string.Empty;
                             if (item.ObjectNameRva != 0)
                             {
                                 ObjectName = _dumpReader.GetNameFromRva(item.ObjectNameRva);
                             }
                             lstHandles.Add(Tuple.Create(item, TypeName, ObjectName));
                             return true; // continue enumerating
                         });
                        var q = from item in lstHandles
                                select new
                                {
                                    Handle = item.Item1.Handle.ToString("x16"),
                                    item.Item1.Attributes,
                                    item.Item1.GrantedAccess,
                                    item.Item1.HandleCount,
                                    item.Item1.PointerCount,
                                    TypeName = item.Item2,
                                    ObjectName = item.Item3
                                };
                        var br = new BrowsePanel(q);
                        var qAggTypeName = from item in lstHandles
                                           group item by item.Item2
                                           into grp
                                           select new
                                           {
                                               Type = grp.Key,
                                               Count = grp.Count()
                                           };
                        var brAggTypeName = new BrowsePanel(qAggTypeName, ShowFilter: false);
                        brAggTypeName.BrowseList.LayoutTransform = new ScaleTransform(0.9, 0.9);
                        var spTop = new StackPanel() { Orientation = Orientation.Horizontal };
                        spTop.Children.Add(brAggTypeName);
                        oTopContent = spTop;
                        res = br;
                    }
                    break;
                case MINIDUMP_STREAM_TYPE.FunctionTableStream:
                    {
                        var lst = new List<_MINIDUMP_FUNCTION_TABLE_DESCRIPTOR>();
                        var hdr = _dumpReader.EnumerateStreamData<_MINIDUMP_FUNCTION_TABLE_STREAM, _MINIDUMP_FUNCTION_TABLE_DESCRIPTOR>(MINIDUMP_STREAM_TYPE.FunctionTableStream, item =>
                         {
                             lst.Add(item);
                             return true; // continue enumerating
                         });
                        var q = from dat in lst
                                select new
                                {
                                    MinimumAddress = dat.MinimumAddress.ToString("x16"),
                                    MaximumAddress = dat.MaximumAddress.ToString("x16"),
                                    BaseAddress = dat.BaseAddress.ToString("x16"),
                                    dat.EntryCount,
                                    dat.SizeOfAlignPad
                                };
                        var br = new BrowsePanel(q);
                        oTopContent = hdr.ToString();
                        res = br;
                    }
                    break;
            }
            if (res == null)
            {
                res = new TextBlock() { Text = $" {streamType} Not implemented" };
            }
            else
            {
                if (oTopContent != null)
                {
                    var dp = new DockPanel();
                    UIElement TopContent;
                    if (oTopContent is string)
                    {
                        TopContent = new TextBox() { Text = oTopContent.ToString() };
                    }
                    else
                    {
                        TopContent = (UIElement)oTopContent;
                    }
                    DockPanel.SetDock(TopContent, Dock.Top);
                    dp.Children.Add(TopContent);
                    dp.Children.Add(res);
                    res = dp;
                }
            }
            return res;
        }

        public void Dispose()
        {
            _dumpReader?.Dispose();
        }
    }

}
