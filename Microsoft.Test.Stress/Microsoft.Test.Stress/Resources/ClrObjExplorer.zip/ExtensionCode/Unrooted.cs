﻿//Desc: Given an object type, search around it to find identifiable stuff (e.g. Who created lots of unrooted NewtonSoft.JValue ?)

//Include: util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xaml.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var ctrl = new UnRootedControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("Unrooted", $"Unrooted Explorer");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
    }
    public class UnRootedControl : UserControl
    {
        public List<string> ClrTypes { get; set; } = new();
        MyMainClass _MyMainClass;
        MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
        ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
        public UnRootedControl(MyMainClass myMainClass)
        {
            _MyMainClass = myMainClass;
        }
        public void Initialize()
        {

            using (var progress = new ProgressOwnUI<string>($"Enumerating types"))
            {
                try
                {
                    foreach (var type in _clrUtil.EnumerateObjectTypes())
                    {
                        ClrTypes.Add(type);
                    }
                }
                catch (Exception ex)
                {
                    _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                }
            }

            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" >
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""800""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <Grid>
        <TextBox x:Name = ""tbTypes"" Text=""Types"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
        <DockPanel x:Name=""dpTypes"" Grid.Row=""1""/>
    </Grid>
    <GridSplitter Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Column = ""2"">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbInstances"" Text=""Instances"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name = ""dpInstances"" Grid.Row=""1""/>
        </Grid>
    </Grid>
    <GridSplitter Grid.Column = ""3"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Column = ""4"">
        <DockPanel x:Name = ""dpData""/>
    </Grid>
</Grid>
";
            var grid = (Grid)(XamlReader.Parse(strxaml));
            this.Content = grid;
            grid.DataContext = this;

            var dpTypes = (DockPanel)grid.FindName("dpTypes");
            var tbTypes = (TextBox)grid.FindName("tbTypes");
            var dpInstances = (DockPanel)grid.FindName("dpInstances");
            var dpData = (DockPanel)grid.FindName("dpData");

            tbTypes.Text = $@"Select a type. Right-Click to see various options";

            var qTypes = from type in ClrTypes
                         orderby type
                         select new
                         {
                             TypeName = type,
                         };
            var brTypes = new BrowsePanel(qTypes);
            dpTypes.Children.Add(brTypes);
            brTypes.BrowseList.SelectionChanged += (o, e) =>
             {
                 try
                 {
                     BrowseList lv = o as BrowseList;
                     if (lv != null && lv.SelectedItems.Count == 1)
                     {
                         var selectedItem = lv.SelectedItems[0];
                         var typeName = (string)TypeDescriptor.GetProperties(selectedItem)["TypeName"].GetValue(selectedItem);
                         var lstObjs = _clrUtil.GetObjectsOfType(typeName, maxNumObjs: 10000);
                         var qInstances = from obj in lstObjs
                                          select new
                                          {
                                              _clrobj = obj,
                                              Address = obj.GetAddressAsString(),
                                              Obj = obj.GetObjectDisplayValue(),
                                          };
                         var brInstances = new BrowsePanel(qInstances);
                         dpInstances.Children.Clear();
                         dpInstances.Children.Add(brInstances);
                         _mainWindowClrObjExp.AddItemsToContextMenu(brInstances);
                         brInstances.BrowseList.ContextMenu.AddMenuItem(async (_, __) =>
                         {
                             try
                             {
                                 if (brInstances.BrowseList.SelectedItems.Count > 0)
                                 {
                                     await Task.Delay(100); // allow ctx menu to close
                                     var dictResult = new Dictionary<string, int>();
                                     var hashVisited = new HashSet<ulong>();
                                     var queue = new Queue<ulong>();
                                     var cts = new CancellationTokenSource();
                                     using (var progress = new ProgressOwnUI<string>($"Walking reference tree", cts: cts, delayStart: false))
                                     {
                                         foreach (var selectedItem in brInstances.BrowseList.SelectedItems)
                                         {
                                             var clrObj = (ClrObject)TypeDescriptor.GetProperties(selectedItem)["_clrobj"].GetValue(selectedItem);
                                             queue.Enqueue(clrObj);
                                             while (queue.Count > 0 && !cts.IsCancellationRequested)
                                             {
                                                 var curobjAddr = queue.Dequeue();
                                                 if (!hashVisited.Contains(curobjAddr))
                                                 {
                                                     hashVisited.Add(curobjAddr);
                                                     var obj = _clrUtil._heap.GetObject(curobjAddr);
                                                     if (hashVisited.Count % 1000 == 0)
                                                     {
                                                         progress.Report($"Visited {hashVisited.Count:n0}");
                                                     }
                                                     obj.EnumerateRefsOfObject((child) =>
                                                     {
                                                         if (child.Type?.IsString == true)
                                                         {
                                                             var strval = child.AsString();
                                                             if (!string.IsNullOrEmpty(strval))
                                                             {
                                                                 if (!dictResult.ContainsKey(strval))
                                                                 {
                                                                     dictResult.Add(strval, 1);
                                                                 }
                                                                 else
                                                                 {
                                                                     dictResult[strval]++;
                                                                 }
                                                             }
                                                         }
                                                         else
                                                         {
                                                             queue.Enqueue(child.Address);
                                                         }
                                                         return true;
                                                     });
                                                 }
                                             }
                                         }
                                     }
                                     var qResult = from res in dictResult
                                                   orderby res.Value descending
                                                   select new
                                                   {
                                                       String = res.Key,
                                                       Count = res.Value
                                                   };
                                     var brResult = new BrowsePanel(qResult);
                                     brResult.BrowseList.ContextMenu.AddMenuItem((_, __) =>
                                     {
                                         try
                                         {
                                             if (brResult.BrowseList.SelectedItems.Count == 1)
                                             {
                                                 var selectedItem = brResult.BrowseList.SelectedItems[0];
                                                 var strVal = (string)TypeDescriptor.GetProperties(selectedItem)["String"].GetValue(selectedItem);
                                                 var allstrings = _clrUtil.GetObjectsOfType("System.String");
                                                 var lstStrs = new List<ulong>();
                                                 foreach (var str in allstrings)
                                                 {
                                                     if (str.AsString() == strVal)
                                                     {
                                                         lstStrs.Add(str.Address);
                                                     }
                                                 }
                                                 _mainWindowClrObjExp.MakeBrowseObjects($"SubSnapUnRooted", $"{strVal}", lstStrs);
                                             }
                                         }
                                         catch (Exception ex)
                                         {
                                             _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                                         }

                                     }, "Subset strings", "Create a new tab with just these strings (Can't do it from ObjSummary because too many strings to snapshot there", InsertPos: 0);
                                     dpData.Children.Clear();
                                     dpData.Children.Add(brResult);
                                     _mainWindowClrObjExp.AddStatusMsg($"Visited {hashVisited.Count:n0} objs");
                                 }

                             }
                             catch (Exception ex)
                             {
                                 _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                             }
                         }, "Get Data", "", InsertPos: 0);
                     }
                 }
                 catch (Exception ex)
                 {
                     _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                 }
             };
        }
    }
}
