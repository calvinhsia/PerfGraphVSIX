﻿//Desc: Show WPF Visual Tree and contents

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: util\BaseExtension.cs
//Include: util\WpfTreeView.cs
//Pragma: CompilerOptions=-langversion:9.0 -optimize

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using System.Reflection.Emit;
using System.Runtime.Remoting.Messaging;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args) { }

        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("WpfViewer", $"Select a WPF {WpfTreeView.WpfBaseType} type to show its Visual Tree");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
        public class MyUserControl : UserControl
        {
            internal MyMainClass _MyMainClass;
            internal MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
            internal ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
            internal DockPanel _dpData;
            public Dictionary<int, MyDependencyProperty> _dictDependencyProperties => _clrUtil._dictDependencyProperties.Value;
            internal WpfTreeView _WpfTreeView;
            public MyUserControl(MyMainClass myMainClass)
            {
                _MyMainClass = myMainClass;
            }
            public void Initialize()
            {
                // Make a namespace referring to our namespace and assembly
                // using the prefix "l:"
                //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
                var nameSpace = this.GetType().Namespace;
                var asm = System.IO.Path.GetFileNameWithoutExtension(
                    System.Reflection.Assembly.GetExecutingAssembly().Location);

                var xmlns = string.Format(
    @"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
                //there are a lot of quotes (and braces) in XAML
                //and the C# string requires quotes to be doubled
                var strxaml =
    @"<TabControl
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
    @">
    <TabItem Header=""WpfViewer"">
        <Grid x:Name=""gridWpfViewer"">
            <Grid.RowDefinitions>
                <RowDefinition Height=""30"" />
                <RowDefinition/>
            </Grid.RowDefinitions>
            <Grid.ColumnDefinitions>
                <ColumnDefinition Width=""400""/>
                <ColumnDefinition Width = ""3""/>
                <ColumnDefinition Width=""1600""/>
                <ColumnDefinition Width = ""3""/>
                <ColumnDefinition Width=""*""/>
            </Grid.ColumnDefinitions>
            <DockPanel x:Name = ""dpTypes"" Grid.Row = ""1"" Grid.Column = ""0""/>
            <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
            <Grid Grid.Row = ""1""  Grid.Column = ""2"">
                <Grid.RowDefinitions>
                    <RowDefinition Height = ""20""/>
                    <RowDefinition Height = ""200""/>
                    <RowDefinition Height = ""3""/>
                    <RowDefinition/>
                </Grid.RowDefinitions>
                <DockPanel x:Name = ""dpLabel"" Grid.Row=""0"" />
                <DockPanel x:Name = ""dpInstances"" Grid.Row = ""1""/>
                <GridSplitter Grid.Row=""2"" Height=""3"" HorizontalAlignment=""Stretch"" VerticalAlignment = ""Center"" Background=""LightBlue""/>
                <DockPanel x:Name = ""dpTree"" Grid.Row=""3"" />
            </Grid>
            <GridSplitter Grid.Row = ""1"" Grid.Column = ""3"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
            <Grid Grid.Row = ""1""  Grid.Column = ""4"">
                <Grid.RowDefinitions>
                    <RowDefinition Height = ""20""/>
                    <RowDefinition/>
                </Grid.RowDefinitions>
                <TextBlock x:Name=""tbDep""/>
                <DockPanel x:Name = ""dpData"" Grid.Row = ""1""/>
            </Grid>

        </Grid>
    </TabItem>
    <TabItem Header = ""DependencyProperties"">
        <DockPanel x:Name = ""dpDepProp""/>
    </TabItem>
</TabControl>
";
                var tabctrlWpfViewer = (TabControl)XamlReader.Parse(strxaml);
                var grid = (Grid)(tabctrlWpfViewer.FindName("gridWpfViewer"));
                this.Content = tabctrlWpfViewer;
                var dpLabel = (DockPanel)grid.FindName("dpLabel");
                var dpTypes = (DockPanel)grid.FindName("dpTypes");
                var dpInstances = (DockPanel)grid.FindName("dpInstances");
                var dpTree = (DockPanel)grid.FindName("dpTree");
                var tbDep = (TextBlock)grid.FindName("tbDep");
                var wpfTreeViewPanel = new WpfTreeViewPanel(_mainWindowClrObjExp);
                dpTree.Children.Add(wpfTreeViewPanel);
                _WpfTreeView = wpfTreeViewPanel._WpfTreeView;
                _dpData = (DockPanel)grid.FindName("dpData");
                dpLabel.Children.Add(new TextBlock() { Text = "Select a type to show WPF Visual Tree details" });

                var dpDepProp = (DockPanel)(tabctrlWpfViewer.FindName("dpDepProp"));
                _WpfTreeView.SelectedItemChanged += (o, e) =>
                {
                    try
                    {
                        _dpData.Children.Clear();
                        var selItem = _WpfTreeView.SelectedItem as WpfTreeViewItem;
                        if (selItem != null && selItem._clrObject != null)
                        {
                            var brEffVal = _WpfTreeView.ShowEffectiveValues(selItem._clrObject);
                            _dpData.Children.Add(brEffVal);
                            tbDep.Text = $"Attached Properties for {selItem._clrObject.GetObjectDisplayValue()}";
                        }
                    }
                    catch (Exception ex)
                    {
                        _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                    }
                    e.Handled = true;
                };
                using (var _progress = new ProgressOwnUI<string>($"Getting WPF Types"))
                {
                    var dependencyProperties = _clrUtil.GetObjectsOfType("System.Windows.DependencyProperty");
                    if (dependencyProperties.Count == 0)
                    {
                        throw new Exception("No WPF objects found");
                    }
                    var onedp = dependencyProperties[0];
                    {
                        var fld = onedp.Type.GetStaticFieldByName("PropertyFromName");
                        var hasht = ((ClrStaticField)fld).ReadObject(ClrUtil.g_ClrUtil.clrRuntime.AppDomains[0]); // System.Windows.DependencyProperty+FromNameKey 1abcd7ca3b0 = System.Windows.DependencyProperty 1abcd7ca3d8
                        var buckets = hasht.GetObjectMember("^[_]?buckets", IsRegex: true).AsArray();
                        var nElem = buckets.Length;
                        var elemType = buckets.Type.ElementType;
                        //_mainWindowClrObjExp.AddStatusMsg($"{hasht.GetObjectDisplayValue()}  nElem={nElem} elemType={elemType}");
                        for (int i = 0; i < Math.Min(100, nElem); i++)
                        {
                            var bucket = buckets.GetStructValue(i);
                            var key = bucket.ReadObjectField("key"); //System.Windows.DependencyProperty+FromNameKey
                            if (key.IsValid)
                            {
                                var propName = key.GetObjectMember("_name").AsString();
                                var ownerType = key.GetObjectMember("_ownerType");
                                var hashcode = key.ReadField<Int32>("_hashCode");
                                var val = bucket.ReadObjectField("val");
                                //                                _mainWindowClrObjExp.AddStatusMsg($"{bucket.Address:x16}  Hash={hashcode:x8} PName {propName} OwnerType={ownerType}  Val = {val}");
                            }
                        }
                    }
                    {
                        var qDp = (from kvp in _clrUtil._dictDependencyProperties.Value
                                   let obj = kvp.Value.clrObject
                                   select new
                                   {
                                       _clrobj = obj,
                                       Address = obj.GetAddressAsString(),
                                       PropertyName = kvp.Value.PropertyName,
                                       PropertyIndex = kvp.Key,
                                       DependencyProperty = obj.GetObjectDisplayValue(),
                                       PackedData = kvp.Value.PackedData.ToString("x8"),
                                   }).OrderBy(p => p.PropertyName);
                        var brdp = new BrowsePanel(qDp);
                        _mainWindowClrObjExp.AddItemsToContextMenu(brdp);
                        dpDepProp.Children.Add(brdp);
                    }
                    var lstTypes = new List<Tuple<ClrType, int>>();

                    foreach (var type in _clrUtil.EnumerateObjectTypes())
                    {
                        var lstObjs = _clrUtil.GetObjectsOfType(type);
                        var oneObjOfType = lstObjs[0];
                        var ptype = oneObjOfType.Type;

                        if (oneObjOfType.InheritsFrom(WpfTreeView.WpfBaseType))
                        {
                            lstTypes.Add(Tuple.Create(ptype, lstObjs.Count));
                        }
                    }
                    var query = from tup in lstTypes
                                let typ = tup.Item1
                                orderby typ.Name
                                select new
                                {
                                    _type = typ,
                                    typ.Name,
                                    Instances = tup.Item2,
                                    BaseType = typ.BaseType == null ? "" : typ.BaseType.Name,
                                    typ.Module,
                                };
                    var brTypes = new BrowsePanel(query);
                    dpTypes.Children.Add(brTypes);
                    brTypes.BrowseList.SelectionChanged += (om, em) =>
                     {
                         try
                         {
                             dpInstances.Children.Clear();
                             wpfTreeViewPanel.Clear();
                             _dpData.Children.Clear();
                             BrowseList lv = om as BrowseList;
                             if (lv != null && lv.SelectedItems.Count == 1)
                             {
                                 var selectedItem = lv.SelectedItems[0];
                                 var typeDesc = TypeDescriptor.GetProperties(selectedItem)["_type"];
                                 var type = (ClrType)typeDesc.GetValue(selectedItem);
                                 var lstObjs = _clrUtil.GetObjectsOfType(type.Name);
                                 var q = from obj in lstObjs
                                         select new
                                         {
                                             _clrobj = obj,
                                             Address = obj.GetAddressAsString(),
                                             Type = obj.Type.Name,
                                             Info = _WpfTreeView.GetWpfExtraInfoFromEffectiveValues(obj)
                                         };
                                 var brObjs = new BrowsePanel(q, ShowFilter: true);
                                 dpInstances.Children.Add(brObjs);
                                 _mainWindowClrObjExp.AddItemsToContextMenu(brObjs);
                                 brObjs.BrowseList.SelectionChanged += (om2, em2) =>
                                 {
                                     try
                                     {
                                         _dpData.Children.Clear();
                                         BrowseList lv2 = om2 as BrowseList;
                                         if (lv2 != null && lv2.SelectedItems.Count == 1)
                                         {

                                             var selectedObjItem = lv2.SelectedItems[0];
                                             var typeDescobj = TypeDescriptor.GetProperties(selectedObjItem)["_clrobj"];
                                             var clrObj = (ClrObject)typeDescobj.GetValue(selectedObjItem);
//                                             using (var _progress = new ProgressOwnUI<string>($"Expanding {clrObj.GetObjectDisplayValue()}")) ;
                                             _WpfTreeView.Initialize(clrObj);
                                             var brEffVal = _WpfTreeView.ShowEffectiveValues(clrObj);
                                             _dpData.Children.Add(brEffVal);
                                             tbDep.Text = $"Dependent Properties for {clrObj.GetObjectDisplayValue()}";
                                         }
                                     }
                                     catch (Exception ex)
                                     {
                                         _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                                     }
                                 };
                             }
                         }
                         catch (Exception ex)
                         {
                             _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                         }
                     };
                }
            }
        }
    }
}
