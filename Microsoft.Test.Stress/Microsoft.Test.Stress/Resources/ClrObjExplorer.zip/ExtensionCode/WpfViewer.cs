﻿//Desc: Show WPF elements and their contents

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: util\BaseExtension.cs
//Pragma: CompilerOptions=-langversion:9.0 -o

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using System.Reflection.Emit;
using System.Runtime.Remoting.Messaging;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("WpfViewer", $"Select a WPF {WpfTreeView.WpfBaseType} type to show its tree");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
        public class MyUserControl : UserControl
        {
            internal MyMainClass _MyMainClass;
            internal MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
            internal ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
            internal DockPanel _dpData;
            public Dictionary<int, MyDependencyProperty> _dictDependencyProperties => _clrUtil._dictDependencyProperties.Value;
            internal WpfTreeView _WpfTreeView;
            public MyUserControl(MyMainClass myMainClass)
            {
                _MyMainClass = myMainClass;
            }
            public void Initialize()
            {
                _mainWindowClrObjExp.AddStatusMsg(_clrUtil._dumpFileName);
                // Make a namespace referring to our namespace and assembly
                // using the prefix "l:"
                //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
                var nameSpace = this.GetType().Namespace;
                var asm = System.IO.Path.GetFileNameWithoutExtension(
                    System.Reflection.Assembly.GetExecutingAssembly().Location);

                var xmlns = string.Format(
    @"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
                //there are a lot of quotes (and braces) in XAML
                //and the C# string requires quotes to be doubled
                var strxaml =
    @"<TabControl
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
    @">
    <TabItem Header=""WpfViewer"">
        <Grid x:Name=""gridWpfViewer"">
            <Grid.RowDefinitions>
                <RowDefinition Height=""30"" />
                <RowDefinition/>
            </Grid.RowDefinitions>
            <Grid.ColumnDefinitions>
                <ColumnDefinition Width=""500""/>
                <ColumnDefinition Width = ""3""/>
                <ColumnDefinition Width=""1200""/>
                <ColumnDefinition Width = ""3""/>
                <ColumnDefinition Width=""*""/>
            </Grid.ColumnDefinitions>
            <DockPanel x:Name = ""dpTypes"" Grid.Row = ""1"" Grid.Column = ""0""/>
            <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
            <Grid Grid.Row = ""1""  Grid.Column = ""2"">
                <Grid.RowDefinitions>
                    <RowDefinition Height = ""20""/>
                    <RowDefinition Height = ""200""/>
                    <RowDefinition Height = ""3""/>
                    <RowDefinition/>
                </Grid.RowDefinitions>
                <DockPanel x:Name = ""dpLabel"" Grid.Row=""0"" />
                <DockPanel x:Name = ""dpInstances"" Grid.Row = ""1""/>
                <GridSplitter Grid.Row=""2"" Height=""3"" HorizontalAlignment=""Stretch"" VerticalAlignment = ""Center"" Background=""LightBlue""/>
                <DockPanel x:Name = ""dpTree"" Grid.Row=""3"" />
            </Grid>
            <GridSplitter Grid.Row = ""1"" Grid.Column = ""3"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
            <DockPanel x:Name = ""dpData"" Grid.Row = ""1"" Grid.Column = ""4"" />
        </Grid>
    </TabItem>
    <TabItem Header = ""DependencyProperties"">
        <DockPanel x:Name = ""dpDepProp""/>
    </TabItem>
</TabControl>
";
                var tabctrlWpfViewer = (TabControl)XamlReader.Parse(strxaml);
                var grid = (Grid)(tabctrlWpfViewer.FindName("gridWpfViewer"));
                this.Content = tabctrlWpfViewer;
                var dpLabel = (DockPanel)grid.FindName("dpLabel");
                var dpTypes = (DockPanel)grid.FindName("dpTypes");
                var dpInstances = (DockPanel)grid.FindName("dpInstances");
                var dpTree = (DockPanel)grid.FindName("dpTree");
                _dpData = (DockPanel)grid.FindName("dpData");
                dpLabel.Children.Add(new TextBlock() { Text = "Select a type to show details" });

                var dpDepProp = (DockPanel)(tabctrlWpfViewer.FindName("dpDepProp"));
                _WpfTreeView = new WpfTreeView(this);
                using (var _progress = new ProgressOwnUI<string>($"Getting WPF Types"))
                {
                    var dependencyProperties = _clrUtil.GetObjectsOfType("System.Windows.DependencyProperty");
                    if (dependencyProperties.Count == 0)
                    {
                        throw new Exception("No WPF objects found");
                    }
                    var onedp = dependencyProperties[0];
                    {
                        var fld = onedp.Type.GetStaticFieldByName("PropertyFromName");
                        var hasht = ((ClrStaticField)fld).ReadObject(ClrUtil.g_ClrUtil.clrRuntime.AppDomains[0]); // System.Windows.DependencyProperty+FromNameKey 1abcd7ca3b0 = System.Windows.DependencyProperty 1abcd7ca3d8
                        var buckets = hasht.GetObjectMember("buckets").AsArray();
                        var nElem = buckets.Length;
                        var elemType = buckets.Type.ElementType;
                        //_mainWindowClrObjExp.AddStatusMsg($"{hasht.GetObjectDisplayValue()}  nElem={nElem} elemType={elemType}");
                        for (int i = 0; i < Math.Min(100, nElem); i++)
                        {
                            var bucket = buckets.GetStructValue(i);
                            var key = bucket.ReadObjectField("key"); //System.Windows.DependencyProperty+FromNameKey
                            if (key.IsValid)
                            {
                                var propName = key.GetObjectMember("_name").AsString();
                                var ownerType = key.GetObjectMember("_ownerType");
                                var hashcode = key.ReadField<Int32>("_hashCode");
                                var val = bucket.ReadObjectField("val");
                                //                                _mainWindowClrObjExp.AddStatusMsg($"{bucket.Address:x16}  Hash={hashcode:x8} PName {propName} OwnerType={ownerType}  Val = {val}");
                            }
                        }
                    }
                    {
                        var qDp = (from kvp in _clrUtil._dictDependencyProperties.Value
                                   let obj = kvp.Value.clrObject
                                   select new
                                   {
                                       _clrobj = obj,
                                       Address = obj.GetAddressAsString(),
                                       PropertyName = kvp.Value.PropertyName,
                                       PropertyIndex = kvp.Key,
                                       DependencyProperty = obj.GetObjectDisplayValue(),
                                       PackedData = kvp.Value.PackedData.ToString("x8"),
                                   }).OrderBy(p => p.PropertyName);
                        var brdp = new BrowsePanel(qDp);
                        _mainWindowClrObjExp.AddItemsToContextMenu(brdp);
                        dpDepProp.Children.Add(brdp);
                    }
                    var lstTypes = new List<Tuple<ClrType, int>>();

                    foreach (var type in _clrUtil.EnumerateObjectTypes())
                    {
                        var lstObjs = _clrUtil.GetObjectsOfType(type);
                        var oneObjOfType = lstObjs[0];
                        var ptype = oneObjOfType.Type;

                        if (oneObjOfType.InheritsFrom(WpfTreeView.WpfBaseType))
                        {
                            lstTypes.Add(Tuple.Create(ptype, lstObjs.Count));
                        }
                    }
                    var query = from tup in lstTypes
                                let typ = tup.Item1
                                orderby typ.Name
                                select new
                                {
                                    _type = typ,
                                    typ.Name,
                                    Instances = tup.Item2,
                                    BaseType = typ.BaseType == null ? "" : typ.BaseType.Name,
                                    typ.Module,
                                };
                    var brTypes = new BrowsePanel(query);
                    dpTypes.Children.Add(brTypes);
                    brTypes.BrowseList.SelectionChanged += (om, em) =>
                     {
                         try
                         {
                             dpTree.Children.Clear();
                             dpInstances.Children.Clear();
                             _dpData.Children.Clear();
                             BrowseList lv = om as BrowseList;
                             if (lv != null && lv.SelectedItems.Count == 1)
                             {
                                 var selectedItem = lv.SelectedItems[0];
                                 var typeDesc = TypeDescriptor.GetProperties(selectedItem)["_type"];
                                 var type = (ClrType)typeDesc.GetValue(selectedItem);
                                 var lstObjs = _clrUtil.GetObjectsOfType(type.Name);
                                 var q = from obj in lstObjs
                                         select new
                                         {
                                             _clrobj = obj,
                                             Address = obj.GetAddressAsString(),
                                             Type = obj.Type.Name,
                                             Info = _WpfTreeView.GetWpfExtraInfoFromEffectiveValues(obj)
                                         };
                                 var brObjs = new BrowsePanel(q, ShowFilter: true);
                                 dpInstances.Children.Add(brObjs);
                                 _mainWindowClrObjExp.AddItemsToContextMenu(brObjs);
                                 brObjs.BrowseList.SelectionChanged += (om2, em2) =>
                                 {
                                     try
                                     {
                                         _dpData.Children.Clear();
                                         BrowseList lv2 = om2 as BrowseList;
                                         if (lv2 != null && lv2.SelectedItems.Count == 1)
                                         {
                                             var selectedObjItem = lv2.SelectedItems[0];
                                             var typeDescobj = TypeDescriptor.GetProperties(selectedObjItem)["_clrobj"];
                                             var clrObj = (ClrObject)typeDescobj.GetValue(selectedObjItem);
                                             dpTree.Children.Clear();
                                             _WpfTreeView.Initialize(clrObj);
                                             dpTree.Children.Add(_WpfTreeView);
                                             _WpfTreeView.ShowEffectivevalues(clrObj);
                                         }
                                     }
                                     catch (Exception ex)
                                     {
                                         _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                                     }
                                 };
                             }
                         }
                         catch (Exception ex)
                         {
                             _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                         }
                     };
                }
            }
        }
        public class WpfTreeView : MyTreeViewBase
        {
            internal MyUserControl _MyUserControl;
            //        public static string WpfBaseType = "System.Windows.Media.Visual";
            //            public static string WpfBaseType = "System.Windows.UIElement";
            public static string WpfBaseType = "System.Windows.DependencyObject";
            public WpfTreeView(MyUserControl myUserControl)
            {
                _MyUserControl = myUserControl;
                this.ContextMenu.AddMenuItem((_, _) =>
                {
                    try
                    {
                        var sel = this.SelectedItem as WpfTreeViewItem;
                        if (sel != null)
                        {
                            ObjRefView.MakeObjRefTree(_MyUserControl._clrUtil, sel._clrObject, _MyUserControl._mainWindowClrObjExp);
                        }
                    }
                    catch (Exception ex)
                    {
                        _MyUserControl._mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                    }

                }, "_References", "Show Object References", InsertPos: 0);
                this.SelectedItemChanged += (o, e) =>
                {
                    try
                    {
                        _MyUserControl._dpData.Children.Clear();
                        var selItem = this.SelectedItem as WpfTreeViewItem;
                        if (selItem != null && selItem._clrObject != null)
                        {
                            ShowEffectivevalues(selItem._clrObject);
                        }
                    }
                    catch (Exception ex)
                    {
                        _MyUserControl._mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                    }
                    e.Handled = true;
                };
            }
            public void Initialize(ClrObject clrObj)
            {
                Items.Clear();
                var tvItem = new WpfTreeViewItem(this, clrObj);
                this.Items.Add(tvItem);
                tvItem.IsExpanded = true;
            }
            //public IEnumerable<EffectiveValueEntry> GetEffectiveValues(ClrObject clrObj)
            //{
            //    var lstEffVals = new List<EffectiveValueEntry>();
            //    var oeffValues = clrObj.GetObjectMember("_effectiveValues");
            //    if (oeffValues.IsValid && oeffValues.IsArray)
            //    {
            //        var oeffValuesArr = oeffValues.AsArray();
            //        var len = oeffValuesArr.Length;
            //        lstEffVals.AddRange(oeffValuesArr.ReadValues<EffectiveValueEntry>(start: 0, count: len));
            //    }
            //    return lstEffVals;
            //}
            //public EffectiveValueEntry? GetEffectiveValue(ClrObject clrObj, string dependencyPropertyName)
            //{
            //    var effvalue = from effval in GetEffectiveValues(clrObj)
            //                   where _MyUserControl._dictDependencyProperties.ContainsKey(effval._propertyIndex)
            //                   where _MyUserControl._dictDependencyProperties[effval._propertyIndex].PropertyName == dependencyPropertyName
            //                   select effval;
            //    return effvalue.FirstOrDefault();
            //}
            public void ShowEffectivevalues(ClrObject clrObj)
            {
                var effVals = clrObj.GetEffectiveValues();
                var q = from effval in effVals
                        let elemObj = _MyUserControl._clrUtil._heap.GetObject((ulong)effval._value.ToInt64())
                        where elemObj.IsValid
                        let PropertyName = _MyUserControl._dictDependencyProperties.ContainsKey(effval._propertyIndex) ? _MyUserControl._dictDependencyProperties[effval._propertyIndex].PropertyName : ""
                        orderby PropertyName
                        select new
                        {
                            _clrobj = elemObj,
                            Address = elemObj.GetAddressAsString(),
                            PropertyIndex = effval._propertyIndex,
                            FullValueSource = ((int)effval._source).ToString("x4"),
                            PropertyName,
                            Value = elemObj.GetObjectDisplayValue()
                        };
                var brEffVal = new BrowsePanel(q);
                _MyUserControl._dpData.Children.Add(brEffVal);
            }

            public void DoPossiblyModifiedValue(ClrObject clrObj, EffectiveValueEntry effVal, Action<ClrObject> act)
            {
                if (clrObj.IsValid)
                {
                    if (clrObj.Type.Name == "System.Windows.ModifiedValue")
                    {
                        if (effVal._source.HasFlag(FullValueSource.IsCoerced) || effVal._source.HasFlag(FullValueSource.IsCoercedWithCurrentValue))
                        {
                            var coercedValue = clrObj.GetObjectMember("_coercedValue");
                            if (coercedValue.IsValid)
                            {
                                act(coercedValue);
                            }
                        }
                        else
                        {
                            var expressionValue = clrObj.GetObjectMember("_expressionValue");
                            if (expressionValue.IsValid)
                            {
                                act(expressionValue);
                            }
                        }
                    }
                    else if (clrObj.Type.Name == "Microsoft.VisualStudio.Platform.WindowManagement.WindowFrameTitle")
                    {
                        var title = clrObj.GetEffectiveValue("Title");
                        if (title != null)
                        {
                            var otitle = _MyUserControl._clrUtil._heap.GetObject((ulong)title.Value._value.ToInt64());
                            if (otitle.IsValid)
                            {
                                DoPossiblyModifiedValue(otitle, effVal, act); // recur
                            }
                        }
                    }
                    else
                    {
                        act(clrObj);
                    }
                }
            }
            public void DoWpfObject(ClrObject clrObj, Func<ClrObject, WpfTreeViewItem> actChild)
            {
                //                _MyUserControl._mainWindowClrObjExp.AddStatusMsg($"{nameof(DoWpfObject)} {clrObj}");
                if (!clrObj.IsValid)
                {
                    return;
                }
                if (clrObj.InheritsFrom("System.Windows.Controls.ContentControl") ||
                    clrObj.InheritsFrom("System.Windows.Controls.ContentPresenter") ||
                    clrObj.InheritsFrom("Microsoft.VisualStudio.PlatformUI.Shell.View"))
                {
                    if (clrObj.InheritsFrom("System.Windows.Controls.HeaderedContentControl"))
                    {
                        var headerEffVal = clrObj.GetEffectiveValue("Header");
                        if (headerEffVal != null)
                        {
                            var header = _MyUserControl._clrUtil._heap.GetObject((ulong)headerEffVal.Value._value.ToInt64());
                            if (header.IsValid && !header.Type.IsValueType && !header.Type.IsString)  // don't add a simple string as a child to reduce clutter
                            {
                                actChild(header);
                            }
                        }
                    }
                    var contentEffVal = clrObj.GetEffectiveValue("Content");
                    if (contentEffVal != null)
                    {
                        var contentObj = _MyUserControl._clrUtil._heap.GetObject((ulong)contentEffVal.Value._value.ToInt64());
                        if (contentObj.IsValid && !contentObj.Type.IsValueType && !contentObj.Type.IsString) // don't add a simple string as a child to reduce clutter
                        {
                            DoPossiblyModifiedValue(contentObj, contentEffVal.Value, (obj =>
                            {
                                actChild(obj);
                            }));
                        }
                    }
                }
                else if (clrObj.InheritsFrom("System.Windows.Controls.Panel")) // notdp _uiElementCollection
                {
                    var uielementCollection = clrObj.GetObjectMember("_uiElementCollection");
                    if (uielementCollection.IsValid)
                    {
                        var visualChildren = uielementCollection.GetObjectMember("_visualChildren"); // System.Windows.Media.VisualCollection
                        if (visualChildren.IsValid)
                        {
                            var oitems = visualChildren.GetObjectMember("_items");
                            if (oitems.IsValid && oitems.IsArray)
                            {
                                var items = oitems.AsArray(); //System.Windows.Media.Visual[]
                                for (int i = 0; i < items.Length; i++)
                                {
                                    var obj = items.GetObjectValue(i);
                                    if (obj.IsValid)
                                    {
                                        actChild(obj);
                                    }
                                }
                            }
                        }
                    }
                }
                else if (clrObj.InheritsFrom("System.Windows.Controls.ItemsControl"))
                {
                    var itemsHost = clrObj.GetObjectMember("_itemsHost");
                    if (itemsHost.IsValid)
                    {
                        actChild(itemsHost);
                    }
                    else
                    {
                        var items = clrObj.GetObjectMember("_items");
                        if (items.IsValid)
                        {
                            void DoArrayList(ClrObject arrayList)
                            {
                                if (arrayList.IsValid)
                                {
                                    var viewListItems = arrayList.GetObjectMember("_items"); // System.Object[]
                                    if (viewListItems.IsValid && viewListItems.IsArray)
                                    {
                                        var viewlistItemsArray = viewListItems.AsArray();
                                        for (int i = 0; i < viewlistItemsArray.Length; i++)
                                        {
                                            var oChild = viewlistItemsArray.GetObjectValue(i);
                                            if (oChild.IsValid)
                                            {
                                                actChild(oChild);
                                            }
                                        }
                                    }
                                }
                            }
                            var internalView = items.GetObjectMember("_internalView"); // MS.Internal.Controls.InnerItemCollectionView
                            if (internalView.IsValid)
                            {
                                var viewList = internalView.GetObjectMember("_viewList"); // System.Collections.ArrayList
                                if (viewList.IsValid)
                                {
                                    DoArrayList(viewList);
                                }
                            }
                            var collectionView = items.GetObjectMember("_collectionView"); // MS.Internal.Data.EnumerableCollectionView
                            if (collectionView.IsValid)
                            {
                                var view = collectionView.GetObjectMember("_view"); // System.Windows.Data.ListCollectionView
                                if (view.IsValid)
                                {
                                    var internalList = view.GetObjectMember("_internalList"); // System.Collections.ArrayList
                                    DoArrayList(internalList);
                                }
                            }
                        }
                    }
                }
                else if (clrObj.InheritsFrom("System.Windows.Controls.Decorator")) // _child System.Windows.UIElement
                {
                    var child = clrObj.GetObjectMember("_child");
                    if (child.IsValid)
                    {
                        actChild(child);
                    }
                }
                else if (clrObj.InheritsFrom("System.Windows.Controls.ContentPresenter")) // dp Content
                {
                    var contentEffVal = clrObj.GetEffectiveValue("Content");
                    if (contentEffVal != null)
                    {
                        var contentObj = _MyUserControl._clrUtil._heap.GetObject((ulong)contentEffVal.Value._value.ToInt64());
                        if (contentObj.IsValid)
                        {
                            actChild(contentObj);
                        }
                    }
                }
                else if (clrObj.InheritsFrom("Microsoft.VisualStudio.PlatformUI.Shell.ViewGroup"))
                {
                    var oitems = clrObj.GetObjectMember("visibleChildren")
                        .GetObjectMember("items")
                        .GetObjectMember("_items");
                    if (oitems.IsValid && oitems.IsArray)
                    {
                        var items = oitems.AsArray(); //System.Windows.Media.Visual[]
                        for (int i = 0; i < items.Length; i++)
                        {
                            var obj = items.GetObjectValue(i);
                            if (obj.IsValid)
                            {
                                actChild(obj);
                            }
                        }
                    }
                }
            }

            public string GetWpfExtraInfoFromEffectiveValues(ClrObject clrObj, StackPanel sp = null)
            {
                var retVal = string.Empty;
                GetStringOrModifiedValue(clrObj, "Name");
                GetStringOrModifiedValue(clrObj, "Header");
                GetStringOrModifiedValue(clrObj, "Text");
                GetStringOrModifiedValue(clrObj, "Title");
                if (clrObj.InheritsFrom("System.Windows.Controls.ContentControl")) // like a Button or Label with just simple text
                {
                    GetStringOrModifiedValue(clrObj, "Content");
                }
                return retVal;
                void GetStringOrModifiedValue(ClrObject clrO, string EffValueName)
                {
                    var effVal = clrO.GetEffectiveValue(EffValueName);
                    if (effVal != null)
                    {
                        var val = _MyUserControl._clrUtil._heap.GetObject((ulong)effVal.Value._value.ToInt64());
                        if (val.IsValid)
                        {
                            DoPossiblyModifiedValue(val, effVal.Value, (obj =>
                            {
                                var value = obj.GetObjectDisplayValue();
                                retVal += $"{EffValueName}='{value}'";
                                if (sp != null)
                                {
                                    sp.Children.Add(new TextBlock() { Text = $" {EffValueName}=", FontWeight = FontWeights.Bold });
                                    sp.Children.Add(new TextBlock() { Text = $"{value}", Foreground = Brushes.DarkCyan });
                                }
                            }));
                        }
                    }
                }
            }
        }

        public class WpfTreeViewItem : MyTreeViewItem
        {
            WpfTreeView _tv;
            public readonly ClrObject _clrObject;
            public WpfTreeViewItem(WpfTreeView tv, ClrObject clrObject)
            {
                this._clrObject = clrObject;
                this._tv = tv;
                this.Expanded += (o, e) =>
                {
                    try
                    {
                        if (this.Items.Count == 1 && (this.Items[0] as MyTreeViewItem != null))
                        {
                            Items.Clear();//clear dummy
                            _tv.DoWpfObject(_clrObject, (oChild) =>
                            {
                                var newItem = new WpfTreeViewItem(_tv, oChild);
                                this.Items.Add(newItem);
                                return newItem;
                            });
                        }
                        e.Handled = true;
                    }
                    catch (Exception ex)
                    {
                        _tv._MyUserControl._mainWindowClrObjExp.AddStatusMsg($"{ex}");
                    }
                };
                var sp = new StackPanel() { Orientation = Orientation.Horizontal };
                Header = sp;

                sp.Children.Add(new TextBlock() { Text = $"{clrObject.GetObjectDisplayValue()}" });
                _tv.GetWpfExtraInfoFromEffectiveValues(_clrObject, sp);

                this.Items.Add(new MyTreeViewItem()); // add a dummy
            }

            public override string ToString() => $"{Header}";
        }
    }
}
