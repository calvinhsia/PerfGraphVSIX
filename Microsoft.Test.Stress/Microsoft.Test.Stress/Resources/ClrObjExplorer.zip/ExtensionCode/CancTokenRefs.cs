﻿//Desc: CancellationTokenSource can have many object references in a sparse array, which is cumbersome to navigate

//Include: util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xaml.dll

// see also https://github.com/dotnet/runtime/blob/main/src/libraries/System.Collections.Immutable/src/System/Collections/Immutable/ImmutableHashSet.cs


using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("CancTknSrcRefs", $"CancellationTokenSource can have many object references in a sparse array, which is cumbersome to navigate");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
    }
    public class MyUserControl : UserControl
    {
        MyMainClass _MyMainClass;
        MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
        ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
        public MyUserControl(MyMainClass myMainClass)
        {
            _MyMainClass = myMainClass;
        }
        public void Initialize()
        {
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" >
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""Auto""/>
    </Grid.ColumnDefinitions>
    <Grid>
        <Grid>
            <DockPanel x:Name=""dpInstances"" Grid.Row=""0""/>
        </Grid>
    </Grid>
    <GridSplitter Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Column = ""2"">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height = ""Auto""/>
                <RowDefinition Height = ""*""/>
            </Grid.RowDefinitions>
            <TextBox x:Name = ""tbRefs"" Text=""Instances"" TextWrapping=""Wrap"" HorizontalAlignment=""Stretch""/>
            <DockPanel x:Name = ""dpRefs"" Grid.Row=""1""/>
        </Grid>
    </Grid>
</Grid>
";
            var grid = (Grid)(XamlReader.Parse(strxaml));
            this.Content = grid;
            grid.DataContext = this;

            var dpInstances = (DockPanel)grid.FindName("dpInstances");
            var dpRefs = (DockPanel)grid.FindName("dpRefs");
            var tbRefs = (TextBox)grid.FindName("tbRefs");

            var lstCTS = _clrUtil.GetObjectsOfType("System.Threading.CancellationTokenSource");
            var qTypes = from cts in lstCTS
                         let Refs = cts.GetSizeEx()
                         orderby Refs descending
                         select new
                         {
                             _clrobj = cts,
                             Address = cts.GetAddressAsString(),
                             CTS = cts.GetObjectDisplayValue(),
                             Refs
                         };
            var brInstances = new BrowsePanel(qTypes);
            dpInstances.Children.Add(brInstances);
            _mainWindowClrObjExp.AddItemsToContextMenu(brInstances);
            brInstances.BrowseList.SelectionChanged += (o, e) =>
             {
                 try
                 {
                     if (brInstances.BrowseList.SelectedItems.Count == 1)
                     {
                         dpRefs.Children.Clear();
                         var selectedItem = brInstances.BrowseList.SelectedItems[0];
                         var clrObjCTS = (ClrObject)TypeDescriptor.GetProperties(selectedItem)["_clrobj"].GetValue(selectedItem);
                         var ctsCallBackLists = clrObjCTS.GetObjectMember("m_registeredCallbacksLists"); //SparselyPopulatedArray<CancellationCallbackInfo>[]
                         var lstRefs = new List<ClrObject>();
                         if (ctsCallBackLists.IsValid)
                         {
                             ctsCallBackLists.EnumerateReferences((child) =>
                             {
                                 var done = false;
                                 var curArrayFrag = child.GetObjectMember("m_head");
                                 while (!done)
                                 {
                                     var elemArray = curArrayFrag.GetObjectMember("m_elements");
                                     elemArray.EnumerateReferences((addr2) =>
                                     {
                                         lstRefs.Add(addr2);
                                         return true;
                                     });

                                     var next = curArrayFrag.GetObjectMember("m_next");
                                     if (!next.IsValid)
                                     {
                                         done = true;
                                     }
                                     curArrayFrag = next;
                                 }
                                 return true;
                             });
                             var qRefs = from oRef in lstRefs // every one is a System.Threading.CancellationCallbackInfo
                                         let Callback = oRef.GetObjectMember("Callback")
                                         let StateForCallback = oRef.GetObjectMember("StateForCallback")
                                         select new
                                         {
                                             _clrobj = oRef,
                                             Address = oRef.GetAddressAsString(),
                                             Ref = oRef.GetObjectDisplayValue(),
                                             Callback = Callback.GetObjectDisplayValue(),
                                             StateForCallback = StateForCallback.GetObjectDisplayValue()
                                         };
                             var brRefs = new BrowsePanel(qRefs);
                             _mainWindowClrObjExp.AddItemsToContextMenu(brRefs);
                             dpRefs.Children.Add(brRefs);
                         }
                     }
                 }
                 catch (Exception ex)
                 {
                     _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                 }
             };
        }
    }
}
