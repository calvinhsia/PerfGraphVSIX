﻿//Desc: Extension Sample
//Desc: Shows how to find types, display selected members for TextBuffer

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Xml;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;


namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }
        /*
         */
        private void DoMainInternal()
        {
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" Margin=""5,5,5,5"">
<Grid.RowDefinitions>
    <RowDefinition/>
    <RowDefinition Height=""25"" />
</Grid.RowDefinitions>
<DockPanel Grid.Row=""0"">
    <Grid>
        <Grid.RowDefinitions>
        <RowDefinition Height = ""50""/>
        <RowDefinition Height = ""Auto""/>
        <RowDefinition Height = ""3""/>
        <RowDefinition Height = ""*""/>
        </Grid.RowDefinitions>
        <TextBlock Name = ""tbDesc""/>
        <Grid Grid.Row = ""1"">
            <Grid.ColumnDefinitions>
                <ColumnDefinition Width = ""Auto""/>
                <ColumnDefinition Width = ""3""/>
                <ColumnDefinition Width = ""*""/>
            </Grid.ColumnDefinitions>
            <DockPanel Grid.Column=""0"" Name=""dpTb""/>
            <DockPanel Grid.Column=""2"" Name=""dpTaskAllPromises""/>
            <GridSplitter Grid.Column = ""1"" VerticalAlignment=""Stretch"" Width = ""4"" HorizontalAlignment=""Center"" Background=""LightBlue""/>
            
        </Grid>
        <GridSplitter Grid.Row = ""2"" HorizontalAlignment=""Stretch"" VerticalAlignment=""Center"" Background=""LightBlue""/>
        <DockPanel Grid.Row=""3"" Name=""dpTaskDelayPromise""/>
    </Grid>
</DockPanel>
</Grid>
";

            var strReader = new System.IO.StringReader(strxaml);
            var xamlreader = XmlReader.Create(strReader);
            var gridx = (Grid)(XamlReader.Load(xamlreader));

            var typeToFind = "Microsoft.VisualStudio.Text.Implementation.TextBuffer";
            using (var _progress = new ProgressOwnUI<string>($"Finding {typeToFind}"))
            {
                _progress.Report($"Finding {typeToFind}");
                ClrObject clrobjDefault = default;

                var otextBuffers = _clrUtil.GetObjectsOfType(typeToFind);
                var qTextBuffers = from tb in otextBuffers
                                   let ContentTypeChanged = tb.GetObjectMember("ContentTypeChanged")
                                   let invList = ContentTypeChanged.IsValid ? ContentTypeChanged.GetObjectMember("_invocationList") : clrobjDefault
                                   where invList.IsValid
                                   let cnt = invList.GetSizeEx()
                                   select new
                                   {
                                       _clrobj = tb,
                                       Address = tb.GetAddressAsString(),
                                       TBuffer = tb.GetObjectDisplayValue(),
                                       Type = tb.Type.Name,
                                       ContentTypeChanged,
                                       cnt

                                   };
                var brTB = new BrowsePanel(qTextBuffers);
                //((DockPanel)gridx.FindName("dpTb")).Children.Add(brTB);
                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("TextBuffer", $"{typeToFind}");


                tabItem.Content = brTB;
                //var grid = new Grid();
                //tabItem.Content = grid;
                //grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(50) });
                //grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(500) });
                //grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(3) });
                //grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
                //var tb = new TextBlock() { Text = $"Total # of {typeToFind} = {oPromises.Count:n0}" };
                //Grid.SetRow(tb, 0);
                //grid.Children.Add(tb);

                //Grid.SetRow(brAgg, 1);
                //grid.Children.Add(brAgg);

                //var splitter = new GridSplitter() { HorizontalAlignment = HorizontalAlignment.Stretch, Height = 3 };
                //Grid.SetRow(splitter, 2);
                //grid.Children.Add(splitter);

                //Grid.SetRow(br, 3);
                //grid.Children.Add(br);
            }
        }
    }
}
