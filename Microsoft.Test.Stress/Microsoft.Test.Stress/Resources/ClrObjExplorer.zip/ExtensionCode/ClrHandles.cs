﻿//Desc: Show CLR Handles, like GCHandle, WeakShort, Dependent,AsyncPinned

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: util\BaseExtension.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using System.Reflection.Emit;
using System.Runtime.Remoting.Messaging;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        //        public static string WpfBaseType = "System.Windows.Media.Visual";
        public static string WpfBaseType = "System.Windows.DependencyObject";
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            _mainWindowClrObjExp.AddStatusMsg(_clrUtil._dumpFileName);
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                System.Reflection.Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition/>
    </Grid.ColumnDefinitions>
    <DockPanel x:Name = ""dpHandles"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <DockPanel x:Name = ""dpSummary"" Grid.Row=""2"" Grid.Column=""3"" />
</Grid>
";
            var strReader = new System.IO.StringReader(strxaml);
            var xamlreader = XmlReader.Create(strReader);
            var grid = (Grid)(XamlReader.Load(xamlreader));
            var dpHandles = (DockPanel)grid.FindName("dpHandles");
            var dpSummary = (DockPanel)grid.FindName("dpSummary");
            using (var _progress = new ProgressOwnUI<string>("Getting all Handles"))
            {
                var lstHandles = new List<ClrHandle>();

                foreach (ClrHandle clrHandle in _clrUtil.clrRuntime.EnumerateHandles())
                {
                    lstHandles.Add(clrHandle);
                }
                var query = from handle in lstHandles
                            select new
                            {
                                Address = MyAddrFormatter.AddrFormat($"{handle.Address:x}"),
                                Object = handle.Object.GetObjectDisplayValue(),
                                HandleKind = handle.HandleKind.ToString(),
                                handle.ReferenceCount,
                                Dependent = handle.Dependent.GetObjectDisplayValue(),
                                handle.IsInterior,
                                handle.IsPinned,
                                RootKind = handle.RootKind.ToString()
                            };
                var br = new BrowsePanel(query);
                dpHandles.Children.Add(br);

                var qSummary = from handle in lstHandles
                                group handle by handle.HandleKind
                                into grp
                                select new
                                {
                                    HandleKind = grp.Key,
                                    Count = grp.Count()
                                };

                var brSummary = new BrowsePanel(qSummary, ShowFilter: false);
                dpSummary.Children.Add(brSummary);

                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("Handles", $"");
                tabItem.Content = grid;
            }
        }
    }
}
