﻿//Desc: ShowColumnForType : choose a type and an arbitrary field for that type and see that field as a column

// This code will be compiled and run in the ClrObjExplorer Process.

//Include: util\BaseExtension.cs
//Pragma: CompilerOptions=-langversion:9.0 -o

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClrLib;
using ClrObjExplorer;
using Microsoft.Diagnostics.Runtime;
using Utility;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using System.Reflection.Emit;
using System.Runtime.Remoting.Messaging;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }

        private void DoMainInternal()
        {
            var ctrl = new MyUserControl(this);
            var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("PlayGround", $"PlayGround");
            tabItem.Content = ctrl;
            ctrl.Initialize();
        }
        public class MyUserControl : UserControl
        {
            internal MyMainClass _MyMainClass;
            internal MainWindowClrObjExp _mainWindowClrObjExp => _MyMainClass._mainWindowClrObjExp;
            internal ClrUtil _clrUtil => _mainWindowClrObjExp._clrUtil;
            internal DockPanel _dpData;
            public MyUserControl(MyMainClass myMainClass)
            {
                _MyMainClass = myMainClass;
            }
            public void Initialize()
            {
                _mainWindowClrObjExp.AddStatusMsg(_clrUtil._dumpFileName);
                // Make a namespace referring to our namespace and assembly
                // using the prefix "l:"
                //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
                var nameSpace = this.GetType().Namespace;
                var asm = System.IO.Path.GetFileNameWithoutExtension(
                    System.Reflection.Assembly.GetExecutingAssembly().Location);

                var xmlns = string.Format(
    @"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
                //there are a lot of quotes (and braces) in XAML
                //and the C# string requires quotes to be doubled
                var strxaml =
    @"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
    @">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width=""500""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width=""500""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width=""*""/>
    </Grid.ColumnDefinitions>
    <StackPanel Orientation=""Horizontal"">
        <Button x:Name=""btnGo"" Content=""_Go""/>
    </StackPanel>
    <DockPanel x:Name = ""dpTypes"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <Grid Grid.Row = ""1""  Grid.Column = ""2"">
        <Grid.RowDefinitions>
            <RowDefinition Height = ""20""/>
            <RowDefinition Height = ""*""/>
        </Grid.RowDefinitions>
        <DockPanel x:Name = ""dpLabel"" Grid.Row=""0"" />
        <DockPanel x:Name = ""dpFields"" Grid.Row = ""1""/>
    </Grid>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""3"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""3"" Background=""LightBlue""/>
    <DockPanel x:Name = ""dpData"" Grid.Row = ""1"" Grid.Column = ""4"" />
</Grid>
";
                var grid = (Grid)(XamlReader.Parse(strxaml));
                this.Content = grid;
                var btnGo = (Button)grid.FindName("btnGo");
                var dpLabel = (DockPanel)grid.FindName("dpLabel");
                var dpTypes = (DockPanel)grid.FindName("dpTypes");
                var dpFields = (DockPanel)grid.FindName("dpFields");
                _dpData = (DockPanel)grid.FindName("dpData");
                btnGo.Click += (_, _) =>
                {
                    try
                    {
                        var server = _clrUtil._ClrObjectServer.Value as InProcObjectServer;
                        _mainWindowClrObjExp.AddStatusMsg($"got InProcObjectServer{server}  {server.slistObjToRefs.Count} {server.sListInvert.Count}");
                        dpTypes.Children.Clear();
                        _dpData.Children.Clear();
                        var q = from kvp in server.slistObjToRefs
                                select new
                                {
                                    Key = kvp.Key.ToString("x16"),
                                    Num = kvp.Value.Count
                                };
                        var br = new BrowsePanel(q);
                        dpTypes.Children.Add(br);

                        // now 15        System.EventHandler  += System.ComponentModel.Design.Serialization.ResourcePropertyMemberCodeDomSerializer                           MultipleEventHandlers0      2        921         512     

                        //                        foreach (var evHandlerType in _clrUtil.EnumerateObjectTypes())
                        var evHandlerType = "System.ComponentModel.Design.Serialization.ResourcePropertyMemberCodeDomSerializer";
                        {
                            var oneObjOfType = _clrUtil.GetObjectsOfType(evHandlerType, maxNumObjs: 1);
                            var ptype = oneObjOfType[0].Type;
                            var IsEventHandler = false;
                            var curtype = ptype;
                            while (!IsEventHandler && curtype != null && curtype.Name != "System.Object")
                            {
                                if (curtype.Name == "System.MulticastDelegate")
                                {
                                    IsEventHandler = true;
                                    break;
                                }
                                curtype = curtype.BaseType;
                            }
                            _mainWindowClrObjExp.AddStatusMsg($"{evHandlerType} Isevh = {IsEventHandler}");
                        }
                        DoEvHandler();
                    }
                    catch (Exception ex)
                    {
                        _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                    }
                };

            }
            void DoEvHandler()
            {
                ProgressOwnUI<string> _progress = null;
                IWriteResults _writeResults = null;
                var fDidCreateProgBar = false;
                var _cts = new CancellationTokenSource();
                if (_progress == null)
                {
                    _progress = new ProgressOwnUI<string>("EventHandlers", cts: _cts);
                    _progress.GotMessageEvent += (o, e) =>
                    {
                        _clrUtil.LogString(e.msg);
                        _clrUtil.Output(e.msg + "\n");
                    };
                    fDidCreateProgBar = true;
                }
                int thresholdNumEventHandlers = 20; // arbitrary threshold: if there are more than these, see if there are dupes
                                                    //if (!string.IsNullOrEmpty(args))
                                                    //{
                                                    //    if (int.TryParse(args, out thresholdNumEventHandlers))
                                                    //    {
                                                    //    }
                                                    //}

                //                DoRoutedEventHandlers(thresholdNumEventHandlers, fVerbose);
                _progress.Report($"Analyzing EventHandlers");
                //sbResult.AppendLine($"Looking for System.EventHandler Leaks > {thresholdNumEventHandlers}");
                // hwndSourcehook bug: 
                // we don't know the name of the type: could be e.g. "System.Windows.Interop.HwndSourceHook"
                // so we iterate all types and see if they inherit from MulticastDelegate
                int nCnt = 0;
                int modulo = 1000;
                var cntTypes = _clrUtil._ClrObjectServer.Value.GetTypeCount(string.Empty);
                //                foreach (var evHandlerType in _clrUtil.EnumerateObjectTypes())
                var evHandlerType = "System.EventHandler";
                {
                    if (++nCnt % modulo == 0)
                    {
                        _progress?.Report($"{nCnt}/{cntTypes}");
                    }
                    var oneObjOfType = _clrUtil.GetObjectsOfType(evHandlerType, maxNumObjs: 1);
                    var ptype = oneObjOfType[0].Type;
                    if (_cts?.IsCancellationRequested == true)
                    {
                        _progress?.LogMessage("Cancelling");
                        return;
                    }
                    var IsEventHandler = false;
                    var curtype = ptype;
                    while (!IsEventHandler && curtype != null && curtype.Name != "System.Object")
                    {
                        if (curtype.Name == "System.MulticastDelegate")
                        {
                            IsEventHandler = true;
                            break;
                        }
                        curtype = curtype.BaseType;
                    }
                    if (IsEventHandler)
                    {
                        //LogString($"Got Multicast del {evHandlerType.Key}");
                        var dictInvocationList = new Dictionary<ulong, EventInvocationListData>(); //Some events share the same invocationlist. Different handler types should have different invocationlists
                        var lstObjectsOftype = _clrUtil.GetObjectsOfType(evHandlerType);
                        foreach (var evHandler in lstObjectsOftype)
                        {
                            //                        var evHandler = g_ClrUtil.clrRuntime.Heap.GetObject(evHandlerAddr);
                            if (_cts?.IsCancellationRequested == true)
                            {
                                _progress?.LogMessage("Cancelling");
                                return;
                            }
                            if (!evHandler.IsArray) // we don't want to deal with arrays of them
                            {
                                var IsLeakDetected = false;
                                var IsMultipleIdenticalTargetLeak = false;
                                var invocationCount = evHandler.GetSizeEx(); // For System.Eventhandler (and System.EventHandler<>) , this is the _invocationCount. For arrays, it's the array length
                                if (invocationCount > 0)
                                {
                                    // for each of these, let's see what the targets are
                                    //                                        LogString($" {evHandler.GetAddressAsString()}  Size={size} {evHandler.GetTypeName()}");
                                    //foreach (var mem in new[] { "_target", "_methodBase", "_methodPtr", "_methodPtrAux", "_invocationList", "_invocationCount" })
                                    //{
                                    //    var memval = evHandler.GetFieldValue(mem);
                                    //    LogString($"  {mem,25}= {memval}  {memval}");

                                    //}
                                    var invocationlist = evHandler.GetObjectMember("_invocationList");
                                    if (invocationlist.IsValid) // a null invocationlist implies the count==1 and the MulticastDelegate.GetInvocationList returns an array of length 1 with the eventhandler as the single member
                                    {
                                        if (!dictInvocationList.TryGetValue(invocationlist.Address, out var eventInvocationListData))
                                        {
                                            eventInvocationListData = new EventInvocationListData()
                                            {
                                                addrInvocationList = invocationlist.Address
                                            };
                                            dictInvocationList[invocationlist.Address] = eventInvocationListData;
                                        }
                                        //                                          LogString($" _invocationCount={invocationCount}    _invocationList={invocationlist.GetAddressAsString()} ");
                                        var strB = new StringBuilder();
                                        strB.AppendLine();
                                        var dictTargetsForThisEventHandler = new Dictionary<string, int>(); // TargetType to count, TargetTypeName
                                        var dictTargetAddresses = new Dictionary<ulong, EventTargetData>(); // Address of Target to EventTargetData
                                        invocationlist.EnumerateReferences((oTargetAddr) =>
                                        {
                                            var oEvHandler = _clrUtil.clrRuntime.Heap.GetObject(oTargetAddr);
                                            var evHandlerTarg = oEvHandler.GetObjectMember("_target");
                                            var targType = evHandlerTarg.GetTypeName(); // we want the # of typenames. They could be the same or different instances
                                            if (!dictTargetAddresses.ContainsKey(oTargetAddr))
                                            {
                                                dictTargetAddresses[oTargetAddr] = new EventTargetData()
                                                {
                                                    cnt = 1,
                                                    TypeName = targType
                                                };
                                            }
                                            else
                                            {
                                                dictTargetAddresses[oTargetAddr].cnt++;
                                                IsMultipleIdenticalTargetLeak = true;
                                                IsLeakDetected = true;
                                            }
                                            if (invocationCount > thresholdNumEventHandlers)
                                            {
                                                if (!dictTargetsForThisEventHandler.ContainsKey(targType))
                                                {
                                                    dictTargetsForThisEventHandler[targType] = 1;
                                                }
                                                else
                                                {
                                                    var n = dictTargetsForThisEventHandler[targType]++;
                                                    if (n > thresholdNumEventHandlers)
                                                    {
                                                        IsLeakDetected = true;
                                                    }
                                                }
                                                strB.AppendLine($"        {oTargetAddr:x8}  {oEvHandler.GetTypeName()} targ ={evHandlerTarg}");
                                            }
                                            return true;//continue
                                        });
                                        if (eventInvocationListData.strbData == null) // if it's null, use the 1st one found
                                        {
                                            eventInvocationListData.strbData = strB;
                                        }
                                        if ((IsLeakDetected || IsMultipleIdenticalTargetLeak) && !eventInvocationListData.DidOutputThisOne)
                                        {
                                            eventInvocationListData.DidOutputThisOne = true;
                                            var leakType = "Possible Leak";
                                            var memName = evHandler.GetParentObjAndMemberName(out ClrObject objParent); // expensive call
                                            if (!string.IsNullOrEmpty(memName))
                                            {
                                                eventInvocationListData.oEventPublisher = objParent;
                                                eventInvocationListData.strEventPublisherEventName = memName;
                                            }
                                            else
                                            {
                                                objParent = eventInvocationListData.oEventPublisher;
                                                memName = eventInvocationListData.strEventPublisherEventName;
                                            }
                                            //                                    LogString($"{leakType} {evHandler.GetAddressAsString()} {evHandler.GetTypeName()} += {objParent?._type.Name}.{memName}");
                                            var hashReportedTypes = new HashSet<string>(); // prevent duplicate reporting
                                            if (IsMultipleIdenticalTargetLeak)
                                            {
                                                foreach (var kvp in dictTargetAddresses.Where(kvp => kvp.Value.cnt > 1)) // this eventhandler has >1 target of the same address
                                                {
                                                    if (!hashReportedTypes.Contains(kvp.Value.TypeName))
                                                    {
                                                        hashReportedTypes.Add(kvp.Value.TypeName);
                                                        var oParentinfo = !objParent.IsValid ? string.Empty : $"({objParent.GetAddressAsString()}){objParent.Type?.Name}.{memName}";
                                                        _progress.LogMessage($"\n {leakType} MultipleIdenticalTargets: Cnt= {kvp.Value.cnt} {kvp.Key:x8} {oParentinfo} += {evHandler.GetAddressAsString()} {evHandlerType} {kvp.Value.TypeName}");
                                                        var oParentinfoWithoutAddr = !objParent.IsValid ? string.Empty : $"{objParent.Type?.Name}.{memName}";
                                                        _writeResults?.WriteRecord(
                                                            MemoryKind.managed_heap,
                                                            MemoryAnalysisType.eventhandlers,
                                                            "MultipleIdenticalTargets",
                                                            0,
                                                            (ulong)kvp.Value.cnt,
                                                            AdditionalInfo: $"{oParentinfoWithoutAddr} += {evHandlerType} {kvp.Value.TypeName}" // 
                                                            );
                                                    }
                                                }
                                            }
                                            foreach (var kvp in dictTargetsForThisEventHandler.Where(k => k.Value > thresholdNumEventHandlers).OrderByDescending(k => k.Value))
                                            {
                                                if (!hashReportedTypes.Contains(kvp.Key))
                                                {
                                                    var oParentinfo = !objParent.IsValid ? string.Empty : $"{objParent.GetAddressAsString()}){objParent.Type?.Name}.{memName}";
                                                    var oParentinfoWithoutAddr = !objParent.IsValid ? string.Empty : $"{objParent.Type?.Name}.{memName}";
                                                    _progress.LogMessage($"\n {leakType} MultipleEventHandlers: Cnt = {kvp.Value} {evHandler.GetAddressAsString()}  {evHandler.GetTypeName()}  ({oParentinfo} += {kvp.Key}");
                                                    _writeResults?.WriteRecord(
                                                        MemoryKind.managed_heap,
                                                        MemoryAnalysisType.eventhandlers,
                                                        "MultipleEventHandlers",
                                                        0,
                                                        (ulong)kvp.Value,
                                                        AdditionalInfo: $"{evHandler.GetTypeName()} {oParentinfoWithoutAddr} += {kvp.Key}"
                                                        );
                                                }
                                            }
                                            _progress.LogMessage(strB.ToString());
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                _progress.LogMessage($"Done analyzing Event Handlers");

            }
        }
        internal class EventTargetData
        {
            public int cnt;
            public string TypeName;
        }

        internal class EventInvocationListData
        {
            public ulong addrInvocationList;
            public ClrObject oEventPublisher;
            public string strEventPublisherEventName;
            public StringBuilder strbData;
            public bool DidOutputThisOne; // some invocationlists are shared by multiple evhandlers
        }

    }
}
