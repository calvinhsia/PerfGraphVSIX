﻿//Desc: Show Type methodss and their Compilation state, like NGen/Jit
//Include: util\BaseExtension.cs

//Ref: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xaml.dll
// problem:ClrMD says "MS.Internal.Text.TextInterface.Generics.NativeIUnknownWrapper<MS::Internal::Text::TextInterface::Native::IDWriteFont>" is not finalizable, but it has a finalizer: System.Runtime.InteropServices.CriticalHandle.Finalize()

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Markup;
using System.ComponentModel;
using System.Xml;
using ClrLib;
using Microsoft.Diagnostics.Runtime;
using Microsoft.Diagnostics.Runtime.Implementation;
using ClrObjExplorer;
using Utility;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace ClrObjExtension
{
    public class MyMainClass : BaseExtension
    {
        public static void DoMain(object[] args)
        {
            var othis = new MyMainClass(args);
            othis.DoMainInternal();
        }
        public MyMainClass(object[] args) : base(args)
        {

        }
        private void DoMainInternal()
        {
            // Make a namespace referring to our namespace and assembly
            // using the prefix "l:"
            //xmlns:l=""clr-namespace:Fish;assembly=Fish"""
            var nameSpace = this.GetType().Namespace;
            var asm = System.IO.Path.GetFileNameWithoutExtension(
                Assembly.GetExecutingAssembly().Location);

            var xmlns = string.Format(
@"xmlns:l=""clr-namespace:{0};assembly={1}""", nameSpace, asm);
            //there are a lot of quotes (and braces) in XAML
            //and the C# string requires quotes to be doubled
            var strxaml =
@"<Grid
xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
" + xmlns + // add our xaml namespace
@" Margin=""5,5,5,5"">
    <Grid.RowDefinitions>
        <RowDefinition Height=""30"" />
        <RowDefinition/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width = ""Auto""/>
        <ColumnDefinition Width = ""3""/>
        <ColumnDefinition Width = ""*""/>
    </Grid.ColumnDefinitions>
    <DockPanel x:Name = ""dpSummary"" Grid.Row = ""1"" Grid.Column = ""0""/>
    <GridSplitter Grid.Row = ""1"" Grid.Column = ""1"" HorizontalAlignment=""Center"" VerticalAlignment=""Stretch"" Width = ""4"" Background=""LightBlue""/>
        <Grid Grid.Row = ""1""  Grid.Column = ""2"">
            <Grid.RowDefinitions>
                <RowDefinition Height=""30"" />
                <RowDefinition/>
            </Grid.RowDefinitions>
            <DockPanel x:Name = ""dpLabel"" Grid.Row=""0"" />
            <DockPanel x:Name = ""dpJitNGen"" Grid.Row = ""1"" Grid.Column = ""2""/>
        </Grid>
</Grid>
";
            var strReader = new System.IO.StringReader(strxaml);
            var xamlreader = XmlReader.Create(strReader);
            var grid = (Grid)(XamlReader.Load(xamlreader));
            var dpJitNGen = (DockPanel)grid.FindName("dpJitNGen");
            var dpSummary = (DockPanel)grid.FindName("dpSummary");
            var dpLabel = (DockPanel)grid.FindName("dpLabel");
            dpLabel.Children.Add(new TextBlock() { Text = "Select a module to show methods, CompilationType" });

            try
            {
                var lstTuple = new List<Tuple<ClrType, ClrMethod>>();
                using (var progress = new ProgressOwnUI<string>($"Finding CompilationType of Methods"))
                {
                    foreach (var clrobjType in _clrUtil.EnumerateObjectTypes())
                    {
                        var lstObjs = _clrUtil.GetObjectsOfType(clrobjType);
                        var oneObjOfType = lstObjs[0];
                        var ptype = oneObjOfType.Type;
                        if (ptype.Name == "Free")
                        {
                            continue;
                        }
                        foreach (var meth in ptype.Methods)
                        {
                            lstTuple.Add(Tuple.Create(ptype, meth));
                        }
                    }
                }
                var q = from tup in lstTuple
                        group tup by new { tup.Item1.Module, tup.Item2.CompilationType }
                        into grp
                        select new
                        {
                            _module = grp.Key.Module,
                            Module = grp.Key.Module.Name,
                            CompiltionType = grp.Key.CompilationType.ToString(),
                            Count = grp.Count()
                        };
                var br = new BrowsePanel(q);
                dpSummary.Children.Add(br);

                //var qSummary = from obj in lstFinalize
                //               group obj by obj.Type
                //               into grp
                //               select new
                //               {
                //                   Type = grp.Key.Name,
                //                   grp.Key.IsFinalizable,
                //                   Count = grp.Count()
                //               };
                //var brSummary = new BrowsePanel(qSummary);
                //dpSummary.Children.Add(brSummary);
                var tabItem = _mainWindowClrObjExp.AddNewCloseableTabItem("JitNGen", $"{_clrUtil._dumpFileName}");
                tabItem.Content = grid;

                br.BrowseList.SelectionChanged += (om, em) =>
                {
                    try
                    {
                        BrowseList lv = om as BrowseList;
                        if (lv != null && lv.SelectedItems.Count == 1)
                        {
                            var selectedItem = lv.SelectedItems[0];
                            var typeDesc = TypeDescriptor.GetProperties(selectedItem)["_module"];
                            var module = (ClrmdModule)typeDesc.GetValue(selectedItem);
                            dpLabel.Children.Clear();
                            dpLabel.Children.Add(new TextBlock() { Text = $"{module.Name}" });
                            var qMethods = from tup in lstTuple
                                           where tup.Item1.Module == module
                                           select new
                                           {
                                               Type = tup.Item1.Name,
                                               Method = tup.Item2.Name,
                                               CompilationType = tup.Item2.CompilationType.ToString(),
                                           };
                            var brMethods = new BrowsePanel(qMethods);
                            dpJitNGen.Children.Clear();
                            dpJitNGen.Children.Add(brMethods);
                        }
                    }
                    catch (Exception ex)
                    {
                        _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
                    }

                };

            }
            catch (Exception ex)
            {
                _mainWindowClrObjExp.AddStatusMsg(ex.ToString());
            }
        }
    }
    public class MyDisposeControl : UserControl
    {
        public MyDisposeControl()
        {
            this.DataContext = this;

        }
    }
}
